# Kong's Quest — Windows v0.9 (kit de código e compilação)

Este ZIP substitui a dependência anterior do pacote com nome Android.
Inclui o núcleo modificado Snes9x, o fonte do host nativo Go para Windows,
o EXE Windows 64 bits e o workflow GitHub Actions. Ele NÃO contém ROM SNES.

## Estado
- O arquivo KongQuest-Windows.exe é um binário de Windows 64 bits gerado a partir do fonte Go.
- A DLL Windows modificada não foi gerada neste ambiente: GitHub Actions precisa compilá-la.
- Testar a importação da DLL no Windows NÃO prova que o jogo inteiro funciona.
- O DKC1 inteiro, os quatro personagens e as transições de campanha exigem testes reais.

## Como compilar
1. Envie o ZIP completo `Kongs-Quest-Windows-v09-Completo.zip` na raiz do seu GitHub (sem extrair).
2. Edite o arquivo `.github/workflows/build-windows.yml` no GitHub e substitua todo o texto pelo
   conteúdo de `build-windows-v09.yml` (enviado separadamente na conversa).
3. Em GitHub Actions, veja o job Windows e abra as mensagens de erro se houver falha.
4. Se passar, baixe o artefato Kongs-Quest-Windows-x64-v09-Experimental.
5. Extraia os arquivos; abra `KongQuest-Windows.exe` com a DLL do núcleo ao lado.

## Privacidade e direitos autorais
- Não envie ROMs comerciais, imagens de cartuchos, chaves nem senhas ao GitHub público.
- Este ZIP inclui fonte do emulador sob licença Snes9x (não comercial) e modificações;
  confira a licença `work/core/LICENSE`. Materiais derivados dos jogos podem ter direitos de terceiros.
