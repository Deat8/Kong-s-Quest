#include "snes9x.h"
#include "memmap.h"
#include "journey.h"
#include <algorithm>
#include <cstring>
#include <vector>

// Resolve the actual actor, independently of which original engine slot hosts it.
static int JourneyActorSlot(uint16_t base)
{
    if (Journey.page == 1 && (base == 2 || base == 4))
        return base / 2 - 1;
    if (Journey.page == 2)
    {
        if (base == 0x0de2) return 0;
        if (base == 0x0e40) return 1;
    }
    if (Journey.page == 3)
    {
        if (base == 0x0878) return 0;
        if (base == 0x08e6) return 1;
    }
    return -1;
}

static bool JourneyHeavy(unsigned slot)
{
    const unsigned kong = (Journey.team >> (slot * 2)) & 3;
    return kong == J_DONKEY || kong == J_KIDDY;
}

uint16_t JourneyRoleComparison(unsigned port)
{
    // Ports preserve the original comparison instruction and branch. Only its
    // comparison operand changes, so collision responses stay in the game code.
    const bool idInX = port == 0x5ff6;
    const uint16_t value = Registers.X.W;
    const int slot = JourneyActorSlot(idInX ? Registers.Y.W : Registers.X.W);
    if (slot < 0)
        return idInX ? 0x0230 : (port == 0x5ff4 ? 4 : 2);
    const bool matches = port == 0x5ff4 ? !JourneyHeavy(slot) : JourneyHeavy(slot);
    return matches ? value : value ^ 1;
}

struct JourneyRulePatch
{
    uint8_t* instruction;
    unsigned port;
};

static bool FindComparison(const uint8_t* signature, unsigned size, unsigned comparison,
                           unsigned port, std::vector<JourneyRulePatch>& patches)
{
    uint8_t* begin = Memory.ROM;
    uint8_t* end = begin + Memory.CalculatedSize;
    uint8_t* match = std::search(begin, end, signature, signature + size);
    if (match == end || std::search(match + size, end, signature, signature + size) != end)
        return false;
    patches.push_back({match + comparison, port});
    return true;
}

bool JourneyInstallCharacterRules()
{
    std::vector<JourneyRulePatch> patches;
    if (Journey.page == 1)
    {
        static const uint8_t eligibility[] = {0xa6,0x82,0xa4,0x88,0xe0,2,0,0xd0,0x12,0xb9,0x45,0x0d,0xc9,6,0};
        static const uint8_t bounce[] = {0xa9,0x20,7,0xe0,2,0,0xf0,3,0xa9,0x80,8,0x9d,0xf1,0x0e};
        static const uint8_t hitbox[] = {0xa9,9,0,0xe0,4,0,0xd0,3,0xa9,0x12,0};
        if (!FindComparison(eligibility, sizeof(eligibility), 4, 0x5ff2, patches) ||
            !FindComparison(bounce, sizeof(bounce), 3, 0x5ff2, patches) ||
            !FindComparison(hitbox, sizeof(hitbox), 3, 0x5ff4, patches))
            return false;
    }
    if (Journey.page == 3)
    {
        static const uint8_t response[] = {0xb6,0,0xad,0x54,0x18,0xe0,0x30,2,0xd0,3,0xad,0x56,0x18};
        if (!FindComparison(response, sizeof(response), 5, 0x5ff6, patches))
            return false;
    }
    // All signatures must match before any instruction is changed.
    for (const auto& patch : patches)
    {
        patch.instruction[0] = 0xec; // CPX absolute replaces CPX immediate.
        patch.instruction[1] = patch.port & 255;
        patch.instruction[2] = patch.port >> 8;
    }
    return true;
}
