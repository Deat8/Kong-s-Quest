/***********************************************************************************
  Snes9x - Portable Super Nintendo Entertainment System (TM) emulator.

  (c) Copyright 1996 - 2002  Gary Henderson (gary.henderson@ntlworld.com),
                             Jerremy Koot (jkoot@snes9x.com)

  (c) Copyright 2002 - 2004  Matthew Kendora

  (c) Copyright 2002 - 2005  Peter Bortas (peter@bortas.org)

  (c) Copyright 2004 - 2005  Joel Yliluoma (http://iki.fi/bisqwit/)

  (c) Copyright 2001 - 2006  John Weidman (jweidman@slip.net)

  (c) Copyright 2002 - 2006  funkyass (funkyass@spam.shaw.ca),
                             Kris Bleakley (codeviolation@hotmail.com)

  (c) Copyright 2002 - 2010  Brad Jorsch (anomie@users.sourceforge.net),
                             Nach (n-a-c-h@users.sourceforge.net),
                             zones (kasumitokoduck@yahoo.com)

  (c) Copyright 2006 - 2007  nitsuja

  (c) Copyright 2009 - 2010  BearOso,
                             OV2


  BS-X C emulator code
  (c) Copyright 2005 - 2006  Dreamer Nom,
                             zones

  C4 x86 assembler and some C emulation code
  (c) Copyright 2000 - 2003  _Demo_ (_demo_@zsnes.com),
                             Nach,
                             zsKnight (zsknight@zsnes.com)

  C4 C++ code
  (c) Copyright 2003 - 2006  Brad Jorsch,
                             Nach

  DSP-1 emulator code
  (c) Copyright 1998 - 2006  _Demo_,
                             Andreas Naive (andreasnaive@gmail.com),
                             Gary Henderson,
                             Ivar (ivar@snes9x.com),
                             John Weidman,
                             Kris Bleakley,
                             Matthew Kendora,
                             Nach,
                             neviksti (neviksti@hotmail.com)

  DSP-2 emulator code
  (c) Copyright 2003         John Weidman,
                             Kris Bleakley,
                             Lord Nightmare (lord_nightmare@users.sourceforge.net),
                             Matthew Kendora,
                             neviksti

  DSP-3 emulator code
  (c) Copyright 2003 - 2006  John Weidman,
                             Kris Bleakley,
                             Lancer,
                             z80 gaiden

  DSP-4 emulator code
  (c) Copyright 2004 - 2006  Dreamer Nom,
                             John Weidman,
                             Kris Bleakley,
                             Nach,
                             z80 gaiden

  OBC1 emulator code
  (c) Copyright 2001 - 2004  zsKnight,
                             pagefault (pagefault@zsnes.com),
                             Kris Bleakley
                             Ported from x86 assembler to C by sanmaiwashi

  SPC7110 and RTC C++ emulator code used in 1.39-1.51
  (c) Copyright 2002         Matthew Kendora with research by
                             zsKnight,
                             John Weidman,
                             Dark Force

  SPC7110 and RTC C++ emulator code used in 1.52+
  (c) Copyright 2009         byuu,
                             neviksti

  S-DD1 C emulator code
  (c) Copyright 2003         Brad Jorsch with research by
                             Andreas Naive,
                             John Weidman

  S-RTC C emulator code
  (c) Copyright 2001 - 2006  byuu,
                             John Weidman

  ST010 C++ emulator code
  (c) Copyright 2003         Feather,
                             John Weidman,
                             Kris Bleakley,
                             Matthew Kendora

  Super FX x86 assembler emulator code
  (c) Copyright 1998 - 2003  _Demo_,
                             pagefault,
                             zsKnight

  Super FX C emulator code
  (c) Copyright 1997 - 1999  Ivar,
                             Gary Henderson,
                             John Weidman

  Sound emulator code used in 1.5-1.51
  (c) Copyright 1998 - 2003  Brad Martin
  (c) Copyright 1998 - 2006  Charles Bilyue'

  Sound emulator code used in 1.52+
  (c) Copyright 2004 - 2007  Shay Green (gblargg@gmail.com)

  SH assembler code partly based on x86 assembler code
  (c) Copyright 2002 - 2004  Marcus Comstedt (marcus@mc.pp.se)

  2xSaI filter
  (c) Copyright 1999 - 2001  Derek Liauw Kie Fa

  HQ2x, HQ3x, HQ4x filters
  (c) Copyright 2003         Maxim Stepin (maxim@hiend3d.com)

  NTSC filter
  (c) Copyright 2006 - 2007  Shay Green

  GTK+ GUI code
  (c) Copyright 2004 - 2010  BearOso

  Win32 GUI code
  (c) Copyright 2003 - 2006  blip,
                             funkyass,
                             Matthew Kendora,
                             Nach,
                             nitsuja
  (c) Copyright 2009 - 2010  OV2

  Mac OS GUI code
  (c) Copyright 1998 - 2001  John Stiles
  (c) Copyright 2001 - 2010  zones

  (c) Copyright 2010 - 2016 Daniel De Matteis. (UNDER NO CIRCUMSTANCE 
  WILL COMMERCIAL RIGHTS EVER BE APPROPRIATED TO ANY PARTY)

  Specific ports contains the works of other authors. See headers in
  individual files.


  Snes9x homepage: http://www.snes9x.com/

  Permission to use, copy, modify and/or distribute Snes9x in both binary
  and source form, for non-commercial purposes, is hereby granted without
  fee, providing that this license information and copyright notice appear
  with all copies and any derived work.

  This software is provided 'as-is', without any express or implied
  warranty. In no event shall the authors be held liable for any damages
  arising from the use of this software or it's derivatives.

  Snes9x is freeware for PERSONAL USE only. Commercial users should
  seek permission of the copyright holders first. Commercial use includes,
  but is not limited to, charging money for Snes9x or software derived from
  Snes9x, including Snes9x or derivatives in commercial game bundles, and/or
  using Snes9x as a promotion for your commercial product.

  The copyright holders request that bug fixes and improvements to the code
  should be forwarded to them so everyone can benefit from the modifications
  in future versions.

  Super NES and Super Nintendo Entertainment System are trademarks of
  Nintendo Co., Limited and its subsidiary companies.
 ***********************************************************************************/


#include <stdint.h>
#include "port.h"
#include "obc1.h"

uint8_t *OBC1RAMBase = 0;

uint8_t S9xGetOBC1 (uint16_t Address)
{
	switch (Address)
	{
		case 0x7ff0:
			return (OBC1RAMBase[OBC1.basePtr + (OBC1.address << 2)]);

		case 0x7ff1:
			return (OBC1RAMBase[OBC1.basePtr + (OBC1.address << 2) + 1]);

		case 0x7ff2:
			return (OBC1RAMBase[OBC1.basePtr + (OBC1.address << 2) + 2]);

		case 0x7ff3:
			return (OBC1RAMBase[OBC1.basePtr + (OBC1.address << 2) + 3]);

		case 0x7ff4:
			return (OBC1RAMBase[OBC1.basePtr + (OBC1.address >> 2) + 0x200]);
	}

	return (OBC1RAMBase[Address - 0x6000]);
}

void S9xSetOBC1 (uint8_t Byte, uint16_t Address)
{
	switch (Address)
	{
		case 0x7ff0:
			OBC1RAMBase[OBC1.basePtr + (OBC1.address << 2)] = Byte;
			break;

		case 0x7ff1:
			OBC1RAMBase[OBC1.basePtr + (OBC1.address << 2) + 1] = Byte;
			break;

		case 0x7ff2:
			OBC1RAMBase[OBC1.basePtr + (OBC1.address << 2) + 2] = Byte;
			break;

		case 0x7ff3:
			OBC1RAMBase[OBC1.basePtr + (OBC1.address << 2) + 3] = Byte;
			break;

		case 0x7ff4:
		{
			uint8_t Temp;
			Temp = OBC1RAMBase[OBC1.basePtr + (OBC1.address >> 2) + 0x200];
			Temp = (Temp & ~(3 << OBC1.shift)) | ((Byte & 3) << OBC1.shift);
			OBC1RAMBase[OBC1.basePtr + (OBC1.address >> 2) + 0x200] = Temp;
			break;
		}

		case 0x7ff5:
			if (Byte & 1)
				OBC1.basePtr = 0x1800;
			else
				OBC1.basePtr = 0x1c00;
			break;

		case 0x7ff6:
			OBC1.address = Byte & 0x7f;
			OBC1.shift = (Byte & 3) << 1;
			break;
	}

	OBC1RAMBase[Address - 0x6000] = Byte;
}

void S9xResetOBC1 (void)
{
	int i;
	for ( i = 0; i <= 0x1fff; i++)
		OBC1RAMBase[i] = 0xff;

	if (OBC1RAMBase[0x1ff5] & 1)
		OBC1.basePtr = 0x1800;
	else
		OBC1.basePtr = 0x1c00;

	OBC1.address = OBC1RAMBase[0x1ff6] & 0x7f;
	OBC1.shift = (OBC1RAMBase[0x1ff6] & 3) << 1;
}

uint8_t * S9xGetBasePointerOBC1 (uint16_t Address)
{
	if (Address >= 0x7ff0 && Address <= 0x7ff6)
		return (NULL);
	return (OBC1RAMBase - 0x6000);
}

uint8_t * S9xGetMemPointerOBC1 (uint16_t Address)
{
	if (Address >= 0x7ff0 && Address <= 0x7ff6)
		return (NULL);
	return (OBC1RAMBase + Address - 0x6000);
}
