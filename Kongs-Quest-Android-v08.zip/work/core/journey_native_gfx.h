#ifndef JOURNEY_NATIVE_GFX_H
#define JOURNEY_NATIVE_GFX_H
#include "journey_native_carry.h"

struct JourneyDecodedPose
{
    unsigned header = ~0u;
    const uint16_t* palette = nullptr;
    uint16_t pixels[128 * 128] = {};
    int left = 0, right = 0, top = 0, bottom = 0;
    bool valid = false;
};

static bool JourneyDecodePose(unsigned address, const uint16_t* palette, JourneyDecodedPose& out)
{
    if (out.header == address && out.palette == palette)
        return out.valid;
    out.header = address;
    out.palette = palette;
    out.valid = false;
    if (address + 8 >= Journey.cartridge.size()) return false;
    const uint8_t* h = Journey.cartridge.data() + address;
    const unsigned large = h[0], small = h[1] + h[3], parts = large + small;
    const unsigned bytes = large * 128 + small * 32;
    if (large > 16 || parts > 48 || !parts || address + 8 + parts * 2 + bytes > Journey.cartridge.size())
        return false;
    const uint8_t* gfx = h + 8 + parts * 2;
    std::memset(out.pixels, 0, sizeof(out.pixels));
    out.left = out.top = 128;
    out.right = out.bottom = -1;
    for (unsigned part = 0; part < parts; ++part)
    {
        const unsigned size = part < large ? 16 : 8;
        for (unsigned y = 0; y < size; ++y)
            for (unsigned x = 0; x < size; ++x)
            {
                const unsigned tile = part < large ? part * 2 + x / 8 + (large * 2 + h[1]) * (y / 8) :
                    (part < large + h[1] ? large * 2 + part - large : large * 4 + part - large);
                if (tile * 32 + 31 >= bytes) return false;
                const uint8_t* t = gfx + tile * 32;
                const unsigned row = (y & 7) * 2, bit = 7 - (x & 7);
                const unsigned color = ((t[row] >> bit) & 1) | (((t[row + 1] >> bit) & 1) << 1) |
                    (((t[row + 16] >> bit) & 1) << 2) | (((t[row + 17] >> bit) & 1) << 3);
                if (!color) continue;
                const int dx = 64 + int(h[8 + part * 2]) - 128 + int(x);
                const int dy = 96 + int(h[9 + part * 2]) - 128 + int(y);
                if (dx < 0 || dx >= 128 || dy < 0 || dy >= 128) return false;
                out.pixels[dy * 128 + dx] = palette[color] ? palette[color] : 1;
                out.left = std::min(out.left, dx - 64);
                out.right = std::max(out.right, dx - 64);
                out.top = std::min(out.top, dy - 96);
                out.bottom = std::max(out.bottom, dy - 96);
            }
    }
    return out.valid = out.right >= out.left;
}

static const JourneyNativeCarryStep* JourneyCarryStep(unsigned kong, unsigned motion, unsigned ticks)
{
    if (kong > 3 || motion < 6 || motion > 10) return nullptr;
    const auto& sequence = JourneyCarrySequences[kong][motion - 6];
    unsigned duration = 0;
    for (unsigned i = 0; i < sequence.count; ++i) duration += JourneyCarrySteps[sequence.first + i].duration;
    if (motion == J_PICKUP || motion == J_THROW) ticks = std::min(ticks, duration - 1);
    else ticks %= duration;
    for (unsigned i = 0; i < sequence.count; ++i)
    {
        const auto& step = JourneyCarrySteps[sequence.first + i];
        if (ticks < step.duration) return &step;
        ticks -= step.duration;
    }
    return nullptr;
}

static unsigned JourneyHostPoseHeader(const JourneyActor& actor, unsigned slot)
{
    const unsigned poseAddress = Journey.page == 1 ? 0xd11 + actor.base : actor.base + (Journey.page == 2 ? 0x1a : 0x24);
    const int queuedPose = JourneyRenderHostPose(slot);
    const unsigned pose = queuedPose >= 0 ? unsigned(queuedPose) : READ_WORD(Memory.RAM + poseAddress);
    const unsigned gameOffset = 0x10000 + (Journey.page - 1) * 0x400000;
    const unsigned table = gameOffset + (Journey.page == 1 ? 0x3bcc9c : 0x3c8000);
    if (table + pose + 3 > Journey.cartridge.size()) return ~0u;
    const uint8_t* entry = Journey.cartridge.data() + table + pose;
    return gameOffset + ((entry[0] | (entry[1] << 8) | (entry[2] << 16)) & 0x3fffff);
}
#endif
