#include "snes9x.h"
#include "memmap.h"
#include "journey.h"
#include "journey_native_carry.h"
#include <algorithm>

struct JourneyCarryClock
{
    unsigned animation = ~0u;
    unsigned elapsed = 0;
    unsigned progress = 0;
    unsigned timer = 0, script = 0;
};
static JourneyCarryClock clocks[2];
static int renderPoses[2] = {-1, -1};

void JourneyResetCarryClocks()
{
    renderPoses[0] = renderPoses[1] = -1;
    clocks[0] = JourneyCarryClock();
    clocks[1] = JourneyCarryClock();
}

// Stretch the host script on each side of its release callback. Native object
// creation/throw code still runs; the selected Kong determines when it runs.
static unsigned JourneyWarpCarryTime(unsigned tick, const JourneyCarryTiming& host,
                                     const JourneyCarryTiming& donor, bool throwing)
{
    tick = std::min(tick, donor.duration);
    if (!throwing)
        return tick * host.duration * 256 / donor.duration;
    if (tick <= donor.release)
        return tick * host.release * 256 / donor.release;
    return host.release * 256 + (tick - donor.release) * (host.duration - host.release) * 256 /
        (donor.duration - donor.release);
}

void JourneyUpdateCarryClocks(const JourneyActor (&actors)[2])
{
    for (unsigned slot = 0; slot < 2; ++slot)
    {
        const auto& actor = actors[slot];
        auto& clock = clocks[slot];
        // The PPU draws the pose queued by the preceding logic frame.
        const unsigned poseAddress = Journey.page == 1 ? 0xd11 + actor.base : actor.base + (Journey.page == 2 ? 0x1a : 0x24);
        renderPoses[slot] = actor.present ? READ_WORD(Memory.RAM + poseAddress) : -1;
        int action = -1;
        if (actor.present && actor.kong != actor.original)
        {
            const unsigned animation = actor.animation - (Journey.page == 1 ? (actor.original == J_DIDDY ? 0x68 : 0) :
                Journey.page == 2 ? (actor.original == J_DIXIE ? 0xa3 : 0) : (actor.original == J_KIDDY ? 0x87 : 0));
            if (animation == (Journey.page == 1 ? 0x47u : Journey.page == 2 ? 0x0fu : 0x10u)) action = 0;
            if (animation == (Journey.page == 1 ? 0x4au : Journey.page == 2 ? 0x14u : 0x15u)) action = 1;
        }
        if (action < 0)
        {
            clock = JourneyCarryClock();
            continue;
        }
        const unsigned timerAddress = Journey.page == 1 ? 0x1105 + actor.base : actor.base + (Journey.page == 2 ? 0x38 : 0x42);
        const unsigned scriptAddress = Journey.page == 1 ? 0x116d + actor.base : actor.base + (Journey.page == 2 ? 0x3c : 0x46);
        const unsigned timer = READ_WORD(Memory.RAM + timerAddress), script = READ_WORD(Memory.RAM + scriptAddress);
        if (clock.animation != actor.animation)
        {
            clock = JourneyCarryClock();
            clock.animation = actor.animation;
        }
        else
        {
            // Hitstop and paused gameplay do not consume animation time.
            if (clock.timer == timer && clock.script == script) continue;
            ++clock.elapsed;
        }
        clock.timer = timer;
        clock.script = script;
        const auto& host = JourneyHostTimings[(Journey.page - 1) * 2 + slot][action];
        const auto& donor = JourneyDonorTimings[actor.kong][action];
        const unsigned next = JourneyWarpCarryTime(clock.elapsed + 1, host, donor, action == 1) + 1;
        const unsigned speed = clock.elapsed >= donor.duration ? 0x100 : (next >= clock.progress ? next - clock.progress : 0);
        clock.progress = next;
        const unsigned address = Journey.page == 1 ? 0x1139 + actor.base : actor.base + (Journey.page == 2 ? 0x3a : 0x44);
        WRITE_WORD(Memory.RAM + address, std::min(speed, 0x7fffu));
    }
}

int JourneyCarryElapsed(unsigned slot)
{
    return slot < 2 && clocks[slot].animation != ~0u ? int(clocks[slot].elapsed) : -1;
}

int JourneyRenderHostPose(unsigned slot)
{
    return slot < 2 ? renderPoses[slot] : -1;
}
