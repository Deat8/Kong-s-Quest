#ifndef JOURNEY_GFX_H
#define JOURNEY_GFX_H

#include "journey.h"
#include "journey_map_frames.h"
#include <algorithm>
#include <cstring>
#include "journey_native_gfx.h"

struct JourneyReplacement
{
    const uint8_t* pixels = nullptr;
    int x = 0, y = 0, priority = 0;
    bool flip = false;
    int width = 64, height = 64;
    int originX = 32, originY = 63;
    const JourneyNativeCarryStep* nativeCarry = nullptr;
};

static int JourneyScreenY(const SOBJ& object)
{
    const int y = object.VPos & 255;
    return y >= 240 ? y - 256 : y;
}

static unsigned JourneyPixel(const SOBJ& object, int x, int y, int width)
{
    const int sourceX = object.HFlip ? width - 1 - x : x;
    const int sourceY = object.VFlip ? width - 1 - y : y;
    const int tileRow = ((object.Name & 0xf0) + sourceY / 8 * 16) & 0xf0;
    const int tile = (object.Name & 0x100) | tileRow | (((object.Name & 15) + sourceX / 8) & 15);
    const unsigned address = (PPU.OBJNameBase + tile * 32 + ((tile & 0x100) ? PPU.OBJNameSelect : 0) + (sourceY & 7) * 2) & 65535;
    const int bit = 7 - (sourceX & 7);
    return ((Memory.VRAM[address] >> bit) & 1) |
        (((Memory.VRAM[(address + 1) & 65535] >> bit) & 1) << 1) |
        (((Memory.VRAM[(address + 16) & 65535] >> bit) & 1) << 2) |
        (((Memory.VRAM[(address + 17) & 65535] >> bit) & 1) << 3);
}

static void JourneyBounds(const SOBJ& object, int width, int& left, int& right, int& top, int& bottom)
{
    const int screenY = JourneyScreenY(object);
    for (int y = 0; y < width; ++y)
        for (int x = 0; x < width; ++x)
            if (JourneyPixel(object, x, y, width))
            {
                left = std::min(left, object.HPos + x);
                right = std::max(right, object.HPos + x + 1);
                top = std::min(top, screenY + y);
                bottom = std::max(bottom, screenY + y + 1);
            }
}

static void JourneyPrepareBarrel(const JourneyActor& actor, const JourneyReplacement& player,
                                 int playerLeft, int playerRight, int playerBottom,
                                 JourneyReplacement& barrel, uint16_t (&surface)[4096], bool (&hide)[128],
                                 unsigned motion, unsigned frame, JourneyPose& pose)
{
    if (!actor.held || motion < J_HOLD_IDLE || Journey.cartridge.size() < 0x14200f0)
        return;
    if (player.nativeCarry && !player.nativeCarry->hasGrip)
        return;
    const bool first = Journey.page == 1;
    const bool second = Journey.page == 2;
    const unsigned attributes = first ? READ_WORD(Memory.RAM + 0xc69 + actor.held)
        : READ_WORD(Memory.RAM + actor.held + (second ? 0x12 : 0x1e));
    const unsigned objectX = first ? 0xb19 + actor.held : actor.held + (second ? 6 : 0x12);
    const unsigned objectY = first ? 0xbc1 + actor.held : actor.held + (second ? 10 : 0x16);
    const int dx = static_cast<int16_t>(READ_WORD(Memory.RAM + objectX) - READ_WORD(Memory.RAM + actor.x));
    const int dy = (first ? -1 : 1) * static_cast<int16_t>(READ_WORD(Memory.RAM + objectY) - READ_WORD(Memory.RAM + actor.y));
    const int expectedX = (playerLeft + playerRight) / 2 + dx;
    const int expectedY = playerBottom + dy;
    int indices[16], count = 0;
    int left = 512, right = -512, top = 512, bottom = -512;
    for (int i = 0; i < 128 && count < 16; ++i)
    {
        const auto& object = PPU.OBJ[i];
        if (hide[i] || object.Palette != ((attributes >> 9) & 7) || object.Priority < 2 ||
            (object.Name & 0x1e0) != (attributes & 0x1e0) ||
            std::abs(object.HPos - expectedX) > 44 || std::abs(JourneyScreenY(object) - expectedY) > 52)
            continue;
        JourneyBounds(object, GFX.OBJWidths[i], left, right, top, bottom);
        indices[count++] = i;
    }
    if (!count || right <= left || bottom <= top || right - left > 48 || bottom - top > 48)
        return;
    std::memset(surface, 0, sizeof(surface));
    const int marginX = (64 - (right - left)) / 2;
    const int marginY = (64 - (bottom - top)) / 2;
    for (int index = 0; index < count; ++index)
    {
        const unsigned i = indices[index];
        const auto& object = PPU.OBJ[i];
        const int width = GFX.OBJWidths[i];
        for (int y = 0; y < width; ++y)
            for (int x = 0; x < width; ++x)
            {
                const unsigned colorIndex = JourneyPixel(object, x, y, width);
                if (!colorIndex)
                    continue;
                const int localX = object.HPos + x - left + marginX;
                const int localY = JourneyScreenY(object) + y - top + marginY;
                if (localX < 0 || localX >= 64 || localY < 0 || localY >= 64)
                    continue;
                const uint16_t color = PPU.CGDATA[128 + object.Palette * 16 + colorIndex];
                surface[localY * 64 + localX] = std::max<unsigned>(1,
                    ((color & 31) << 11) | (((color >> 5) & 31) << 6) | ((color >> 10) & 31));
            }
        hide[i] = true;
    }
    const unsigned metadata = 0x1420000 + ((actor.kong * 5 + motion - J_HOLD_IDLE) * 6 + frame) * 2;
    const int actorOriginX = player.x + (player.flip ? player.width - 1 - player.originX : player.originX);
    const int actorOriginY = player.y + player.originY;
    const int visualOffsetX = ((left + right) / 2 - actorOriginX - dx) * (player.flip ? -1 : 1);
    const int visualOffsetY = (top + bottom) / 2 - actorOriginY - dy;
    const int gripX = player.nativeCarry && player.nativeCarry->hasGrip ? player.originX + player.nativeCarry->x + visualOffsetX :
        static_cast<int8_t>(Journey.cartridge[metadata]);
    const int gripY = player.nativeCarry && player.nativeCarry->hasGrip ? player.originY + player.nativeCarry->y + visualOffsetY :
        static_cast<int8_t>(Journey.cartridge[metadata + 1]);
    barrel.pixels = reinterpret_cast<const uint8_t*>(surface);
    barrel.x = player.x + (player.flip ? player.width - 1 - gripX : gripX) - 32;
    barrel.y = player.y + gripY - 32;
    barrel.priority = player.priority;
    pose.carryOffsetX = barrel.x + 32 - (left + right) / 2;
    pose.carryOffsetY = barrel.y + 32 - (top + bottom) / 2;
}

static void PrepareJourneyMapObjects(JourneyReplacement (&players)[2], bool (&hide)[128])
{
    const unsigned active = Journey.activeSlot & 1;
    for (unsigned icon = 0; icon < (Journey.page == 1 ? 2u : 1u); ++icon)
    {
        int left = 512, right = -512, top = 512, bottom = -512;
        int indices[12], count = 0;
        bool flip = false;
        for (int i = 0; i < 128 && count < 12; ++i)
        {
            const auto& object = PPU.OBJ[i];
            bool belongs = false;
            if (Journey.page == 1)
                belongs = object.Palette == 6 && object.Priority == 2 &&
                    (object.Name & 0x1e0) == (icon ? 0x40 : 0);
            else if (Journey.page == 2)
                belongs = i == 127 && object.Palette == 5 && object.Priority >= 2 && object.Name < 32;
            else if (Journey.page == 3)
                belongs = object.Palette == 4 && object.Priority == 3 && (object.Name & 0x1e0) == 0x1a0;
            if (!belongs || JourneyScreenY(object) >= 224 || object.HPos >= 256 || object.HPos < -32)
                continue;
            JourneyBounds(object, GFX.OBJWidths[i], left, right, top, bottom);
            indices[count++] = i;
            flip = object.HFlip;
        }
        if (!count || right <= left || bottom <= top || right - left > 40 || bottom - top > 40)
            continue;
        for (int i = 0; i < count; ++i)
            hide[indices[i]] = true;
        const unsigned slot = icon ? active ^ 1 : active;
        const unsigned kong = (Journey.team >> (slot * 2)) & 3;
        const unsigned frame = (Journey.pad & 0xf0) ? (Journey.animation / 5) % (kong == J_DONKEY ? 10 : 8) : 0;
        auto& out = players[icon];
        out.pixels = reinterpret_cast<const uint8_t*>(JourneyMapFrames[kong][frame]);
        out.x = (left + right) / 2 - 32;
        out.y = bottom - 63;
        out.priority = PPU.OBJ[indices[0]].Priority;
        out.flip = flip;
    }
}

static void PrepareJourneyObjects(JourneyReplacement (&players)[2], JourneyReplacement (&barrels)[2],
                                  uint16_t (&barrelPixels)[2][4096], bool (&hide)[128])
{
    if (Journey.isMap())
    {
        PrepareJourneyMapObjects(players, hide);
        return;
    }
    JourneyActor actors[2];
    JourneyActors(actors);
    for (unsigned a = 0; a < 2; ++a)
    {
        const auto& actor = actors[a];
        if (!actor.present || actor.kong == actor.original)
            continue;
        const int mask = Journey.page == 1 ? 0x1c0 : 0x1e0;
        const int base = actor.attributes & mask;
        const int palette = (actor.attributes >> 9) & 7;
        int anchor = -1;
        for (int i = 0; i < 128; ++i)
        {
            const auto& object = PPU.OBJ[i];
            if (object.Name == base && object.Palette == palette && object.Priority >= 2 &&
                object.HPos > -48 && object.HPos < 256 &&
                JourneyScreenY(object) + GFX.OBJWidths[i] > 0 && JourneyScreenY(object) < 224)
            {
                anchor = i;
                break;
            }
        }
        if (anchor < 0)
            continue;
        int left = 512, right = -512, top = 512, bottom = -512;
        int matches[24], count = 0;
        for (int i = 0; i < 128 && count < 24; ++i)
        {
            const auto& object = PPU.OBJ[i];
            if (object.Priority < 2 || object.Palette != palette || (object.Name & mask) != base ||
                std::abs(object.HPos - PPU.OBJ[anchor].HPos) > 43 ||
                std::abs(JourneyScreenY(object) - JourneyScreenY(PPU.OBJ[anchor])) > 48)
                continue;
            JourneyBounds(object, GFX.OBJWidths[i], left, right, top, bottom);
            matches[count++] = i;
        }
        if (!count || right <= left || bottom <= top || right - left > 72 || bottom - top > 72)
            continue;
        const auto& pose = Journey.poses[a];
        auto& out = players[a];
        out.pixels = JourneyFrame(actor.kong, pose.motion, pose.frame);
        if (!out.pixels)
            continue;
        for (int i = 0; i < count; ++i)
            hide[matches[i]] = true;
        out.x = (left + right) / 2 - 32;
        out.y = bottom - 63;
        out.priority = PPU.OBJ[anchor].Priority;
        out.flip = PPU.OBJ[anchor].HFlip;
        const auto* nativeStep = JourneyCarryStep(actor.kong, pose.motion, pose.ticks);
        if (nativeStep)
        {
            static JourneyDecodedPose nativePlayers[2], hostPlayers[2];
            if (JourneyDecodePose(nativeStep->header, JourneyCarryPalettes[actor.kong], nativePlayers[a]) &&
                JourneyDecodePose(JourneyHostPoseHeader(actor, a), JourneyCarryPalettes[actor.original], hostPlayers[a]))
            {
                const auto& host = hostPlayers[a];
                const int originX = left - (out.flip ? -host.right : host.left);
                const int originY = bottom - host.bottom - 1;
                out.width = out.height = 128;
                out.originX = 64;
                out.originY = 96;
                out.pixels = reinterpret_cast<const uint8_t*>(nativePlayers[a].pixels);
                out.x = originX - (out.flip ? 63 : 64);
                out.y = originY - 96;
                out.nativeCarry = nativeStep;
            }
        }
        JourneyPrepareBarrel(actor, out, left, right, bottom, barrels[a], barrelPixels[a], hide, pose.motion, pose.frame, Journey.poses[a]);
    }
}

static void DrawJourneyObjectLine(const JourneyReplacement& object, int y, int offset, int depth, int pixelWidth)
{
    const int row = y - object.y;
    if (!object.pixels || row < 0 || row >= object.height)
        return;
    for (int column = 0; column < object.width; ++column)
    {
        const int x = object.x + column;
        if (x < 0 || x >= 256)
            continue;
        const uint16_t source = READ_WORD(object.pixels + 2 * (row * object.width + (object.flip ? object.width - 1 - column : column)));
        if (!source)
            continue;
        int clip = 0;
        for (; clip < GFX.Clip[4].Count; ++clip)
            if (x >= GFX.Clip[4].Left[clip] && x < GFX.Clip[4].Right[clip])
                break;
        if (clip == GFX.Clip[4].Count || !GFX.Clip[4].DrawMode[clip])
            continue;
        const int light = (GFX.Clip[4].DrawMode[clip] & 1) ? PPU.Brightness : 0;
        const uint16_t color = (((source >> 11) * light / 15) << 11) |
            ((((source >> 5) & 63) * light / 15) << 5) | ((source & 31) * light / 15);
        for (int subpixel = 0; subpixel < pixelWidth; ++subpixel)
        {
            const int index = offset + x * pixelWidth + subpixel;
            if (GFX.DB[index] < 2)
            {
                GFX.S[index] = color;
                GFX.DB[index] = depth + object.priority * 4;
            }
        }
    }
}
// Recompose held objects after the original game's raster effects. DKC2 can
// disable OBJ in its sky band, which otherwise clips an overhead DK barrel.
void JourneyFinishFrame(int width, int height)
{
    if (!Journey.enabled() || !Journey.page || Journey.boot || width != 256)
        return;
    JourneyReplacement players[2], barrels[2];
    uint16_t barrelPixels[2][4096];
    bool hidden[128] = {};
    PrepareJourneyObjects(players, barrels, barrelPixels, hidden);
    for (unsigned actor = 0; actor < 2; ++actor)
    {
        const auto& barrel = barrels[actor];
        const auto& player = players[actor];
        if (!barrel.pixels)
            continue;
        const unsigned kong = (Journey.team >> (actor * 2)) & 3;
        const bool overhead = kong == J_DONKEY || kong == J_DIXIE;
        for (int row = 0; row < 64; ++row)
            for (int column = 0; column < 64; ++column)
            {
                const int x = barrel.x + column, y = barrel.y + row;
                if (x < 0 || x >= width || y < 0 || y >= height)
                    continue;
                const uint16_t source = READ_WORD(barrel.pixels + 2 * (row * 64 + column));
                if (!source)
                    continue;
                const int px = x - player.x, py = y - player.y;
                if (overhead && px >= 0 && px < player.width && py >= 0 && py < player.height && player.pixels &&
                    READ_WORD(player.pixels + 2 * (py * player.width + (player.flip ? player.width - 1 - px : px))))
                    continue;
                const unsigned index = y * (GFX.Pitch / 2) + x;
                if (GFX.ZBuffer[index] > 48)
                    continue;
                const unsigned light = PPU.Brightness;
                GFX.Screen[index] = (((source >> 11) * light / 15) << 11) |
                    ((((source >> 5) & 63) * light / 15) << 5) | ((source & 31) * light / 15);
            }
    }
}
#endif
