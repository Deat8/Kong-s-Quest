#include "snes9x.h"
#include "memmap.h"
#include "controls.h"
#include "journey.h"
#include <algorithm>
#include <cstring>
#include <cstdlib>

JourneyRuntime Journey;
static uint16_t word(unsigned address) { return READ_WORD(Memory.RAM + address); }

unsigned JourneyRuntime::cleared() const
{
    return std::memcmp(battery + 0x1800, "DKCJ", 4) == 0 ? std::min<unsigned>(battery[0x1804], 3) : 0;
}

bool JourneyRuntime::isMap() const
{
    if (page == 1)
        return word(0x3e) >= 0xe6 && word(0x3e) <= 0xed;
    if (page == 2)
        return word(0x20) == 0x8ce9 || word(0x20) == 0x8cf1;
    return page == 3 && word(0x4e) == 0xb179;
}

void JourneyRuntime::saveBattery()
{
    if (page)
        std::memcpy(battery + (page - 1) * 0x800, Memory.SRAM, 0x800);
}

bool JourneyRuntime::loadPage(unsigned nextPage)
{
    if (nextPage > 3 || !enabled())
        return false;
    saveBattery();
    page = nextPage;
    requested = 0;
    boot = page ? 1 : 0;
    ending = 0;
    exitStable = 0;
    victoryStable = 0;
    armed = false;
    animation = 0;
    activeSlot = 0;
    JourneyResetCarryClocks();
    poses[0] = {};
    poses[1] = {};
    const unsigned offset = page ? 0x10000 + (page - 1) * 0x400000 : 0;
    const unsigned size = page ? 0x400000 : 0x10000;
    if (!Memory.LoadROMMem(cartridge.data() + offset, size, "Jornada"))
        return false;
    if (!JourneyInstallCharacterRules())
        return false;
    Memory.ClearSRAM();
    if (page)
        std::memcpy(Memory.SRAM, battery + (page - 1) * 0x800, 0x800);
    Memory.FillRAM[0x5ff0] = page;
    Memory.FillRAM[0x5ff1] = team;
    battery[0x1805] = page;
    return true;
}

void JourneyRuntime::update()
{
    if (!page || boot)
        return;
    saveBattery();
    if (page == cleared() + 1)
    {
        // A scene transition may momentarily reuse the victory address.
        // A chapter completes only after a newly observed, sustained signal.
        const uint8_t* end = cartridge.data() + 0x7f10 + (page - 1) * 4;
        const bool won = (word(READ_WORD(end)) & READ_WORD(end + 2)) != 0;
        if (!won)
        {
            armed = true;
            victoryStable = 0;
        }
        else if (armed)
        {
            victoryStable = std::min(victoryStable + 1, 8u);
            if (victoryStable == 8)
            {
                std::memcpy(battery + 0x1800, "DKCJ", 4);
                battery[0x1804] = page;
            }
        }
    }
    if (page > cleared() || page >= 3)
    {
        ending = 0;
        exitStable = 0;
        return;
    }

    // Finish the ending sequence; only switch after the title/map is stable.
    ending = std::min(ending + 1, 180u);
    const bool title = page == 1 ? word(0x3e) == 0 && word(0x521) == 9 : word(0x20) == 0xb461;
    exitStable = isMap() || title ? std::min(exitStable + 1, 30u) : 0;
    if ((ending == 180 && exitStable >= 30) || (pad & 0xc08) == 0xc08)
        requested = page + 1;
}

void JourneyActors(JourneyActor (&actors)[2])
{
    if (!Journey.enabled() || !Journey.page || Journey.boot)
        return;
    uint8_t native[2] = {J_DONKEY, J_DIDDY};
    if (Journey.page == 2)
        native[0] = J_DIDDY, native[1] = J_DIXIE;
    if (Journey.page == 3)
        native[0] = J_DIXIE, native[1] = J_KIDDY;
    for (unsigned slot = 0; slot < 2; ++slot)
    {
        auto& actor = actors[slot];
        actor.kong = (Journey.team >> (slot * 2)) & 3;
        actor.original = native[slot];
        if (Journey.page == 1)
        {
            if (!(word(0x1e15) & 0x40))
                continue;
            for (unsigned i = 2; i < 0x34; i += 2)
            {
                if (word(0xd45 + i) != slot + 1)
                    continue;
                actor.base = i;
                actor.attributes = word(0xc69 + i);
                actor.x = 0xb19 + i;
                actor.y = 0xbc1 + i;
                actor.vx = 0xe89 + i;
                actor.vy = 0xef1 + i;
                actor.animation = word(0x10d1 + i);
                actor.active = word(0x56f) == slot + 1;
                actor.present = true;
                // Grabbed objects keep the owner actor index in table 1375.
                for (unsigned object = 6; object < 0x34; object += 2)
                    if (word(0xd45 + object) >= 0x22 && word(0xd45 + object) <= 0x27 && word(0x1375 + object) == i &&
                        (word(0x1029 + object) == 1 || word(0x1029 + object) == 6))
                        actor.held = object;
                break;
            }
        }
        else
        {
            const bool second = Journey.page == 2;
            const unsigned base = second ? (slot ? 0xe40 : 0xde2) : (slot ? 0x8e6 : 0x878);
            if (word(base) != (second ? (slot ? 0xe8 : 0xe4) : (slot ? 0x230 : 0x22c)))
                continue;
            if (second && word(0x20) != 0x8608)
                continue;
            actor.base = base;
            actor.attributes = word(base + (second ? 0x12 : 0x1e));
            actor.x = base + (second ? 6 : 0x12);
            actor.y = base + (second ? 10 : 0x16);
            actor.vx = base + (second ? 0x20 : 0x2a);
            actor.vy = base + (second ? 0x24 : 0x2e);
            actor.animation = word(base + (second ? 0x36 : 0x40));
            actor.active = word(second ? 0x593 : 0x4f9) == base;
            actor.present = true;
            const unsigned held = word(second ? 0xd7a : 0x186b);
            if (actor.active && held >= 0x600u && held < 0x2000 &&
                word(held) != (second ? 0xe4 : 0x22c) && word(held) != (second ? 0xe8 : 0x230))
                actor.held = held;
        }
    }
}

void JourneyUpdatePoses(unsigned previousPad)
{
    JourneyActor actors[2];
    JourneyActors(actors);
    JourneyUpdateCarryClocks(actors);
    for (unsigned slot = 0; slot < 2; ++slot)
    {
        const auto& actor = actors[slot];
        auto& pose = Journey.poses[slot];
        if (actor.present && actor.active)
            Journey.activeSlot = slot;
        if (!actor.present || actor.kong == actor.original)
        {
            pose = {};
            continue;
        }
        if (pose.held && !actor.held)
        {
            const unsigned object = pose.held;
            const unsigned objectID = Journey.page == 1 ? word(0xd45 + object) : word(object);
            if (objectID)
            {
                const unsigned xAddress = Journey.page == 1 ? 0xb19 + object : object + (Journey.page == 2 ? 6 : 0x12);
                const unsigned yAddress = Journey.page == 1 ? 0xbc1 + object : object + (Journey.page == 2 ? 10 : 0x16);
                WRITE_WORD(Memory.RAM + xAddress, word(xAddress) + pose.carryOffsetX);
                WRITE_WORD(Memory.RAM + yAddress, word(yAddress) + pose.carryOffsetY * (Journey.page == 1 ? -1 : 1));
            }
            pose.carryOffsetX = pose.carryOffsetY = 0;
        }
        pose.held = actor.held;
        const uint16_t x = word(actor.x), y = word(actor.y);
        const int dx = std::abs(static_cast<int16_t>(x - pose.x));
        const int down = Journey.page == 1 ? -1 : 1;
        const int dy = down * static_cast<int16_t>(y - pose.y);
        const int vy = down * static_cast<int16_t>(word(actor.vy));
        if (!pose.valid || dx > 32 || std::abs(dy) > 32)
        {
            pose = {};
            pose.x = x;
            pose.y = y;
            pose.valid = true;
            continue;
        }
        pose.x = x;
        pose.y = y;
        pose.quiet = dy == 0 ? std::min(pose.quiet + 1, 3) : 0;
        pose.descent = dy > 0 ? std::min(pose.descent + 1, 3) : 0;
        const bool wasAirborne = pose.airborne;
        if ((dy <= -2 && vy < 0) || (dy >= 3 && pose.descent >= 2 && vy >= 0x200))
            pose.airborne = true;
        if (pose.quiet >= 2 && vy >= 0x200)
            pose.airborne = false;
        const int vx = std::abs(static_cast<int16_t>(word(actor.vx)));
        unsigned motion = vx > 0x80 && dx > 0 ? J_RUN : J_IDLE;
        if (pose.airborne)
        {
            motion = J_JUMP;
            if (actor.active && actor.kong == J_DIXIE && (Journey.pad & 2) &&
                dy >= 0 && vy >= 0x100 && vy <= 0x200)
                motion = J_GLIDE;
        }
        else if ((actor.active && (Journey.pad & ~previousPad & 2) && ((Journey.pad & 0xc0) || vx >= 0x180)) ||
                 (pose.motion == J_ROLL && pose.ticks < 22 && (dx > 0 || pose.ticks < 5)))
            motion = J_ROLL;
        else if (wasAirborne)
            motion = J_JUMP;

        if (actor.held)
            motion = pose.airborne ? J_HOLD_JUMP : (dx > 0 ? J_HOLD_WALK : J_HOLD_IDLE);
        if (Journey.page == 1)
        {
            const unsigned nativeAnimation = actor.animation - (actor.original == J_DIDDY ? 0x68 : 0);
            if (nativeAnimation == 0x47)
                motion = J_PICKUP;
            if (nativeAnimation == 0x4a)
                motion = J_THROW;
        }
        else if (Journey.page == 2)
        {
            const unsigned animation = actor.animation - (actor.original == J_DIXIE ? 0xa3 : 0);
            if (animation == 0xf)
                motion = J_PICKUP;
            if (animation == 0x14 || animation == 0x13)
                motion = J_THROW;
        }
        if (Journey.page == 3)
        {
            const unsigned animation = actor.animation - (actor.original == J_KIDDY ? 0x87 : 0);
            if (animation == 0x10)
                motion = J_PICKUP;
            if (animation == 0x14 || animation == 0x15)
                motion = J_THROW;
        }
        if (motion != pose.motion || (motion == J_JUMP && !wasAirborne))
        {
            pose.ticks = 0;
            pose.stride = 0;
        }
        else
            pose.ticks = (pose.ticks + 1) % 1440;
        const int nativeCarryElapsed = JourneyCarryElapsed(slot);
        if ((motion == J_PICKUP || motion == J_THROW) && nativeCarryElapsed >= 0)
            pose.ticks = nativeCarryElapsed;
        pose.motion = motion;
        if (motion == J_RUN || motion == J_HOLD_WALK)
        {
            pose.stride = (pose.stride + dx) % 36;
            pose.frame = pose.stride / 6;
        }
        else if (motion == J_JUMP || motion == J_HOLD_JUMP)
        {
            if (!pose.airborne)
                pose.frame = 5;
            else if (!wasAirborne && dy < 0)
                pose.frame = 0;
            else if (vy < -0x200)
                pose.frame = 1;
            else if (vy <= 0x100)
                pose.frame = 2;
            else
                pose.frame = vy > 0x400 ? 4 : 3;
        }
        else if (motion == J_PICKUP || motion == J_THROW)
            pose.frame = std::min(pose.ticks / 3, 5);
        else
            pose.frame = (pose.ticks / (motion == J_IDLE ? 12 : 4)) % 6;

        if (actor.active && pose.airborne && actor.kong == J_DIXIE && !actor.held && (Journey.pad & 2) && vy > 0x180 && vy < 0x600)
            WRITE_WORD(Memory.RAM + actor.vy, 0x180 * down);
    }
}

const uint8_t* JourneyFrame(unsigned kong, unsigned motion, unsigned frame)
{
    if (motion < 6)
        return Journey.cartridge.data() + 0x1210000 + ((kong * 6 + motion) * 6 + frame) * 8192;
    const unsigned offset = 0x1330000 + ((kong * 5 + motion - 6) * 6 + frame) * 8192;
    return offset + 8192 <= Journey.cartridge.size() ? Journey.cartridge.data() + offset : nullptr;
}
