#ifndef JOURNEY_H
#define JOURNEY_H

#include <vector>
#include <cstdint>

struct JourneyActor
{
    uint16_t attributes = 0;
    uint16_t x = 0, y = 0, vx = 0, vy = 0, animation = 0, base = 0;
    uint16_t held = 0;
    uint8_t kong = 0, original = 0;
    bool active = false, present = false;
};

struct JourneyPose
{
    uint16_t x = 0, y = 0;
    uint8_t motion = 0, frame = 0;
    int stride = 0, ticks = 0, quiet = 0, descent = 0;
    bool valid = false, airborne = false;
    uint16_t held = 0;
    int carryOffsetX = 0, carryOffsetY = 0;
};

enum JourneyMotion { J_IDLE, J_RUN, J_JUMP, J_ROLL, J_GLIDE, J_SWIM,
                     J_HOLD_IDLE, J_HOLD_WALK, J_PICKUP, J_THROW, J_HOLD_JUMP };
enum JourneyKong { J_DONKEY, J_DIDDY, J_DIXIE, J_KIDDY };

struct JourneyRuntime
{
    std::vector<uint8_t> cartridge;
    uint8_t battery[8192] = {};
    unsigned page = 0, requested = 0, team = 4, pad = 0;
    unsigned boot = 0, ending = 0, animation = 0;
    bool armed = false;
    JourneyPose poses[2];
    unsigned activeSlot = 0;
    unsigned exitStable = 0, victoryStable = 0, manualAdvanceHeld = 0;
    bool enabled() const { return !cartridge.empty(); }
    unsigned cleared() const;
    bool isMap() const;
    bool loadPage(unsigned page);
    void saveBattery();
    void update();
};
extern JourneyRuntime Journey;
bool JourneyInstallCharacterRules();
uint16_t JourneyRoleComparison(unsigned port);
void JourneyActors(JourneyActor (&actors)[2]);
void JourneyUpdatePoses(unsigned previousPad);
void JourneyUpdateCarryClocks(const JourneyActor (&actors)[2]);
void JourneyResetCarryClocks();
int JourneyCarryElapsed(unsigned slot);
int JourneyRenderHostPose(unsigned slot);
void JourneyFinishFrame(int width, int height);
const uint8_t* JourneyFrame(unsigned kong, unsigned motion, unsigned frame);

#endif
