# Integração em andamento — 11/11/2026

## Cartucho nativo de DKC1

O código em `project/native` gera uma ROM ExHiROM de 8 MiB. A seleção, o salvamento da dupla, o desenho dos Kongs e as regras de jogo são executados no SNES emulado. O cartucho importa gráficos originais dos outros jogos para DKC1. Consulte `project/native/LEIA-ME.md` para compilar e reproduzir os testes em Snes9x e bsnes.

O mapa da ilha e os seis mapas de fases desenham os Kongs da dupla e preservam as cores dos demais elementos de DKC1. Rambi, Expresso, Winky e Enguarde usam os gráficos originais dos animais e os quadros do Kong montado. Dixie e Kiddy passaram no teste de montaria, deslocamento e desmontagem no Snes9x. A troca de liderança usa os quadros originais de cada personagem quando há uma animação correspondente. Os efeitos de dano de Dixie e Kiddy foram portados de DKC3 para o motor de áudio do cartucho nativo e testados nas duas posições da dupla.

O pisão de Dixie e Kiddy usa os quadros, o impulso e a desaceleração do quique original de DKC3. O primeiro quadro ao tomar dano vem do script de dano de cada um. A voz de dano é selecionada pelo Kong atingido, e o Gnawty conserva seu efeito original. O perfil de velocidade vertical do salto normal segue o Kong selecionado. Dixie e Kiddy foram testados em Jungle Hijinxs nas duas posições.

Seguem pendentes a progressão DKC1 → DKC2 → DKC3 na mesma ROM, os demais efeitos exclusivos de Dixie e Kiddy e a fidelidade de todas as ações e animações.

## Mapeamento para a campanha

Os três jogos originais somam 12 MiB. O ExHiROM atual endereça até 8 MiB. Um teste com uma ROM de 12 MiB e mapeamento S-DD1 leu páginas de 1 MiB numeradas 0, 4 e 8 pelo registrador `$4804`. O bsnes leu as três páginas e o Snes9x leu a página 0 no lugar da 8. Os núcleos usados são os mesmos listados em `project/native/LEIA-ME.md`.

A compactação LZMA de blocos de 64 KiB dos três jogos produziu 8.312.480 bytes antes das modificações do projeto. Usar compactação no cartucho exige manter o código executável acessível e adaptar o carregamento dos dados. A passagem entre capítulos segue pendente no cartucho nativo.

## Histórico do leitor — 10/11/2026

O leitor 4.5 experimental introduziu alterações de gráficos de carregamento usando o arquivo SFC 4.3.

## Arquitetura e limitação principal

O arquivo SFC é um contêiner dos três jogos, interpretado pelo núcleo Snes9x modificado. A campanha, a seleção e as substituições gráficas dependem desse núcleo. Não é uma ROM SNES independente que implemente essas funções no hardware ou em um emulador comum.

## Sincronização de ações — 4.5 experimental

- Novo controlador `work/core/journey_carry_clock.cpp`. Ele ajusta o avanço do script nativo de pegada e arremesso ao personagem selecionado. No arremesso, sincroniza separadamente o trecho anterior e o posterior ao callback que solta o objeto.
- Foram extraídos tempos dos seis personagens nativos dos três motores (DK/Diddy em DKC1, Diddy/Dixie em DKC2, Dixie/Kiddy em DKC3), além dos quatro conjuntos usados como referência dos personagens selecionados.
- O relógio acompanha mudanças reais do timer e do ponteiro de animação. Pausas por impacto não consomem o tempo do personagem desenhado.
- A origem usada para posicionar o personagem passou a considerar a pose enfileirada no quadro lógico anterior, que corresponde aos tiles realmente exibidos pela PPU. A comparação de pixels verifica essa defasagem explicitamente.
- `test_carry_timing.py`: mede o objeto efetivamente deixando de estar preso à mão e o fim do arremesso. Nos 12 casos do espaço principal (quatro personagens × três motores), ambos ficaram a até um tick lógico dos valores de referência. O tempo de parede inclui pausas por impacto e é registrado separadamente.
- `test_pickup_timing.py`: os quatro personagens completaram a pegada em DKC3 com a duração de referência, com diferença máxima de um tick, mantendo o objeto.
- Regressões dos cenários de barris dos três capítulos, correspondência de pixels das poses nativas e seleção/progressão da campanha passaram no núcleo Linux.

### Limites desta etapa

O controlador ainda executa os callbacks do motor hospedeiro. O instante de registro do objeto como segurado durante a pegada e o percurso do objeto nos quadros iniciais sem encaixe explícito não foram transplantados do personagem de referência. O movimento completo, os efeitos sonoros, soltar no chão, situações de água, interrupções especiais e a sincronização no espaço de parceiro ainda precisam de integração e testes. Estados salvos externos durante uma ação não têm o relógio adicional serializado. O aplicativo salva a bateria da campanha, sem estados instantâneos.

## Gráficos de carregamento — 4.4 experimental

- Extrator `project/extract_native_carry.py`: 166 etapas em 20 sequências dos quatro personagens, com gráficos, duração e deslocamentos do objeto vindos dos scripts originais.
- Decodificação do formato nativo de tiles, incluindo as duas fileiras dos blocos grandes e os grupos adicionais de tiles pequenos. A extração não redimensiona nem recorta pixels dos quadros extraídos.
- Área de desenho de 128×128 para acomodar os quadros largos de arremesso. O personagem conserva suas dimensões originais.
- O desenho de carregamento usa os pixels diretamente dos jogos já contidos no SFC. O posicionamento utiliza a origem do quadro original e o deslocamento do objeto, incluindo o deslocamento visual do próprio barril.
- `test_native_carry_pixels.py`: o decodificador foi comparado aos índices de paleta produzidos pela PPU original em oito capturas de cada motor, usando DK em DKC1, Diddy em DKC2 e Dixie em DKC3. Os quadros da PPU podem atrasar em relação à variável de pose na RAM; o teste procura a correspondência no conjunto original de poses de carregamento e exige que a pose do quadro lógico anterior corresponda aos tiles exibidos. Kiddy foi conferido visualmente e pelo extrator, sem comparação direta com a PPU nativa de Kiddy.
- Regressões de segurar, caminhar, virar e arremessar com os quatro personagens nos cenários de barris dos três capítulos passaram no núcleo Linux. As quatro miniaturas nos três mapas iniciais também passaram.
- APK ARM64 compilado e assinatura verificada. Não foi instalado nem testado em um aparelho Android nesta etapa.

### Limitações específicas

A seleção da ação ainda vem do motor hospedeiro. A versão 4.5 acrescenta sincronização da duração de pegada e do instante de soltura no arremesso. Ela não transplanta todos os callbacks, colisões e velocidades dinâmicas do personagem original. A troca entre ações com barril e as demais animações ainda pode apresentar diferença visual. Soltar o objeto no chão e arremessá-lo ainda compartilham uma classificação visual simplificada. Portanto, este avanço não equivale a animações idênticas em todas as ações.

## Implementado na etapa anterior

- Miniaturas de DK, Diddy, Dixie e Kiddy extraídas diretamente dos gráficos e paletas originais. Quadros sem redimensionamento em `work/core/journey_map_frames.h`.
- Substituição das miniaturas nos mapas dos três capítulos. Acompanhamento do espaço ativo durante a fase em `Journey.activeSlot`.
- Comparações de peso em DKC1: elegibilidade de pisão, resposta de quique e seleção de caixa de colisão. DK/Kiddy usam a classe pesada, Diddy/Dixie a leve, independentemente do espaço original ocupado.
- Seleção da tabela de resposta a golpes de DKC3 segundo a mesma classe de peso.
- Identificação de assinaturas de código antes de aplicar alterações. A aplicação é atômica: nenhum byte é alterado se qualquer assinatura necessária estiver ausente ou duplicada.

## Verificado no núcleo Linux

- `test_character_roles.py`: execução real de CPX no emulador, verificando as portas de comparação para os quatro personagens em ambos os espaços, em DKC1 e DKC3. Não substitui testes integrados com inimigos.
- `test_map_characters.py`: quatro imagens distintas da miniatura em cada um dos três mapas iniciais, sem mudanças fora da região dos ícones. Outros mapas, veículos e retorno após troca ainda não foram validados.
- `test_campaign.py`: 12 duplas, exclusão de duplicatas, condições simuladas de conclusão e retomada da campanha.
- `test_carry_render.py`: regressão dos quatro personagens no cenário de barril preservado de DKC1.

## Pendente para atender ao pedido

- Portar todas as animações originais de cada personagem, com sequências, temporização, colisões e alinhamento corretos. As ações fora de carregamento ainda usam o atlas aproximado de seis quadros por movimento da versão 4.3.
- Portar a física completa, incluindo movimento, salto, água, cordas, ações especiais e interação com inimigos. A alteração da classe de peso não resolve toda a física.
- Regras para personagens pesados no motor de DKC2.
- Sons próprios de cada personagem. Nenhuma alteração de áudio foi implementada.
- Testes integrados com os inimigos relevantes, todos os mundos, estados de mapa, troca de personagem e aparelho Android.

## Reproduzir

O fluxo de compilação permanece em `project/LEIA-ME.md`. Para os testes desta etapa, gere primeiro o contêiner com `python3 project/build_carry_atlas.py`, compile o núcleo com `make -s -j6 -C work/core/libretro` e execute os testes descritos acima.

`project/extract_native_map_sprites.py` regenera o cabeçalho de miniaturas. Foram incluídos os arquivos necessários das desmontagens de referência de Yoshifanatic1 (repositórios Donkey-Kong-Country-1-Disassembly, Donkey-Kong-Country-2-Disassembly e Donkey-Kong-Country-3-Disassembly no GitHub). Os dados gráficos vêm dos jogos já fornecidos pelo usuário.
