from pathlib import Path
from struct import pack_into, unpack_from
from zlib import crc32
import hashlib

ROOT = Path(__file__).resolve().parent
src = ROOT / 'recovered/Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc'
dst = Path('/mnt/data/Donkey-Kong-Country-Kongs-Quest-Campanha-Unica-Emulador-Proprio.sfc')
rom = bytearray(src.read_bytes())
assert len(rom) == 0x1330000 and rom[0x7f00:0x7f0f] == b'DKCJOURNEY-MMC5'
orig = bytes(rom)
base = 0x8a00

def write_menu_row(row, text, palette):
    assert len(text) <= 32
    offset = base + row * 64
    # Preserve reserved tiles and clear old contents by writing a centered row.
    for col in range(32):
        pack_into('<H', rom, offset + col * 2, 0)
    x = (32 - len(text)) // 2
    for i, letter in enumerate(text):
        pack_into('<H', rom, offset + (x + i) * 2, ord(letter) | (palette << 10))

# The original boot program DMA-copies this tilemap to BG VRAM at $2000.
assert b''.join(bytes((ord(c),4)) for c in 'A GRANDE JORNADA') in rom[base + 3*64:base+4*64]
assert b''.join(bytes((ord(c),8)) for c in 'MONTE SUA DUPLA') in rom[base + 6*64:base+7*64]
write_menu_row(3, 'DONKEY KONG COUNTRY', 1)
write_menu_row(6, "KONG'S QUEST", 2)
# Keep LIDER / PARCEIRO and all original key prompts untouched.
# Internal SNES header only describes the boot loader, not the three embedded ROMs.
header = b"DKC: KONG'S QUEST".ljust(21, b' ')
assert rom[0xffc0:0xffc4] == b'DKC '
rom[0xffc0:0xffd5] = header
# SNES checksum is informational for this custom-format container.
rom[0xffdc:0xffe0] = (0xffff).to_bytes(2, 'little') + (0).to_bytes(2, 'little')
checksum = sum(rom[:0x10000]) & 0xffff
rom[0xffdc:0xffe0] = (checksum ^ 0xffff).to_bytes(2, 'little') + checksum.to_bytes(2, 'little')
assert rom[0x10000:] == orig[0x10000:]  # Embedded games and animation data unmodified.
assert all(rom[base + row*64:base+(row+1)*64] == orig[base + row*64:base+(row+1)*64]
           for row in (1,10,12,16,18,21,22,24,25,26))

dst.write_bytes(rom)
print('output', dst)
print('bytes',len(rom), 'CRC',hex(crc32(rom)), 'SHA',hashlib.sha256(rom).hexdigest())
print('changed',sum(x!=y for x,y in zip(rom,orig)))
for row in (3,6):
  print('title line',row,repr(''.join(chr(unpack_from('<H',rom,base+row*64+2*c)[0]&0xff) if unpack_from('<H',rom,base+row*64+2*c)[0]&0xff else ' ' for c in range(32)).strip()))
