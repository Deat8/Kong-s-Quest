"""Extract native carry scripts, frames and object offsets without resampling."""
from pathlib import Path
import re,json
import numpy as np
from PIL import Image,ImageDraw
from extract_native_map_sprites import tables,decode_tile
ROOT=Path(__file__).resolve().parents[1]
SPECS=[(1,'DonkeyKong',0x3bcc9c,0x3e8572,2,[0x48,0x49,0x47,0x4a,0x4d],'PAL_Sprite_DonkeyKong_Active'),
       (2,'Diddy',0x3c8000,0x390000,4,[0x10,0x11,0xf,0x14,0x16],'PAL_Sprite_Diddy_Active'),
       (3,'Dixie',0x3c8000,0x390100,4,[0x11,0x12,0x10,0x15,0x11],'PAL_Sprite_Dixie_Active'),
       (3,'Kiddy',0x3c8000,0x390100,4,[0x98,0x99,0x97,0x9c,0x98],'PAL_Sprite_Kiddy_Active')]

def signed(w):return w-65536 if w&32768 else w

def decode_native(rom,assets,headers,name,palette):
    addr,header=headers[name];begin,end=assets[name]
    assert rom[addr:begin]==header,(name,'metadata mismatch')
    assert len(header)==8+2*(header[0]+header[1]+header[3]),name
    gfx=rom[begin:end];offset=0
    pixels=np.zeros((128,128),dtype=np.uint16)
    large=header[0];small=header[1]+header[3]
    for part,size in enumerate([16]*large+[8]*small):
        x=64+header[8+2*part]-128;y=96+header[9+2*part]-128
        for ty in range(size//8):
            for tx in range(size//8):
                tile_index=(part*2+tx+(large*2+header[1])*ty) if part<large else (large*2+part-large if part<large+header[1] else large*4+part-large)
                tile=decode_tile(gfx[tile_index*32:tile_index*32+32]);offset+=32
                for py,px in zip(*tile.nonzero()):
                    dx=x+tx*8+int(px);dy=y+ty*8+int(py)
                    assert 0<=dx<128 and 0<=dy<128,(name,'clipped native pixel',dx,dy)
                    pixels[dy,dx]=palette[int(tile[py,px])]
    assert offset==len(gfx),(name,offset,len(gfx))
    return pixels

def extract(specs=SPECS, cartridge=None):
    result=[]
    for game,kong,pose_table,anim_table,entry_size,animations,palette_name in specs:
        rom,assets,headers=tables(game,cartridge)
        source=(ROOT/f'work/dkc{game}/DKC{game}/Routine_Macros_DKC{game}.asm').read_text()
        by_address={address:name for name,(address,h) in headers.items()}
        a,b=assets[palette_name];raw_palette=b'\0\0'+rom[a:b]
        assert len(raw_palette)==32
        palette=[]
        for i in range(16):
            c=int.from_bytes(raw_palette[2*i:2*i+2],'little')
            palette.append(((c&31)<<11)|(((c>>5)&31)<<6)|((c>>10)&31))
        sequences=[]
        for motion,index in enumerate(animations,6):
            ptr=int.from_bytes(rom[anim_table+index*entry_size:anim_table+index*entry_size+2],'little')
            bank=0xbe0000 if game==1 else 0xf90000
            label=f'DATA_{bank|ptr:06X}:'
            start=source.index(label)
            lines=source[start:].splitlines()[1:]
            frames=[];events=[]
            for line in lines:
                if re.match(r'(?:CODE_|\s*%FREE_BYTES)',line):break
                if game==2:
                    m=re.search(r'db \$8B : db \$([0-9A-F]{2}) : dw \$([0-9A-F]{4}),\$([0-9A-F]{4}),\$([0-9A-F]{4})',line)
                    if not m:m=re.search(r'db \$([0-7][0-9A-F]) : dw \$([0-9A-F]{4})',line)
                else:
                    m=re.search(r'AnS(?:1)?_Op(?:XX|8B|95)\(\$([0-9A-F]{2}), \$([0-9A-F]{4})(?:, \$([0-9A-F]{4}), \$([0-9A-F]{4}))?\)',line)
                if m:
                    values=[int(v,16) if v else None for v in m.groups()]
                    duration,pose=values[:2]
                    addr=int.from_bytes(rom[pose_table+pose:pose_table+pose+3],'little')&0x3fffff
                    name=by_address[addr]
                    assert name.startswith('GFX_'+kong+'_'),(kong,motion,name)
                    grip=None
                    if len(values)==4 and values[2] is not None:
                        grip=[signed(values[2]),signed(values[3])*(-1 if game==1 else 1)]
                    pixels=decode_native(rom,assets,headers,name,palette)
                    frames.append(dict(duration=duration,pose=pose,name=name,header=addr,grip=grip,pixels=pixels))
                elif line.strip():events.append(line.strip())
                if re.search(r'Op(?:80|9A)\(\)|db \$80\s*$',line):break
            assert frames,(kong,motion,label)
            sequences.append(dict(motion=motion,label=label,frames=frames,events=events))
        result.append(dict(game=game,kong=kong,palette=palette,sequences=sequences))
    return result

def timing(sequence):
    total=sum(f['duration'] for f in sequence['frames'])
    elapsed=0;gripped=False;release=0
    for frame in sequence['frames']:
        if gripped and frame['grip'] is None and not release:release=elapsed
        gripped=gripped or frame['grip'] is not None
        elapsed+=frame['duration']
    if sequence['motion']==9:assert 0<release<total,(sequence['label'],release,total)
    return total,release

HOST_SPECS=[SPECS[0],
 (1,'Diddy',0x3bcc9c,0x3e8572,2,[0xb0,0xb1,0xaf,0xb2,0xb5],'PAL_Sprite_Diddy_Active'),
 SPECS[1],
 (2,'Dixie',0x3c8000,0x390000,4,[0xb3,0xb4,0xb2,0xb7,0xb9],'PAL_Sprite_Dixie_Active'),
 SPECS[2],SPECS[3]]

def main():
    data=extract();out=ROOT/'work/core/journey_native_carry.h'
    rows=[];sequences=[];palettes=[];records=[]
    for kong in data:
        palettes.append(kong['palette']);seq=[]
        for sequence in kong['sequences']:
            seq.append((len(rows),len(sequence['frames'])))
            record=dict(game=kong['game'],kong=kong['kong'],motion=sequence['motion'],script=sequence['label'],events=sequence['events'],frames=[])
            for frame in sequence['frames']:
                grip=frame['grip'];rows.append((0x10000+(kong['game']-1)*0x400000+frame['header'],frame['duration'],*(grip or [0,0]),bool(grip)))
                record['frames'].append({k:v for k,v in frame.items() if k!='pixels'})
            records.append(record)
        sequences.append(seq)
    with out.open('w') as f:
        f.write('// Generated from original ROM data and animation scripts. Do not edit.\n')
        f.write('struct JourneyNativeCarryStep { unsigned header; unsigned duration; int x,y; bool hasGrip; };\n')
        f.write('struct JourneyNativeCarrySequence { unsigned first,count; };\n')
        f.write('static const JourneyNativeCarryStep JourneyCarrySteps[] = {\n')
        for addr,duration,x,y,has in rows:f.write(f'{{0x{addr:x},{duration},{x},{y},{str(has).lower()}}},\n')
        f.write('};\nstatic const JourneyNativeCarrySequence JourneyCarrySequences[4][5] = {\n')
        for seq in sequences:f.write('{'+','.join('{%d,%d}'%v for v in seq)+'},\n')
        f.write('};\nstatic const uint16_t JourneyCarryPalettes[4][16] = {\n')
        for palette in palettes:f.write('{'+','.join(hex(v) for v in palette)+'},\n')
        f.write('};\n')
        f.write('struct JourneyCarryTiming { unsigned duration, release; };\n')
        for label,characters in [('JourneyDonorTimings',data),('JourneyHostTimings',extract(HOST_SPECS))]:
            f.write(f'static const JourneyCarryTiming {label}[{len(characters)}][2] = {{\n')
            for character in characters:
                values=[timing(character['sequences'][i]) for i in (2,3)]
                f.write('{'+','.join('{%d,%d}'%v for v in values)+'},\n')
            f.write('};\n')
    (ROOT/'project/tests/native-carry-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
    preview=Image.new('RGB',(128*16,128*4),'#203c45')
    draw=ImageDraw.Draw(preview)
    for y,kong in enumerate(data):
        for x,frame in enumerate(kong['sequences'][1]['frames'][:16]):
            p=frame['pixels'];rgb=np.stack(((p>>11)*255//31,((p>>5)&63)*255//63,(p&31)*255//31),axis=-1).astype('uint8')
            preview.paste(Image.fromarray(rgb),(128*x,128*y))
            if frame['grip']:
                gx=128*x+64+frame['grip'][0];gy=128*y+96+frame['grip'][1]
                draw.ellipse((gx-2,gy-2,gx+2,gy+2),fill='red')
    preview.save('/tmp/native-carry-frames.png')
    print('Extracted',len(rows),'native carry steps across',len(records),'sequences; no clipped or resampled pixels')
if __name__=='__main__':main()
