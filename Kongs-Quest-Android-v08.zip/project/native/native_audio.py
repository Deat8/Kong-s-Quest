"""Build the SPC700 data for the original Dixie and Kiddy damage sounds."""
from struct import pack, pack_into, unpack_from

DKC1_EFFECTS = 0x092D95
DKC3_EFFECTS = 0x31B663
DKC3_VOICE = 0x3105BE
VOICE_SAMPLE_ID = 0x46
VOICE_EFFECTS = ((4, 0x44), (3, 0x45))  # Dixie, Kiddy
ECHO_START = 0xE000
SAMPLE_START = 0x32A4
COMMON_RELOCATION = {0x06: 0x31C0}
SONG_RELOCATIONS = {0: (0x1C, 0x227D), 8: (0x0C, 0x1CA0), 20: (0x2C, 0x1C15)}


def word(data, offset):
    return unpack_from('<H', data, offset)[0]


def pointer(data, offset):
    return int.from_bytes(data[offset:offset + 3], 'little') & 0x3FFFFF


def sample_list(original, offset):
    samples = []
    while (sample := word(original, offset)) != 0xFFFF:
        assert sample < VOICE_SAMPLE_ID
        samples.append(sample)
        offset += 2
    return samples


def generate_native_audio(original, directory, cartridge):
    dkc3 = cartridge[0x810000:0xC10000]
    sample_size = word(dkc3, DKC3_VOICE - 2)
    assert word(dkc3, DKC3_VOICE - 4) == 0 and sample_size == 990
    sample = dkc3[DKC3_VOICE - 4:DKC3_VOICE + sample_size]
    assert sample[-9] & 1, 'Original BRR sample has no ending block'

    effects_size, effects_address = unpack_from('<HH', original, DKC1_EFFECTS)
    assert effects_address == 0x2380
    effects = bytearray(original[DKC1_EFFECTS + 4:DKC1_EFFECTS + 4 + effects_size])
    donor_address = word(dkc3, DKC3_EFFECTS)
    for source_id, effect_id in VOICE_EFFECTS:
        start = word(dkc3, DKC3_EFFECTS + 6 + source_id * 2)
        offset = DKC3_EFFECTS + 4 + start - donor_address
        donor = dkc3[offset:offset + 7]
        assert donor[:3] == bytes((1, 0xA6, 0x23)) and donor[-1] == 0
        volume, note, duration = donor[3:6]
        # Both pitch tables produce the same DSP pitch for these notes. The
        # older engine uses separate left/right volume values and explicit ADSR.
        pack_into('<H', effects, effect_id * 2, effects_address + len(effects))
        effects.extend((1, VOICE_SAMPLE_ID, 0x10, 0x8E, 0xE0, 2, volume, volume, note, duration, 0))
    assert effects_address + len(effects) <= COMMON_RELOCATION[0x06]

    common = sample_list(original, 0x0AB245)
    common.append(VOICE_SAMPLE_ID)
    sizes = {sample_id: word(original, pointer(original, 0x09FF00 + sample_id * 3) + 2)
             for sample_id in range(VOICE_SAMPLE_ID)}
    sizes[VOICE_SAMPLE_ID] = sample_size
    assert COMMON_RELOCATION[0x06] + sizes[0x06] <= 0x3200
    for song in range(28):
        offset = 0x0A0000 + word(original, 0x0AB20D + song * 2)
        samples = sample_list(original, offset)
        assert 0x3200 + 4 * (len(common) + len(samples)) <= SAMPLE_START
        tail = sum(sizes[sample_id] for sample_id in samples)
        if song in SONG_RELOCATIONS:
            sample_id, address = SONG_RELOCATIONS[song]
            assert sample_id in samples
            size, start = unpack_from('<HH', original, pointer(original, 0x0AB159 + song * 3))
            assert start + size <= address and address + sizes[sample_id] <= effects_address
            tail -= sizes[sample_id]
        end = SAMPLE_START + sum(sizes[sample_id] for sample_id in common
                                 if sample_id not in COMMON_RELOCATION) + tail
        assert end <= ECHO_START, (song, hex(end))

    (directory / 'native-dkc3-voice.brr').write_bytes(sample)
    (directory / 'native-common-samples.bin').write_bytes(pack(f'<{len(common) + 1}H', *common, 0xFFFF))
    (directory / 'native-sfx.bin').write_bytes(pack('<HH', len(effects), effects_address) + effects)
