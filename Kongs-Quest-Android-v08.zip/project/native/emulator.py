"""Minimal libretro frontend for testing the standalone cartridge on stock cores."""
from pathlib import Path
import ctypes as c
import numpy as np
from PIL import Image

ENV = c.CFUNCTYPE(c.c_bool, c.c_uint, c.c_void_p)
VIDEO = c.CFUNCTYPE(None, c.c_void_p, c.c_uint, c.c_uint, c.c_size_t)
AUDIO = c.CFUNCTYPE(c.c_size_t, c.c_void_p, c.c_size_t)
SAMPLE = c.CFUNCTYPE(None, c.c_int16, c.c_int16)
POLL = c.CFUNCTYPE(None)
INPUT = c.CFUNCTYPE(c.c_int16, c.c_uint, c.c_uint, c.c_uint, c.c_uint)


class Game(c.Structure):
    _fields_ = [('path', c.c_char_p), ('data', c.c_void_p), ('size', c.c_size_t), ('meta', c.c_char_p)]


class Geometry(c.Structure):
    _fields_ = [(name, c.c_uint) for name in ('base_width', 'base_height', 'max_width', 'max_height')] + [('aspect_ratio', c.c_float)]


class Timing(c.Structure):
    _fields_ = [('fps', c.c_double), ('sample_rate', c.c_double)]


class AVInfo(c.Structure):
    _fields_ = [('geometry', Geometry), ('timing', Timing)]


class Emulator:
    def __init__(self, core):
        self.lib = c.CDLL(str(Path(core).resolve()))
        self.buttons = 0
        self.capture = None
        self.pixel_format = 0
        self.audible_samples = 0
        self.system_dir = str(Path.cwd()).encode()
        self.callbacks = {'environment': ENV(self.environment), 'video_refresh': VIDEO(self.video),
                          'audio_sample_batch': AUDIO(self.audio), 'audio_sample': SAMPLE(self.sample),
                          'input_poll': POLL(lambda: None), 'input_state': INPUT(self.input)}
        for name, fn in self.callbacks.items():
            getattr(self.lib, 'retro_set_' + name)(fn)
        self.lib.retro_get_memory_data.restype = c.c_void_p
        self.lib.retro_get_memory_size.restype = c.c_size_t
        self.lib.retro_load_game.argtypes = [c.POINTER(Game)]
        self.lib.retro_load_game.restype = c.c_bool
        self.lib.retro_init()

    def environment(self, command, data):
        command &= 0xffff
        if command == 10:
            self.pixel_format = c.c_int.from_address(data).value
            return self.pixel_format in (0, 1, 2)
        if command in (9, 31):
            c.cast(data, c.POINTER(c.c_char_p)).contents.value = self.system_dir
            return True
        if command == 47:
            c.c_int.from_address(data).value = 3
            return True
        return command in (18, 35, 36, 37, 44, 52, 60)

    def video(self, data, width, height, pitch):
        if not data:
            return
        if self.pixel_format == 1:
            pixels = np.frombuffer(c.string_at(data, pitch * height), dtype=np.uint32).reshape(height, pitch // 4)[:, :width]
            rgb = np.stack(((pixels >> 16) & 255, (pixels >> 8) & 255, pixels & 255), axis=-1)
        else:
            pixels = np.frombuffer(c.string_at(data, pitch * height), dtype=np.uint16).reshape(height, pitch // 2)[:, :width]
            red_shift, green_mask = (11, 63) if self.pixel_format == 2 else (10, 31)
            rgb = np.stack((((pixels >> red_shift) & 31) * 255 // 31,
                            ((pixels >> 5) & green_mask) * 255 // green_mask,
                            (pixels & 31) * 255 // 31), axis=-1)
        self.capture = Image.fromarray(rgb.astype(np.uint8))

    def audio(self, data, frames):
        samples = np.ctypeslib.as_array((c.c_int16 * (frames * 2)).from_address(data))
        self.audible_samples += int(np.count_nonzero(samples))
        return frames

    def sample(self, left, right):
        self.audible_samples += bool(left) + bool(right)

    def input(self, port, device, index, button):
        if port != 0:
            return 0
        return self.buttons if button == 256 else int(bool(self.buttons & (1 << button)))

    def load(self, rom):
        rom = Path(rom).resolve()
        self.buffer = c.create_string_buffer(rom.read_bytes())
        self.game = Game(str(rom).encode(), c.cast(self.buffer, c.c_void_p), rom.stat().st_size, None)
        if not self.lib.retro_load_game(c.byref(self.game)):
            raise RuntimeError(f'Emulator rejected {rom.name}')
        info = AVInfo()
        self.lib.retro_get_system_av_info(c.byref(info))
        self.lib.retro_set_controller_port_device(0, 1)
        self.ram = self.memory(2)
        self.sram = self.memory(0)

    def memory(self, kind):
        length = self.lib.retro_get_memory_size(kind)
        address = self.lib.retro_get_memory_data(kind)
        if not address or not length:
            return bytearray()
        return (c.c_uint8 * length).from_address(address)

    def word(self, address):
        return self.ram[address] | self.ram[address + 1] << 8

    def run(self, frames=1, buttons=0):
        self.buttons = buttons
        for _ in range(frames):
            self.lib.retro_run()

    def press(self, mask):
        self.run(2, mask)
        self.run(3)

    def snapshot(self):
        self.lib.retro_serialize_size.restype = c.c_size_t
        self.lib.retro_serialize.argtypes = (c.c_void_p, c.c_size_t)
        self.lib.retro_serialize.restype = c.c_bool
        size = self.lib.retro_serialize_size()
        data = c.create_string_buffer(size)
        assert self.lib.retro_serialize(data, size)
        return data.raw

    def restore(self, data):
        self.lib.retro_unserialize.argtypes = (c.c_void_p, c.c_size_t)
        self.lib.retro_unserialize.restype = c.c_bool
        buffer = c.create_string_buffer(data)
        assert self.lib.retro_unserialize(buffer, len(data))

    def close(self):
        self.lib.retro_unload_game()
        self.lib.retro_deinit()
