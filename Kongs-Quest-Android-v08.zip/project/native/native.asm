exhirom

; The bank 00 reset mirror belongs to the extended half of the ROM.
; Bank 80 continues to point at Rare's original reset entry point.
org $008000
    jml NativeBoot

; Keep the SRAM test, with a mirror one 16 KiB SRAM size away.
assert read3($80E9CD) == $306859
org $80E9CD
    dl $326059

org $400000
!TeamSave = $307FF0
!FirstKong = $0100
!SecondKong = $0102
!ActiveField = $0104
!PreviousJoy = $0106
!CurrentJoy = $0108
!JoyEdges = $010A
!Direction = $010C

NativeBoot:
    sei
    clc
    xce
    cld
    rep #$30
    lda.w #$01FF
    tcs
    lda.w #$0000
    tcd
    phk
    plb
    ; PPU and I/O registers use bank 00, while assets use long reads.
    sep #$20
    lda.b #$00
    pha
    plb
    stz.w $4200
    stz.w $420C
    lda.b #$80
    sta.w $2100
    stz.w $2105
    lda.b #$08
    sta.w $2107
    stz.w $210B
    stz.w $210D
    stz.w $210D
    stz.w $210E
    stz.w $210E
    stz.w $2123
    stz.w $2124
    stz.w $2125
    stz.w $212D
    stz.w $2130
    stz.w $2131
    stz.w $2133
    lda.b #$01
    sta.w $212C
    lda.b #$80
    sta.w $2115
    stz.w $2121
    ldx.w #$0000
.palette:
    lda.l NativeMenuPalette,x
    sta.w $2122
    inx
    cpx.w #$0018
    bne .palette
    rep #$20
    stz.w $2116
    lda.w #$1801
    sta.w $4300
    lda.w #NativeMenuFont
    sta.w $4302
    lda.w #NativeMenuFontEnd-NativeMenuFont
    sta.w $4305
    sep #$20
    lda.b #NativeMenuFont>>16
    sta.w $4304
    lda.b #$01
    sta.w $420B
    rep #$20
    lda.w #$0800
    sta.w $2116
    lda.w #NativeMenuMap
    sta.w $4302
    lda.w #NativeMenuMapEnd-NativeMenuMap
    sta.w $4305
    sep #$20
    lda.b #NativeMenuMap>>16
    sta.w $4304
    lda.b #$01
    sta.w $420B
    rep #$20
    stz.w !ActiveField
    stz.w !PreviousJoy
    lda.l !TeamSave
    and.w #$FFF0
    cmp.w #$4B00
    bne .defaultTeam
    lda.l !TeamSave
    and.w #$0003
    sta.w !FirstKong
    lda.l !TeamSave
    lsr
    lsr
    and.w #$0003
    cmp.w !FirstKong
    beq .defaultTeam
    sta.w !SecondKong
    bra .show
.defaultTeam:
    stz.w !FirstKong
    lda.w #$0001
    sta.w !SecondKong
.show:
    jsr NativeMenuDraw
    sep #$20
    lda.b #$0F
    sta.w $2100
.loop:
    sep #$20
.waitVisible:
    lda.w $4212
    bmi .waitVisible
.waitVBlank:
    lda.w $4212
    bpl .waitVBlank
    lda.b #$01
    sta.w $4016
    stz.w $4016
    rep #$20
    stz.w !CurrentJoy
    ldx.w #$0010
.readJoy:
    lda.w $4016
    lsr
    rol.w !CurrentJoy
    dex
    bne .readJoy
    lda.w !PreviousJoy
    eor.w #$FFFF
    and.w !CurrentJoy
    sta.w !JoyEdges
    lda.w !CurrentJoy
    sta.w !PreviousJoy
    lda.w !JoyEdges
    bit.w #$1000
    bne .startGame
    bit.w #$0800
    beq .checkDown
    stz.w !ActiveField
.checkDown:
    bit.w #$0400
    beq .checkHorizontal
    ldx.w #$0002
    stx.w !ActiveField
.checkHorizontal:
    bit.w #$0100
    beq .checkLeft
    ldy.w #$0001
    bra .cycle
.checkLeft:
    bit.w #$0200
    beq .draw
    ldy.w #$FFFF
.cycle:
    sty.w !Direction
    ldx.w !ActiveField
    txa
    eor.w #$0002
    tay
    lda.w !FirstKong,x
    clc
    adc.w !Direction
    and.w #$0003
    cmp.w !FirstKong,y
    bne .setKong
    clc
    adc.w !Direction
    and.w #$0003
.setKong:
    sta.w !FirstKong,x
.draw:
    lda.w !JoyEdges
    and.w #$0F00
    bne .updateMenu
    brl .loop
.updateMenu:
    jsr NativeMenuDraw
    brl .loop
.startGame:
    lda.w !SecondKong
    asl
    asl
    ora.w !FirstKong
    ora.w #$4B00
    sta.l !TeamSave
    jsr NativePreparePalettes
    sep #$20
    lda.b #$80
    sta.w $2100
    ; The original reset routine initializes the game and the sound engine.
    jml $808000

NativeMenuDraw:
    lda.w #$0983
    sta.w $2116
    lda.w !ActiveField
    beq .firstCursor
    lda.w #$0020
    bra .writeFirstCursor
.firstCursor:
    lda.w #$043E
.writeFirstCursor:
    sta.w $2118
    lda.w #$0A23
    sta.w $2116
    lda.w !ActiveField
    bne .secondCursor
    lda.w #$0020
    bra .writeSecondCursor
.secondCursor:
    lda.w #$043E
.writeSecondCursor:
    sta.w $2118
    lda.w #$0986
    sta.w $2116
    lda.w !FirstKong
    jsr NativeMenuDrawName
    lda.w #$0A26
    sta.w $2116
    lda.w !SecondKong
    jsr NativeMenuDrawName
    rts

NativeMenuDrawName:
    asl
    asl
    asl
    asl
    asl
    tax
    ldy.w #$0010
.loop:
    lda.l NativeMenuNames,x
    sta.w $2118
    inx
    inx
    dey
    bne .loop
    rts

NativeMenuPalette:
    dw $1882,$6F9C,$0000,$0000
    dw $1882,$1F7E,$0000,$0000
    dw $1882,$4674,$0000,$0000
NativeMenuFont:
    incbin "menu-font.bin"
NativeMenuFontEnd:
NativeMenuMap:
    incbin "menu-map.bin"
NativeMenuMapEnd:
NativeMenuNames:
    incbin "menu-names.bin"

incsrc "engine.asm"
assert pc() <= $408000
incsrc "patches.asm"
