"""Pack original Kong graphics into the writable build image's ExHiROM banks."""
import json
import re
import sys
from pathlib import Path
from struct import pack, pack_into, unpack_from

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
from extract_native_carry import HOST_SPECS, SPECS, decode_native, extract  # noqa: E402
from extract_native_map_sprites import tables  # noqa: E402

POSE_TABLE = 0x3BCC9C
MAP_BANKS = (0x420000, 0x430000, 0x440000, 0x450000)
CHARACTERS = ('DonkeyKong', 'Diddy', 'Dixie', 'Kiddy')
FAMILIES = (
    ('Idle', 'IdleSway', 'LookAroundIdle', 'StandIdle', 'Stand'),
    ('Walk',), ('Run',), ('Jump',), ('Fall',), ('Land',), ('Roll',),
    ('Swim', 'Swimming'), ('Duck',), ('Turn',), ('Hurt',), ('Bounce',),
    ('ClimbUpSingleVerticalRope', 'ClimbUpSingleRope'),
    ('IdleOnVerticalRope', 'HangOnVerticalRope'), ('TurnOnVerticalRope',),
    ('ClimbHorizontalRope',), ('HangFromHorizontalRope',),
    ('TurnWhileSwimming',), ('RideSteelKeg',),
    ('BeatChest', 'Juggling', 'DrinkJuiceBox', 'PullPajamas', 'ScratchHead'),
    ('RideAnimalBuddy', 'SitOnAnimalBuddy'), ('HangOntoStabbingEnguarde', 'SitOnAnimalBuddy'),
    ('HangOntoWinky', 'SitOnAnimalBuddy'), ('SwingOnRope',),
    ('AngledInMinecart', 'RideToboggan'), ('IdleInMinecart', 'LookToSideInToboggan'),
    ('Crawling', 'EnterCrawlSpace'), ('LookUp',), ('TooCloseToEdge',),
    ('Victory', 'Dancing'), ('Failure', 'FreakOut', 'Tantrum'),
)
TAG_ACTIONS = (('DonkeyTakesLead', 'DiddyTakesLead'), ('DixieTakesLead', 'KiddyTakesLead'))
MOUNT_ACTIONS = ('RideAnimalBuddy', 'HangOntoStabbingEnguarde', 'HangOntoWinky')
BOUNCE_ANIMATIONS = {2: (0x0D, 'Dixie_Bounce'), 3: (0x94, 'Kiddy_Roll')}


def art_groups(assets, name):
    groups = {}
    prefix = 'GFX_' + name + '_'
    for asset in assets:
        if not asset.startswith(prefix):
            continue
        match = re.fullmatch(r'(.*?)(\d+)?', asset[len(prefix):])
        groups.setdefault(match[1], []).append((int(match[2] or 0), asset))
    return {family: [asset for _, asset in sorted(frames)] for family, frames in groups.items()}


class GraphicsBank:
    def __init__(self, rom):
        self.rom = rom
        self.next_address = 0x460000
        self.copied = {}

    def add(self, game, name, source, assets, headers, origin=(0, 0)):
        key = (game, name, origin)
        if key in self.copied:
            return self.copied[key]
        header_address, header = headers[name]
        graphics_begin, graphics_end = assets[name]
        assert graphics_begin == header_address + len(header), name
        assert source[header_address:graphics_begin] == header, name
        if game == 1 and origin == (0, 0):
            return 0xC00000 + header_address
        decode_native(source, assets, headers, name, list(range(16)))
        layout = bytearray(header)
        for index in range(8, len(layout)):
            layout[index] += origin[index % 2]
        data = bytes(layout) + source[graphics_begin:graphics_end]
        address = self.next_address
        if (address & 0xFFFF) + len(data) > 0x8000:
            address = ((address >> 16) + 1) << 16
        assert address + len(data) < 0x7E0000, 'ExHiROM graphics space exhausted'
        self.rom[address:address + len(data)] = data
        self.next_address = address + len(data)
        self.copied[key] = address
        return address


def closest_phase(frames, ordinal, count):
    if count <= 1:
        return frames[0]
    return frames[ordinal * (len(frames) - 1) // (count - 1)]


def original_bounce(game_data, target):
    rom, _, headers = game_data[3]
    animation, prefix = BOUNCE_ANIMATIONS[target]
    pointer = unpack_from('<H', rom, 0x390100 + 4 * animation)[0]
    offset = 0x390000 + pointer
    names = {address: name for name, (address, _) in headers.items()}
    frames = []
    while rom[offset] < 0x80:
        duration, pose = unpack_from('<BH', rom, offset)
        address = int.from_bytes(rom[0x3C8000 + pose:0x3C8003 + pose], 'little') & 0x3FFFFF
        name = names[address]
        assert duration and name.startswith('GFX_' + prefix), (animation, name)
        frames.append((duration, name))
        offset += 3
    # The same original landing callback ends both cycles on contact.
    assert frames and rom[offset:offset + 4] == bytes.fromhex('85 24 AB 9A')
    return frames


def write_bounce_script(directory, target_name, frames, host_poses):
    assert len(frames) <= len(host_poses)
    script = bytearray()
    for index, ((duration, _), pose) in enumerate(zip(frames, host_poses)):
        script.extend(pack('<BH', duration, pose))
        if index == 0:
            # Keep DKC1's native ground and water transition callback.
            script.extend(bytes.fromhex('84 2C 96 BE'))
    script.extend(bytes.fromhex('80 00'))
    (directory / f'native-{target_name.lower()}-bounce.bin').write_bytes(script)


def mount_contact(graphics, name):
    source, assets, headers = graphics
    pixels = decode_native(source, assets, headers, name, list(range(16)))
    ys, xs = pixels.nonzero()
    bottom = int(ys.max())
    feet = sorted(xs[ys >= bottom - 7])
    return int(feet[len(feet) // 2]), bottom


def palette_rows(game, name, source, assets):
    # The inactive names are capitalized differently in the DKC3 disassembly.
    addresses = {asset.lower(): address for asset, address in assets.items()}
    result = bytearray()
    for variant in ('Active', 'Inactive', 'P2Active', 'P2Inactive'):
        start, end = addresses[f'PAL_Sprite_{name}_{variant}'.lower()]
        assert end - start == 30, (game, name, variant)
        result.extend(source[start:end])
    result.extend(bytes(8))
    return result


MAP_ART = (
    (1, 'MapDonkeyKong', 'PAL_Sprite_MapScreen'),
    (1, 'MapDiddy', 'PAL_Sprite_MapScreen'),
    (3, 'MapDixie', 'PAL_Sprite_MapDixieAndKiddy_P1'),
    (3, 'MapKiddy', 'PAL_Sprite_MapDixieAndKiddy_P1'),
)


def map_palette_data(game_data):
    result = bytearray()
    for game, _, name in MAP_ART:
        rom, assets, _ = game_data[game]
        start, end = assets[name]
        colors = rom[start:end]
        if game == 1:
            colors = colors[6 * 32:7 * 32]
        if len(colors) == 30:
            colors = bytes(2) + colors
        assert len(colors) == 32
        result.extend(colors)
    return result


def generate_native_art(rom, directory, cartridge):
    game_data = {game: tables(game, cartridge) for game in (1, 2, 3)}
    source1, _, headers1 = game_data[1]
    assert source1 == rom[:0x400000]
    # Pose IDs are byte offsets into the original 4-byte pointer table.
    source_asm = (PROJECT.parent / 'work/dkc1/DKC1/Routine_Macros_DKC1.asm').read_text()
    table_lines = source_asm.split('DATA_BBCC9C:', 1)[1].split('%HiROMBankSplit()', 1)[0]
    rows = [line.strip()[3:] for line in table_lines.splitlines() if line.strip().startswith('dd ')]
    count = sum(len(row.split(',')) for row in rows)
    assert count and count * 8 <= 0x8000
    by_header = {address: name for name, (address, _) in headers1.items()}
    by_name = {}
    for ordinal in range(count):
        pose = ordinal * 4
        pointer = unpack_from('<I', source1, POSE_TABLE + pose)[0]
        name = by_header.get(pointer & 0x3FFFFF)
        if name is not None:
            by_name.setdefault(name, []).append((pose, pointer >> 24))

    donor_games = (1, 1, 3, 3)
    art = [art_groups(game_data[game][2], name) for game, name in zip(donor_games, CHARACTERS)]
    all_carry = extract([HOST_SPECS[0], HOST_SPECS[1], SPECS[2], SPECS[3]], cartridge)
    graphics = GraphicsBank(rom)
    stats = []
    manifest = {'pose_table_bytes': count * 4, 'characters': [], 'graphics': []}
    palette_data = bytearray()
    for target, (target_game, target_name, bank) in enumerate(zip(donor_games, CHARACTERS, MAP_BANKS)):
        target_source, target_assets, target_headers = game_data[target_game]
        palette_data.extend(palette_rows(target_game, target_name, target_source, target_assets))
        override = bytearray(count * 8)
        for offset in range(0, len(override), 8):
            pack_into('<H', override, offset + 4, 0x8000)
        mapped = {}

        def assign(host_name, donor_name, grip=None, mounted=False):
            if host_name not in by_name:
                return
            origin = (0, 0)
            if mounted:
                x, y = mount_contact(game_data[1], host_name)
                donor_x, donor_y = mount_contact(game_data[target_game], donor_name)
                origin = (x - donor_x, y - donor_y)
            target_pointer = graphics.add(target_game, donor_name, target_source, target_assets, target_headers, origin)
            for pose, priority in by_name[host_name]:
                pack_into('<I', override, pose * 2, target_pointer | (priority << 24))
                if grip is not None:
                    pack_into('<hh', override, pose * 2 + 4, grip[0], -grip[1])
                else:
                    pack_into('<HH', override, pose * 2 + 4, 0x8000, 0)
                mapped[pose] = {'source': host_name, 'target': donor_name, 'pointer': target_pointer,
                                'grip': grip}

        for host in (0, 1):
            if host == target:
                continue
            for family in FAMILIES:
                donor = next((art[target][alias] for alias in family if alias in art[target]), None)
                if donor is None:
                    continue
                for alias in family:
                    host_frames = art[host].get(alias, ())
                    for ordinal, host_name in enumerate(host_frames):
                        assign(host_name, closest_phase(donor, ordinal, len(host_frames)), mounted=family[0] in MOUNT_ACTIONS)

            for lead_slot, action in enumerate(TAG_ACTIONS[0]):
                target_lead = target % 2 if lead_slot == host else 1 - target % 2
                donor = art[target][TAG_ACTIONS[target // 2][target_lead]]
                host_frames = art[host][action]
                for ordinal, host_name in enumerate(host_frames):
                    assign(host_name, closest_phase(donor, ordinal, len(host_frames)))

            # A host pose may be reused by several actions. Give its regular
            # pickup/walk/throw sequence precedence over static hold aliases.
            for sequence_id in (0, 4, 1, 2, 3):
                host_frames = all_carry[host]['sequences'][sequence_id]['frames']
                donor_frames = all_carry[target]['sequences'][sequence_id]['frames']
                for ordinal, frame in enumerate(host_frames):
                    donor = closest_phase(donor_frames, ordinal, len(host_frames))
                    assign(frame['name'], donor['name'], donor['grip'])

            # Some original scripts have no corresponding action for the
            # selected Kong. Keep its own sprite even during those scripts.
            idle = next(art[target][alias][0] for alias in FAMILIES[0] if alias in art[target])
            for host_frames in art[host].values():
                for host_name in host_frames:
                    if any(pose not in mapped for pose, _ in by_name.get(host_name, ())):
                        assign(host_name, idle)
            if target in (0, 3):
                # DKC1 DK and DKC3 Kiddy use their landing art on descent.
                fall = art[target]['Land'][:4 if target == 0 else 2]
                host_fall = art[host].get('Fall', ())
                for ordinal, host_name in enumerate(host_fall):
                    assign(host_name, closest_phase(fall, ordinal, len(host_fall)))

        if target in BOUNCE_ANIMATIONS:
            # The DKC1 scripts open a hit with the last numbered hurt asset.
            # The DKC3 scripts for both losing a Kong and losing a life open
            # with Hurt1. Use that exact pose for the initial hit.
            for host_name in ('GFX_DonkeyKong_Hurt18', 'GFX_Diddy_Hurt17'):
                assign(host_name, art[target]['Hurt'][0])

            # Both player slots can use DK's original bounce pose IDs. Each
            # ID keeps its native collision box and has the selected artwork.
            host_frames = art[0]['Bounce']
            frames = original_bounce(game_data, target)
            host_poses = []
            for host_name, (_, donor_name) in zip(host_frames, frames):
                (pose, _), = by_name[host_name]
                host_poses.append(pose)
                assign(host_name, donor_name)
            write_bounce_script(directory, target_name, frames, host_poses)
        map_game, map_name, _ = MAP_ART[target]
        map_source, map_assets, map_headers = game_data[map_game]
        map_art = art_groups(map_headers, map_name)
        inactive_art = art_groups(map_headers, 'Inactive' + map_name)
        walk = map_art['Walk' if map_game == 1 else 'WalkSide']
        for host_name, entries in by_name.items():
            match = re.fullmatch(r'GFX_(Inactive)?Map(?:DonkeyKong|Diddy)_(Walk|Jump|Victory|Idle)(\d+)?', host_name)
            if match is None:
                continue
            variants = inactive_art if match[1] else map_art
            frames = variants.get(match[2]) or map_art.get(match[2]) or walk
            index = (int(match[3] or 1) - 1) % len(frames)
            name = frames[index]
            target_pointer = graphics.add(map_game, name, map_source, map_assets, map_headers)
            for pose, priority in entries:
                pack_into('<I', override, pose * 2, target_pointer | (priority << 24))
                mapped[pose] = {'source': host_name, 'target': name, 'pointer': target_pointer,
                                'grip': None}
        rom[bank:bank + len(override)] = override
        stats.append(len(mapped))
        manifest['characters'].append({'kong': target_name, 'mapped': mapped})

    (directory / 'native-palettes.bin').write_bytes(palette_data)
    (directory / 'native-map-palettes.bin').write_bytes(map_palette_data(game_data))
    hover_source, hover_assets, hover_headers = game_data[3]
    hover = bytearray(12 * 4)
    for frame in range(12):
        pointer = graphics.add(3, f'GFX_Dixie_Hover{frame + 1}', hover_source, hover_assets, hover_headers)
        pack_into('<I', hover, frame * 4, pointer)
    (directory / 'native-hover.bin').write_bytes(hover)
    (directory / 'native-hover-cycle.bin').write_bytes(bytes((tick % 12) * 4 for tick in range(256)))
    for (game, name, origin), pointer in graphics.copied.items():
        source, assets, headers = game_data[game]
        begin = headers[name][0]
        pixels = assets[name][0]
        end = assets[name][1]
        assert rom[pointer + pixels - begin:pointer + end - begin] == source[pixels:end]
        manifest['graphics'].append({'game': game, 'name': name, 'pointer': pointer,
                                     'size': end - begin, 'origin': origin})
    (directory / 'native-art.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print('Mapped native poses per Kong:', stats, '· imported sprite frames:', len(graphics.copied))
