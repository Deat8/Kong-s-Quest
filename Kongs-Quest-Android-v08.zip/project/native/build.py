"""Build the native DKC1 cartridge from the original game in the user's container."""
from argparse import ArgumentParser
from pathlib import Path
from shutil import copyfile
from struct import pack_into
from subprocess import run
from zlib import crc32
from menu_assets import menu_assets
from native_assets import generate_native_art
from native_audio import generate_native_audio

ROOT = Path(__file__).resolve().parents[2]
ORIGINAL_CRCS = (0xC946DCA0, 0x4E2D90F4, 0x448EEC19)


def original_dkc1(container):
    if container[0x7F00:0x7F0F] != b'DKCJOURNEY-MMC5':
        raise ValueError('Use the supplied Jornada container with all three original games')
    for chapter, expected in enumerate(ORIGINAL_CRCS, 1):
        start = 0x10000 + (chapter - 1) * 0x400000
        if crc32(container[start:start + 0x400000]) != expected:
            raise ValueError(f'DKC{chapter} must match the original CRC32 {expected:08X}')
    return container[0x10000:0x410000]


def set_headers(rom):
    for base in (0, 0x400000):
        rom[base + 0xFFD5] = 0x35  # Fast ExHiROM
        rom[base + 0xFFD7] = 0x0D  # 8 MiB ROM
        rom[base + 0xFFD8] = 0x04  # 16 KiB SRAM
        pack_into('<HH', rom, base + 0xFFDC, 0xFFFF, 0)
    checksum = sum(rom) & 0xFFFF
    for base in (0, 0x400000):
        pack_into('<HH', rom, base + 0xFFDC, checksum ^ 0xFFFF, checksum)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--asar', required=True, type=Path)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    cartridge = args.input.read_bytes()
    original = original_dkc1(cartridge)
    work = ROOT / 'work' / 'native-dkc1'
    work.mkdir(parents=True, exist_ok=True)
    menu_assets(work)
    for name in ('native.asm', 'engine.asm', 'patches.asm'):
        copyfile(Path(__file__).with_name(name), work / name)
    rom = bytearray(original + original)
    generate_native_art(rom, work, cartridge)
    generate_native_audio(original, work, cartridge)
    set_headers(rom)
    candidate = work / 'native-candidate.sfc'
    candidate.write_bytes(rom)
    run([str(args.asar.resolve()), '--no-title-check', 'native.asm', candidate.name], cwd=work, check=True)
    rom = bytearray(candidate.read_bytes())
    # The palette math reads the same shadow as direct palette DMA. Limit
    # these operand changes to the two original palette code blocks.
    for start, end in ((0x0198B9, 0x019B20), (0x36B37D, 0x36BE00)):
        for offset in range(0, 30, 2):
            original_load = b'\xBF' + (0xBC81CC + offset).to_bytes(3, 'little')
            shadow_load = b'\xBF' + (0x3161CC + offset).to_bytes(3, 'little')
            rom[start:end] = rom[start:end].replace(original_load, shadow_load)
    # Keep the slow-bank mirrors of original code coherent. The reset hook
    # in bank 00 remains in the extended copy only.
    boot_hook = bytes(rom[0x408000:0x408004])
    for bank in range(0x40):
        start = (bank << 16) + 0x8000
        rom[start + 0x400000:start + 0x408000] = rom[start:start + 0x8000]
    rom[0x408000:0x408004] = boot_hook
    set_headers(rom)
    if len(rom) != 0x800000:
        raise ValueError('Native cartridge must have exactly 8 MiB')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(rom)
    print(f'{args.output} · {len(rom)} bytes · CRC32 {crc32(rom):08X}')


if __name__ == '__main__':
    main()
