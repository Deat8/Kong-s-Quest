"""Boot the native cartridge, exercise its menu, and play DKC1 on stock cores."""
from argparse import ArgumentParser
from collections import deque
from pathlib import Path
import ctypes as c
import json
from emulator import Emulator

ROOT = Path(__file__).resolve().parents[2]
START, SELECT, B, Y, UP, DOWN, LEFT, RIGHT = 8, 4, 1, 2, 16, 32, 64, 128
NAMES = ('DK', 'Diddy', 'Dixie', 'Kiddy')


def menu_state(emulator):
    return (emulator.word(0x100), emulator.word(0x102), emulator.word(0x104) // 2)


def menu_move(state, button):
    first, second, field = state
    if button == UP:
        return first, second, 0
    if button == DOWN:
        return first, second, 1
    team = [first, second]
    direction = 1 if button == RIGHT else -1
    team[field] = (team[field] + direction) % 4
    if team[field] == team[1 - field]:
        team[field] = (team[field] + direction) % 4
    return team[0], team[1], field


def choose_team(emulator, team):
    start = menu_state(emulator)
    pending = deque([(start, ())])
    visited = {start}
    while pending:
        state, path = pending.popleft()
        if state[:2] == team:
            for button in path:
                start = menu_move(start, button)
                emulator.press(button)
                assert menu_state(emulator) == start, (team, button, menu_state(emulator), start)
            return
        for button in (UP, DOWN, LEFT, RIGHT):
            next_state = menu_move(state, button)
            if next_state not in visited:
                visited.add(next_state)
                pending.append((next_state, path + (button,)))
    raise AssertionError(f'Menu cannot select {team}')


def reach_map(emulator):
    emulator.press(START)
    for frame in range(2900):
        emulator.run(buttons=START if 30 <= frame % 90 < 34 else 0)
        if 0xE6 <= emulator.word(0x3E) <= 0xED:
            emulator.run(125)
            return
    raise AssertionError('Could not reach the original DKC1 map')


def reach_stage(emulator):
    emulator.press(START)
    for frame in range(1200):
        emulator.run(buttons=START if 30 <= frame % 90 < 34 else 0)
        if emulator.word(0x1E15) & 0x40:
            emulator.run(330)
            assert emulator.word(0xD47) == 1 and emulator.word(0xD13)
            return
    raise AssertionError('Could not enter Jungle Hijinxs')


def reach_internal_map(emulator):
    for frame in range(360):
        emulator.run(buttons=START if 22 <= frame % 90 < 26 else 0)
        if emulator.word(0x3E) == 0x16 and emulator.word(0x527) == 1:
            emulator.run(125)
            assert not emulator.word(0x1E15) & 0x40 and emulator.word(0xD45) == 0x10
            return
    raise AssertionError('Could not enter the Kongo Jungle stage map')


def exact_vram_pose(emulator, rom, art, kong, actor, pose=None):
    if pose is None:
        pose = emulator.word(0xAE5 + actor)
    entry = art['characters'][kong]['mapped'].get(str(pose))
    if entry is None:
        if actor == 0 or kong != 0:
            return False
        address = int.from_bytes(rom[0x3BCC9C + pose:0x3BCC9F + pose], 'little')
    else:
        address = entry['pointer']
    return vram_graphic_matches(emulator, rom, address, actor)


def vram_graphic_matches(emulator, rom, address, actor):
    vram = emulator.memory(3)
    if len(vram) != 0x10000:
        return False
    offset = address if 0x400000 <= address < 0x7E0000 else address & 0x3FFFFF
    header = rom[offset:offset + 8]
    if len(header) != 8:
        return False
    source = offset + 8 + (header[0] + header[1] + header[3]) * 2
    size = header[5] * 32
    destination = (emulator.word(0xC69 + actor) & 0x1FF) * 32
    if not size or bytes(vram[destination:destination + size]) != rom[source:source + size]:
        return False
    destination += header[6] * 32
    source += size
    size = (header[7] & 0xF) * 32
    return bytes(vram[destination:destination + size]) == rom[source:source + size]


def wait_for_vram_pose(emulator, rom, art, kong, actor):
    # The pose ID can be queued one frame before the next VRAM transfer.
    for _ in range(16):
        if exact_vram_pose(emulator, rom, art, kong, actor):
            return
        emulator.run()
    raise AssertionError((NAMES[kong], actor, 'displayed tiles do not match the selected Kong'))


def test_barrel(emulator, root, kong, output):
    fixture = root / 'project/tests/fixtures/held-native.state'
    emulator.lib.retro_unserialize.argtypes = (c.c_void_p, c.c_size_t)
    emulator.lib.retro_unserialize.restype = c.c_bool
    state = c.create_string_buffer(fixture.read_bytes())
    cartridge_data = bytes(emulator.sram)
    assert emulator.lib.retro_unserialize(state, len(state) - 1)
    emulator.sram[:] = cartridge_data
    assert emulator.word(0x16F5), 'The barrel fixture has no held object'
    emulator.run(16, Y)
    assert emulator.word(0x16F5)
    emulator.capture.save(output / f'{kong}-barrel.png')
    emulator.run(12, Y | RIGHT)
    assert emulator.word(0x16F5)
    emulator.run(90)
    assert emulator.word(0x16F5) == 0, 'The barrel stayed attached after release'


def test_pickup_and_tag(emulator, output, kong, partner, rom, art, verify_tiles):
    # Reach the first DK barrel with ordinary controller inputs. Jump over the
    # Gnawty and land beside the barrel while holding Y.
    emulator.run(90, RIGHT | Y)
    emulator.run(30, RIGHT | Y | B)
    emulator.run(23, RIGHT | Y)
    emulator.run(48, Y)
    for _ in range(80):
        if emulator.word(0x16F5):
            break
        emulator.run(buttons=RIGHT | Y)
    assert emulator.word(0x16F5), (NAMES[kong], 'did not pick up the barrel')
    emulator.run(12, Y)
    assert emulator.word(0x16F5)
    emulator.capture.save(output / f'{NAMES[kong]}-stage-barrel.png')
    emulator.run(95)
    assert not emulator.word(0x16F5) and emulator.word(0x579) & 1
    emulator.press(SELECT)
    checked = set()
    for _ in range(55):
        for actor, selected in ((2, kong), (4, partner)):
            pose = emulator.word(0xAE5 + actor)
            entry = art['characters'][selected]['mapped'].get(str(pose))
            if entry is None or 'TakesLead' not in entry['source']:
                continue
            assert 'TakesLead' in entry['target']
            if not verify_tiles or exact_vram_pose(emulator, rom, art, selected, actor):
                checked.add(actor)
        emulator.run()
    assert checked == {2, 4}, (kong, 'tag frames were not displayed for both players')
    assert emulator.word(0x56F) == 2, (NAMES[partner], 'did not become active')
    emulator.capture.save(output / f'{NAMES[partner]}-after-tag.png')


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--core', required=True, type=Path)
    parser.add_argument('--rom', required=True, type=Path)
    parser.add_argument('--assets', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--snes9x', action='store_true')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    rom = args.rom.read_bytes()
    art = json.loads(args.assets.read_text())
    emulator = Emulator(args.core)
    emulator.load(args.rom)
    emulator.run(12)
    assert len(emulator.sram) == 0x4000
    assert menu_state(emulator) == (0, 1, 0)
    seen = set()
    for first in range(4):
        for second in range(4):
            if first != second:
                choose_team(emulator, (first, second))
                seen.add(menu_state(emulator)[:2])
    assert len(seen) == 12
    print('12 ordered pairs reachable, with no duplicate Kong', flush=True)
    emulator.lib.retro_unload_game()
    for kong in range(4):
        partner = 2 if kong == 3 else (kong + 1) % 4
        emulator.load(args.rom)
        emulator.run(12)
        choose_team(emulator, (kong, partner))
        emulator.capture.save(args.output / f'{kong}-menu.png')
        reach_map(emulator)
        team = int.from_bytes(emulator.sram[0x1FF0:0x1FF2], 'little')
        assert team == 0x4B00 | (partner << 2) | kong
        emulator.capture.save(args.output / f'{kong}-map.png')
        if args.snes9x:
            assert exact_vram_pose(emulator, rom, art, kong, 0), (kong, 'map tiles mismatch')
        reach_internal_map(emulator)
        assert (emulator.word(0xC69) >> 9) & 7 == (1 if kong >= 2 else 6)
        if args.snes9x:
            wait_for_vram_pose(emulator, rom, art, kong, 0)
        emulator.capture.save(args.output / f'{kong}-internal-map.png')
        reach_stage(emulator)
        assert emulator.audible_samples > 0
        emulator.capture.save(args.output / f'{kong}-idle.png')
        if args.snes9x:
            assert exact_vram_pose(emulator, rom, art, kong, 2), (kong, 'player tiles mismatch')
        before_movement = emulator.snapshot()
        x = emulator.word(0xB1B)
        emulator.run(21, RIGHT)
        assert emulator.word(0xB1B) > x, (kong, 'walk did not advance')
        emulator.capture.save(args.output / f'{kong}-run.png')
        y = emulator.word(0xBC3)
        emulator.run(11, B)
        assert emulator.word(0xBC3) > y + 8, (kong, 'jump did not rise')
        emulator.capture.save(args.output / f'{kong}-jump.png')
        if kong == 2:
            gliding = 0
            for _ in range(75):
                emulator.run(buttons=Y)
                if emulator.word(0xEF3) == 0xFE80:
                    gliding += 1
                    if gliding == 4:
                        emulator.capture.save(args.output / '2-glide.png')
            assert gliding >= 8, ('Dixie did not sustain glide', gliding)
            print(f'Dixie glide sustained for {gliding} native game frames', flush=True)
        emulator.restore(before_movement)
        for _ in range(24):
            emulator.run(buttons=Y | RIGHT)
            if emulator.word(0x10D3) == 0x18:
                emulator.capture.save(args.output / f'{kong}-roll.png')
                break
        else:
            raise AssertionError((kong, 'roll action did not start'))
        if kong in (2, 3):
            emulator.restore(before_movement)
            test_pickup_and_tag(emulator, args.output, kong, partner, rom, art, args.snes9x)
            if args.snes9x:
                wait_for_vram_pose(emulator, rom, art, partner, 4)
            print(f'{NAMES[kong]} threw the DK barrel and tagged in {NAMES[partner]} with native sprites', flush=True)
        if args.snes9x:
            test_barrel(emulator, ROOT, kong, args.output)
        saved = bytes(emulator.sram)
        emulator.lib.retro_unload_game()
        emulator.load(args.rom)
        emulator.sram[:] = saved
        emulator.run(12)
        assert menu_state(emulator)[:2] == (kong, partner)
        emulator.lib.retro_unload_game()
        print(f'{NAMES[kong]}: menu, map, movement, jump, roll, audio and persisted pair OK', flush=True)
    emulator.lib.retro_deinit()


if __name__ == '__main__':
    main()
