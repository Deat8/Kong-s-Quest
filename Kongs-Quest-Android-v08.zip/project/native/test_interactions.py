"""Exercise the native stomp and sound dispatch routines in stock Snes9x."""
from argparse import ArgumentParser
from pathlib import Path
import struct

from emulator import Emulator
from native_audio import DKC3_VOICE, VOICE_SAMPLE_ID, SONG_RELOCATIONS, pointer, word
from test_cartridge import choose_team, reach_map, reach_stage


def run_code(emulator, state, code, inputs, *, returns=True, max_frames=1):
    state = bytearray(state)
    cpu = state.index(b'CPU:000048:') + 11
    registers = state.index(b'REG:000016:') + 11
    memory = state.index(b'RAM:131072:') + 11
    # Use the WRAM mirror in bank BF so the game's RTS returns to this probe.
    start = 0x1DC0
    # Set 16-bit registers, bank 80 data, and disable interrupts for one call.
    prefix = bytes.fromhex('78 C2 30 D8 F4 80 80 AB AB A9 00 00 5B E2 20 9C 00 42 C2 20')
    tail = bytes.fromhex('A9 37 13 8F 00 F0 7F 80 FE')
    routine = prefix + code + tail
    state[memory + start:memory + start + len(routine)] = routine
    state[cpu + 42:cpu + 44] = b'\x00\x00'  # WaitingForInterrupt and NMIPending
    state[registers] = 0xBF
    struct.pack_into('>H', state, registers + 14, start)
    for address, value in inputs.items():
        struct.pack_into('<H', state, memory + address, value)
    struct.pack_into('<H', state, memory + 0x1F000, 0)
    sram = bytes(emulator.sram)
    emulator.restore(bytes(state))
    emulator.sram[:] = sram
    for _ in range(max_frames):
        emulator.run()
        if not returns or emulator.word(0x1F000) == 0x1337:
            return
    raise AssertionError('Game routine did not return to the WRAM probe')


def audio_state(snapshot):
    offset = snapshot.index(b'SND:') + 11
    aram = snapshot[offset:offset + 0x10000]
    # Snes9x serializes 41 32-bit SMP fields between ARAM and the DSP registers.
    start = offset + 0x10000 + 41 * 4
    return aram, snapshot[start:start + 128]


def sample_address(aram, sample_id):
    index = aram[0x04E0 + sample_id]
    return word(aram, 0x3200 + index * 4)


def test_imported_damage(emulator, state, cartridge):
    dkc1 = cartridge[0x10000:0x410000]
    dkc3 = cartridge[0x810000:0xC10000]
    voice_data = dkc3[DKC3_VOICE:DKC3_VOICE + word(dkc3, DKC3_VOICE - 2)]
    aram, dsp = audio_state(state)
    index = aram[0x04E0 + VOICE_SAMPLE_ID]
    address = sample_address(aram, VOICE_SAMPLE_ID)
    assert aram[address:address + len(voice_data)] == voice_data
    assert (dsp[0x6D], dsp[0x7D]) == (0xE0, 4), 'Echo delay changed'

    for lead, partner in ((3, 2), (2, 3)):
        emulator.sram[0x1FF0:0x1FF2] = struct.pack('<H', 0x4B00 | lead | partner << 2)
        for requested, selected, actor in ((0x46, lead, 2), (0x43, partner, 4)):
            command = bytes((0xA9, requested, 0, 0x22, 0x27, 0xFB, 0xBF))
            run_code(emulator, state, command, {0x82: actor, 0xD45 + actor: actor // 2})
            assert emulator.word(0xF5) == (0x44 if selected == 2 else 0x45)
            emulator.run(3)
            _, dsp = audio_state(emulator.snapshot())
            pitch = 0x047D if selected == 2 else 0x02FF
            assert any(dsp[v + 4] == index and word(dsp, v + 2) == pitch and dsp[v + 8]
                       for v in range(0, 128, 16)), (selected, 'wrong DSP sample or pitch')
    for requested in (0x03, 0x05, 0x13, 0x3E, 0x3F, 0x40, 0x41):
        command = bytes((0xA9, requested, 0, 0x22, 0x27, 0xFB, 0xBF))
        run_code(emulator, state, command, {})
        assert emulator.word(0xF5) == 0
    print('Dixie and Kiddy play the original DKC3 BRR sample at the correct pitch in both slots', flush=True)

    for song, (sample_id, expected_address) in SONG_RELOCATIONS.items():
        if song:
            command = bytes((0xA9, song, 0, 0x22, 0x49, 0x90, 0xB9))
            run_code(emulator, state, command, {}, max_frames=130)
            aram, _ = audio_state(emulator.snapshot())
        for original_id, expected in ((0x06, 0x31C0), (sample_id, expected_address)):
            address = sample_address(aram, original_id)
            source = pointer(dkc1, 0x09FF00 + original_id * 3)
            size = word(dkc1, source + 2)
            assert address == expected and aram[address:address + size] == dkc1[source + 4:source + 4 + size]
        address = sample_address(aram, VOICE_SAMPLE_ID)
        assert aram[address:address + len(voice_data)] == voice_data
    print('All displaced DKC1 samples remain byte-identical after the original track loader runs', flush=True)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--core', required=True, type=Path)
    parser.add_argument('--rom', required=True, type=Path)
    parser.add_argument('--input', required=True, type=Path, help='Original Jornada container')
    args = parser.parse_args()
    emulator = Emulator(args.core)
    emulator.load(args.rom)
    emulator.run(12)
    choose_team(emulator, (1, 0))
    reach_map(emulator)
    reach_stage(emulator)
    state = emulator.snapshot()
    for kong in range(4):
        other = (kong + 1) % 4
        for slot in range(2):
            leader, partner = (kong, other) if slot == 0 else (other, kong)
            emulator.sram[0x1FF0:0x1FF2] = struct.pack('<H', 0x4B00 | leader | partner << 2)
            actor, enemy = 2 + slot * 2, 0x1E
            for enemy_id in (0x06, 0x2F, 0x46):
                run_code(emulator, state, bytes.fromhex('20 E8 A7'), {
                    0x82: actor, 0x84: slot * 2, 0x88: enemy,
                    0xD45 + actor: slot + 1, 0xD45 + enemy: enemy_id,
                    0x11A1 + enemy: 0, 0x1595 + enemy: 0,
                })
                heavy = kong in (0, 3)
                assert emulator.word(0x1595 + enemy) == int(heavy), (kong, slot, enemy_id)
                assert emulator.word(0xEF1 + actor) == (0x0720, 0x0300, 0x0300, 0x0800)[kong]
        print(f'Kong {kong}: both slots follow the Klump, Army and Blue Krusha stomp branches', flush=True)
    emulator.sram[0x1FF0:0x1FF2] = struct.pack('<H', 0x4B01)
    for dk, diddy in ((0x64, 0x33), (0x3F, 0x3E), (0x40, 0x41),
                      (0x46, 0x43), (0x5E, 0x5D), (0x75, 0x76)):
        for requested, expected, actor in ((dk, diddy, 2), (diddy, dk, 4)):
            code = bytes((0xA9, requested, 0, 0x22, 0x27, 0xFB, 0xBF))
            run_code(emulator, state, code, {0x82: actor, 0xD45 + actor: actor // 2})
            assert emulator.word(0xF5) == expected, (requested, expected, emulator.word(0xF5))
    print('All six DK/Diddy voice pairs dispatch the selected voice from either slot', flush=True)
    test_imported_damage(emulator, state, args.input.read_bytes())
    emulator.close()


if __name__ == '__main__':
    main()
