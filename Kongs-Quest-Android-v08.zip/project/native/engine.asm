; Hooks execute the new code on the 65816. No emulator ports are used.

; Y is the game actor index. A returns the selected Kong, carry says it is a player.
NativeSelectedKong:
    cpy.w #$0002
    beq .first
    cpy.w #$0004
    bne .other
    lda.w $0D45,y
    cmp.w #$0002
    bne .other
    lda.l !TeamSave
    lsr
    lsr
    and.w #$0003
    sec
    rts
.first:
    lda.w $0D45,y
    cmp.w #$0001
    bne .other
    lda.l !TeamSave
    and.w #$0003
    sec
    rts
.other:
    clc
    rts

; The original mount scripts put the animal pose in the player slot and the
; rider pose in the animal slot. Follow the live link back to the player.
NativeRenderedKong:
    jsr NativeSelectedKong
    bcs .done
    lda.w $0D45,y
    cmp.w #$0009
    bcc .other
    cmp.w #$000D
    bcs .other
    phy
    phx
    lda.w $1375,y
    tax
    cpx.w #$0002
    beq .linked
    cpx.w #$0004
    bne .notLinked
.linked:
    tya
    cmp.w $0510,x
    bne .notLinked
    txy
    jsr NativeSelectedKong
    bra .restore
.notLinked:
    clc
.restore:
    plx
    ply
.done:
    rts
.other:
    clc
    rts

; X is the original pose offset. Preserve X and Y, and return the same pointer
; fields that the original OAM and VRAM DMA routines consume.
NativeRenderPointer:
    lda.w $1E15
    bit.w #$0040
    beq .map
    jsr NativeRenderedKong
    bcs .player
    brl .original
.player:
    cmp.w #$0002
    bne .choose
    cpy.w #$0006
    bcs .choose
    lda.w $0510,y
    bne .dixieNormal
    lda.w $170D
    cmp.b $3C
    bcc .currentHover
    lda.l $307FE0
    bpl .dixieNormal
    and.w #$00FF
    phx
    tax
    bra .hoverPointer
.currentHover:
    jsr NativeCanGlide
    bcc .dixieNormal
    phx
    jsr NativeHoverOffset
    tax
.hoverPointer:
    lda.l NativeHoverPointers+2,x
    sta.b $5C
    lda.l NativeHoverPointers,x
    brl .mapped
.dixieNormal:
    lda.w #$0002
    bra .choose
.map:
    lda.w $0527
    cmp.w #$0001
    bne .notMap
    cpy.w #$0008
    bcs .notMap
    lda.w $0D45,y
    cmp.w #$0004
    beq .mapKong
    cpy.w #$0004
    bcs .notMap
    cmp.w #$0010
    beq .mapKong
    cmp.w #$0012
    beq .mapKong
    cmp.w #$001C
    beq .mapKong
    cmp.w #$0014
    bne .notMap
.mapKong:
    jsr NativeMapKong
    bra .choose
.notMap:
    brl .original
.choose:
    phx
    cmp.w #$0001
    beq .diddy
    cmp.w #$0002
    beq .dixie
    cmp.w #$0003
    beq .kiddy
.donkey:
    txa
    asl
    tax
    lda.l $420002,x
    beq .unmapped
    sta.b $5C
    lda.l $420000,x
    bra .mapped
.diddy:
    txa
    asl
    tax
    lda.l $430002,x
    beq .unmapped
    sta.b $5C
    lda.l $430000,x
    bra .mapped
.dixie:
    txa
    asl
    tax
    lda.l $440002,x
    beq .unmapped
    sta.b $5C
    lda.l $440000,x
    bra .mapped
.kiddy:
    txa
    asl
    tax
    lda.l $450002,x
    beq .unmapped
    sta.b $5C
    lda.l $450000,x
.mapped:
    sta.b $5A
    inc
    sta.b $5E
    plx
    lda.w $0527
    cmp.w #$0001
    bne .returnPointer
    jsr NativeMapKong
    cmp.w #$0002
    bcc .originalMapPalette
    lda.w $0C69,y
    and.w #$F1FF
    ora.w #$0200
    bra .setMapPalette
.originalMapPalette:
    lda.w $0C69,y
    and.w #$F1FF
    ora.w #$0C00
.setMapPalette:
    sta.w $0C69,y
    sta.b $4C
    sta.b $4E
.returnPointer:
    lda.b $5C
    sta.b $60
    rtl
.unmapped:
    plx
.original:
    lda.l $BBCC9C,x
    sta.b $5A
    inc
    sta.b $5E
    lda.l $BBCC9E,x
    sta.b $5C
    sta.b $60
    rtl

; Replace the native object offsets after the original carry opcode runs.
; The barrel remains a normal game object, including when it leaves the hand.
NativeGrip:
    cpx.w #$0006
    bcs .candidate
    brl .restore
.candidate:
    lda.w $0D45,x
    cmp.w #$0022
    bcc .restore
    cmp.w #$0028
    bcs .restore
    phy
    phx
    ldy.b $82
    jsr NativeSelectedKong
    bcc .done
    cmp.w #$0001
    beq .diddy
    cmp.w #$0002
    beq .dixie
    cmp.w #$0003
    beq .kiddy
.donkey:
    lda.w $0D11,y
    asl
    tax
    lda.l $420004,x
    cmp.w #$8000
    beq .done
    pha
    lda.l $420006,x
    bra .store
.diddy:
    lda.w $0D11,y
    asl
    tax
    lda.l $430004,x
    cmp.w #$8000
    beq .done
    pha
    lda.l $430006,x
    bra .store
.dixie:
    lda.w $0D11,y
    asl
    tax
    lda.l $440004,x
    cmp.w #$8000
    beq .done
    pha
    lda.l $440006,x
    bra .store
.kiddy:
    lda.w $0D11,y
    asl
    tax
    lda.l $450004,x
    cmp.w #$8000
    beq .done
    pha
    lda.l $450006,x
.store:
    ply
    plx
    pha
    tya
    sta.w $13E9,x
    pla
    sta.w $145D,x
    ply
    bra .restore
.done:
    plx
    ply
.restore:
    ldx.b $82
    tya
    clc
    rtl

NativeWeight:
    pha
    phy
    txy
    jsr NativeSelectedKong
    bcc .original
    cmp.w #$0000
    beq .heavy
    cmp.w #$0003
    beq .heavy
    bra .light
.original:
    cpx.w #$0002
    beq .heavy
.light:
    ply
    pla
    clc
    rts
.heavy:
    ply
    pla
    sec
    rts

NativeStompWeight:
    jsr NativeWeight
    bcs .heavy
    jml $BFA803
.heavy:
    jml $BFA7F1

NativeStompLaunch:
    phy
    txy
    jsr NativeSelectedKong
    ply
    bcc .original
    cmp.w #$0002
    bcc .original
    ; DKC3 stores upward speed as negative. DKC1 uses positive Y upward.
    phy
    ldy.b $84
    lda.w #$FF90
    sta.w $16F9,y
    ply
    lda.w #$0800
    jml $BFA7A9
.original:
    lda.w #$0720
    jsr NativeWeight
    bcs .heavy
    jml $BFA7A6
.heavy:
    jml $BFA7A9

; Called by both animation entry and the loop opcode. X is the original
; animation ID times two and Y is the actor. Preserve both registers.
NativeAnimationScript:
    cpx.w #$0017*2
    beq .bounce
    cpx.w #$007F*2
    bne .original
.bounce:
    jsr NativeSelectedKong
    bcc .original
    phx
    asl
    tax
    lda.l NativeBounceScripts,x
    plx
    rtl
.original:
    lda.l $BE8572,x
    rtl

NativeBounceScripts:
    dw $95F6,$B69E,NativeDixieBounce,NativeKiddyBounce

NativeHitboxWeight:
    jsr NativeWeight
    bcs .heavy
    jml $BFA75A
.heavy:
    jml $BFA75D

NativeJumpWeight:
    jsr NativeWeight
    bcs .heavy
    jml $BFB516
.heavy:
    jml $BFB51E

; These callbacks are used by the normal jump scripts. Keep the original
; launch bookkeeping and apply the selected character's vertical profile.
NativeDKGroundJump:
    jsl $BEA7D6
    bra NativeGroundJump

NativeDiddyGroundJump:
    jsl $BEA7C1
NativeGroundJump:
    php
    pha
    phy
    txy
    jsr NativeSelectedKong
    bcc .done
    phx
    asl
    asl
    tax
    lda.l NativeJumpProfiles,x
    pha
    lda.l NativeJumpProfiles+2,x
    ldy.b $84
    sta.w $16F9,y
    pla
    plx
    sta.w $0EF1,x
.done:
    ply
    pla
    plp
    rtl

NativeJumpProfiles:
    ; Launch speed and held-button gravity. Released-button gravity stays $FF90.
    dw $0700,$FFB8
    dw $085A,$FFA6
    dw $0800,$FFA6
    dw $0800,$FFA6

; Keep the original palette identifiers in WRAM. The palette data shadow lives
; in the second SRAM bank so both direct DMA and the native fades can read it.
NativePreparePalettes:
    lda.w #$0000
    sta.l $307FE0
    ldx.w #$0000
.copyOriginal:
    lda.l $BC8000,x
    sta.l $316000,x
    inx
    inx
    cpx.w #$2000
    bne .copyOriginal
    phb
    pea.w $3131
    plb
    plb
    lda.w !FirstKong
    xba
    lsr
    tax
    ldy.w #$0000
.firstRows:
    lda.l NativeKongPalettes,x
    sta.w $649A,y
    inx
    inx
    iny
    iny
    cpy.w #$0078
    bne .firstRows
    lda.w !SecondKong
    xba
    lsr
    tax
    ldy.w #$0000
.secondRows:
    lda.l NativeKongPalettes,x
    sta.w $6422,y
    inx
    inx
    iny
    iny
    cpy.w #$0078
    bne .secondRows
    plb
    rts

NativePaletteQueue:
    lda.b $8C
    cmp.w #$8000
    bcc .original
    cmp.w #$A000
    bcs .original
    sec
    sbc.w #$2000
    sta.w $1A8F,x
    lda.b $76
    asl
    asl
    asl
    clc
    adc.w #$0081
    xba
    ora.w #$0031
    sta.w $1A91,x
    rtl
.original:
    lda.b $8C
    sta.w $1A8F,x
    lda.b $76
    asl
    asl
    asl
    clc
    adc.w #$0081
    xba
    ora.w #$00BC
    sta.w $1A91,x
    rtl

NativePaletteDecompose:
    phx
    phy
    phb
    tya
    cmp.w #$8000
    bcc .copy
    cmp.w #$A000
    bcs .copy
    sec
    sbc.w #$2000
    tay
    pea.w $3131
    plb
    plb
.copy:
    ldx.b $8C
    !color = 0
    while !color < 15
        lda.w !color*2,y
        and.w #$001F
        xba
        sta.l $7F04A0+(!color*6),x
        lda.w !color*2,y
        and.w #$03E0
        sta.l $7F04A2+(!color*6),x
        lda.w !color*2,y
        and.w #$7C00
        sta.l $7F04A4+(!color*6),x
        !color #= !color+1
    endwhile
    lda.b $8C
    clc
    adc.w #$0060
    sta.b $8C
    plb
    ply
    plx
    rtl

NativeHoverOffset:
    phx
    lda.b $28
    and.w #$00FF
    tax
    lda.l NativeHoverCycle,x
    and.w #$00FF
    plx
    rts

; The original cache compares only pose IDs. Hover has its own frames, so
; explicitly refresh its tiles and restore the normal tiles when it ends.
NativeNeedsNewPose:
    pha
    phy
    txy
    jsr NativeSelectedKong
    bcc .original
    cmp.w #$0002
    bne .original
    jsr NativeCanGlide
    bcc .endGlide
    jsr NativeHoverOffset
    ora.w #$8000
    cmp.l $307FE0
    beq .original
    sta.l $307FE0
    bra .changed
.endGlide:
    lda.l $307FE0
    bpl .original
    lda.w #$0000
    sta.l $307FE0
.changed:
    ply
    pla
    sec
    rts
.original:
    ply
    pla
    cmp.w $0AE5,x
    beq .same
    sec
    rts
.same:
    clc
    rts

NativeComparePoseFirst:
    jsr NativeNeedsNewPose
    bcs .upload
    jml $BBA7C9
.upload:
    jml $BBA7D3

NativeComparePoseSecond:
    jsr NativeNeedsNewPose
    bcs .upload
    jml $BBA9A0
.upload:
    jml $BBA9A3

NativeActiveKong:
    lda.w $056F
    cmp.w #$0002
    beq NativeSecondKong
NativeFirstKong:
    lda.l !TeamSave
    and.w #$0003
    rts
NativeSecondKong:
    lda.l !TeamSave
    lsr
    lsr
    and.w #$0003
    rts

NativeInactiveKong:
    lda.w $056F
    cmp.w #$0002
    beq NativeFirstKong
    bra NativeSecondKong

NativeMapKong:
    tya
    bit.w #$0002
    bne NativeInactiveKong
    bra NativeActiveKong

NativeMapPaletteLoad:
    ; Keep DK and Diddy on their original map palette. Dixie and Kiddy share
    ; the same DKC3 palette, so only the alternate Kong row is needed.
    lda.w #$BF03
    ldy.w #$0080
    ldx.w #$0020
    jsl $B999F1
    jsr NativeFirstKong
    cmp.w #$0002
    bcs .upload
    jsr NativeSecondKong
    cmp.w #$0002
    bcc .done
.upload:
    lda.w #NativeMapPalettes+$0040
    sta.w $4302
    lda.w #$0020
    sta.w $4305
    lda.w #$2200
    sta.w $4300
    sep #$20
    lda.b #NativeMapPalettes>>16
    sta.w $4304
    lda.b #$90
    sta.w $2121
    lda.b #$01
    sta.w $420B
    rep #$20
.done:
    rtl

; Use the normal air-gravity path. Swimming, objects and companion motion
; retain their original physics. The selected Dixie can hold Y to glide.
NativeCanGlide:
    tya
    lsr
    cmp.w $056F
    bne .no
    lda.w $0510,y
    bne .no
    lda.w $050E
    bit.w #$4000
    beq .no
    lda.w $16F3,y
    bne .no
    lda.w $0EF1,y
    bpl .no
    lda.w $10D1,y
    cpy.w #$0004
    bne .animation
    sec
    sbc.w #$0068
.animation:
    cmp.w #$0005
    beq .yes
    cmp.w #$0007
    beq .yes
    cmp.w #$0015
    beq .yes
.no:
    clc
    rts
.yes:
    sec
    rts

NativeAirGravity:
    cmp.w #$0000
    bpl .store
    cmp.w #$FE80
    bcs .store
    pha
    phy
    txy
    jsr NativeSelectedKong
    bcc .original
    cmp.w #$0002
    bne .original
    jsr NativeCanGlide
    bcc .original
    ply
    pla
    lda.w #$FE80
    bra .store
.original:
    ply
    pla
.store:
    sta.w $0EF1,x
    jml $BFAF68

; Character sounds follow the selected player in either original actor slot.
NativeSoundDispatch:
    pha
    lda.l $7E1E15
    bit.w #$0040
    beq .dispatch
    lda.b $F5
    cmp.w #$0013
    beq .donkeyOnly
    cmp.w #$0003
    beq .diddyOnly
    cmp.w #$0005
    beq .diddyOnly
    cmp.w #$0043
    beq .damage
    cmp.w #$0046
    beq .damage
    ldx.w #$0000
.findVoice:
    lda.l NativeVoicePairs,x
    cmp.b $F5
    beq .firstSlot
    lda.l NativeVoicePairs+2,x
    cmp.b $F5
    beq .secondSlot
    txa
    clc
    adc.w #$0008
    tax
    cpx.w #NativeVoicesEnd-NativeVoicePairs
    bcc .findVoice
    bra .dispatch
.firstSlot:
    jsr NativeFirstKong
    bra .mappedVoice
.secondSlot:
    jsr NativeSecondKong
.mappedVoice:
    asl
    stx.b $F5
    clc
    adc.b $F5
    tax
    lda.l NativeVoicePairs,x
    beq .skipVoice
    sta.b $F5
    bra .dispatch
.donkeyOnly:
    jsr NativeFirstKong
    bne .skipVoice
    bra .dispatch
.diddyOnly:
    jsr NativeSecondKong
    cmp.w #$0001
    bne .skipVoice
    bra .dispatch
.damage:
    ; Gnawty uses the same command as Diddy's hurt voice in DKC1.
    ; Remap the voice only when the current actor is a player.
    phy
    ldy.b $82
    jsr NativeSelectedKong
    ply
    bcc .dispatch
    asl
    tax
    lda.l NativeDamageVoices,x
    sta.b $F5
.dispatch:
    pla
    ora.b $F5
    tax
    jsl $8AB1AA
    rtl
.skipVoice:
    stz.b $F5
    pla
    rtl

NativeVoicePairs:
    ; DK, Diddy, Dixie, Kiddy. Preserve physical sounds by weight class.
    dw $0064,$0033,$0033,$0064
    dw $003F,$003E,$0000,$0000
    dw $0040,$0041,$0000,$0000
    dw $005E,$005D,$005D,$005E
    dw $0075,$0076,$0076,$0075
NativeVoicesEnd:
NativeDamageVoices:
    dw $0046,$0043,$0044,$0045

NativeSamplePointer:
    cpx.w #$0046*3
    bne .original
    lda.w #NativeVoiceSample
    sta.b $4C
    lda.w #NativeVoiceSample>>16
    sta.b $4E
    rtl
.original:
    lda.l $89FF00,x
    sta.b $4C
    lda.l $89FF02,x
    and.w #$00FF
    sta.b $4E
    rtl

; X holds three times the sample ID, $12 is the original song sample-list
; address, and $06 is the packed sample cursor. Keep the few displaced
; samples in ARAM gaps where they do not overlap the song or effect data.
NativeSampleDestination:
    cpx.w #$0006*3
    beq .common
    lda.b $12
    cmp.w #$B281
    beq .islandSwing
    cmp.w #$B305
    beq .songEight
    cmp.w #$B39F
    bne .packed
    cpx.w #$002C*3
    bne .packed
    lda.w #$1C15
    bra .destination
.islandSwing:
    cpx.w #$001C*3
    bne .packed
    lda.w #$227D
    bra .destination
.songEight:
    cpx.w #$000C*3
    bne .packed
    lda.w #$1CA0
    bra .destination
.common:
    lda.w #$31C0
    bra .destination
.packed:
    lda.b $06
.destination:
    sta.b $08
    xba
    sep #$20
    rtl

NativeAdvanceSample:
    lda.b $06
    cmp.b $08
    bne .done
    clc
    adc.b $0E
    sta.b $06
.done:
    rtl

NativeVoiceSample:
    incbin "native-dkc3-voice.brr"
NativeCommonSamples:
    incbin "native-common-samples.bin"
NativeEffects:
    incbin "native-sfx.bin"

NativeHoverPointers:
    incbin "native-hover.bin"
NativeHoverCycle:
    incbin "native-hover-cycle.bin"
NativeMapPalettes:
    incbin "native-map-palettes.bin"
NativeKongPalettes:
    incbin "native-palettes.bin"
