"""Exercise original DKC1 mount transitions and the displayed rider graphics."""
from argparse import ArgumentParser
from pathlib import Path
from struct import pack_into
import json

from emulator import Emulator
from test_cartridge import (B, RIGHT, choose_team, exact_vram_pose, reach_internal_map,
                            reach_map, reach_stage, test_pickup_and_tag, vram_graphic_matches,
                            wait_for_vram_pose)
from test_interactions import run_code
from test_maps import cgram, enter_internal_map

MOUNTS = (('Rambi', 9, 0x87E1), ('Expresso', 10, 0x8805), ('Winky', 11, 0x87F3),
          ('Enguarde', 12, 0x87C7))
A = 1 << 8


def spawn_mount(emulator, snapshot, player, sprite, script):
    # Allocate the real animal through the game's spawn code, then resume
    # normal gameplay with it beside the active Kong, ready to mount.
    command = bytes((0xA0, script & 255, script >> 8, 0x22, 0x2F, 0x80, 0xB5))
    run_code(emulator, snapshot, command, {0x82: player}, max_frames=10)
    actor = emulator.word(0x86)
    assert actor >= 6 and emulator.word(0xD45 + actor) == sprite
    ram = snapshot.index(b'RAM:131072:') + 11
    resumed = bytearray(snapshot)
    spawned = emulator.snapshot()
    for start, end in ((0x0200, 0x1DC0), (0x1E00, 0x1F000)):
        resumed[ram + start:ram + end] = spawned[ram + start:ram + end]
    pack_into('<H', resumed, ram + 0xB19 + actor, emulator.word(0xB19 + player) + 28)
    pack_into('<H', resumed, ram + 0xBC1 + actor, emulator.word(0xBC1 + player))
    pack_into('<H', resumed, ram + 0x1029 + actor, 3)
    emulator.restore(bytes(resumed))
    return actor


def verify_mounted(emulator, rom, art, kong, player, actor, color_row, button=0):
    previous_animal = previous_rider = None
    for _ in range(26):
        assert emulator.word(0x0510 + player) == actor
        assert (emulator.word(0xC69 + actor) >> 9) & 7 == color_row
        animal = emulator.word(0xAE5 + player)
        rider = emulator.word(0xAE5 + actor)
        # The engine records the queued pose one frame before the DMA.
        animal_checked = any(
            vram_graphic_matches(
                emulator, rom, int.from_bytes(rom[0x3BCC9C + pose:0x3BCC9F + pose], 'little'), player
            )
            for pose in (animal, previous_animal) if pose
        )
        rider_checked = any(exact_vram_pose(emulator, rom, art, kong, actor, pose)
                            for pose in (rider, previous_rider) if pose)
        if rider_checked and animal_checked:
            return
        previous_animal, previous_rider = animal, rider
        emulator.run(buttons=button)
    raise AssertionError((kong, actor, 'mounted tiles', rider_checked, animal_checked))


def test_mount(emulator, rom, art, stage, kong, player, mount, output):
    name, sprite, script = mount
    emulator.restore(stage)
    color_row = (emulator.word(0xC69 + player) >> 9) & 7
    start = 128 + color_row * 16
    colors = cgram(emulator)[start:start + 16]
    actor = spawn_mount(emulator, stage, player, sprite, script)
    for frame in range(100):
        if emulator.word(0x0510 + player) == actor:
            break
        if 15 <= frame < 38:
            emulator.run(buttons=RIGHT)
        elif 38 <= frame < 62:
            emulator.run(buttons=RIGHT | B)
        else:
            emulator.run()
    else:
        raise AssertionError((name, kong, 'could not mount through original collision'))
    emulator.run(25)
    verify_mounted(emulator, rom, art, kong, player, actor, color_row)
    assert cgram(emulator)[start:start + 16] == colors
    emulator.capture.save(output / f'{name}-{kong}-mounted.png')
    emulator.run(12, RIGHT)
    verify_mounted(emulator, rom, art, kong, player, actor, color_row, RIGHT)
    emulator.press(A)
    emulator.run(40)
    assert emulator.word(0x0510 + player) == 0
    wait_for_vram_pose(emulator, rom, art, kong, player)
    print(f'{name}, Kong {kong}: mounted and dismounted with the original animal and selected rider', flush=True)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--core', required=True, type=Path)
    parser.add_argument('--rom', required=True, type=Path)
    parser.add_argument('--assets', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    rom = args.rom.read_bytes()
    art = json.loads(args.assets.read_text())
    emulator = Emulator(args.core)
    emulator.load(args.rom)
    emulator.run(12)
    choose_team(emulator, (3, 2))
    reach_map(emulator)
    island = emulator.snapshot()
    reach_internal_map(emulator)
    reach_stage(emulator)
    kiddy = emulator.snapshot()
    test_pickup_and_tag(emulator, args.output, 3, 2, rom, art, True)
    emulator.run(100)
    dixie = emulator.snapshot()
    for mount in MOUNTS[:3]:
        test_mount(emulator, rom, art, kiddy, 3, 2, mount, args.output)
        test_mount(emulator, rom, art, dixie, 2, 4, mount, args.output)
    for slot, kong in ((0, 3), (1, 2)):
        enter_internal_map(emulator, island, 0xBF, slot)
        reach_stage(emulator)
        assert emulator.word(0x32) == 3 and emulator.word(0x56F) == slot + 1
        test_mount(emulator, rom, art, emulator.snapshot(), kong, 2 + slot * 2,
                   MOUNTS[3], args.output)
    emulator.close()


if __name__ == '__main__':
    main()
