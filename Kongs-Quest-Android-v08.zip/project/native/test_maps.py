"""Load every DKC1 stage map through its original renderer in stock Snes9x."""
from argparse import ArgumentParser
from pathlib import Path
from struct import pack, unpack_from
from tempfile import TemporaryDirectory
import json

from emulator import Emulator
from native_assets import map_palette_data, tables
from test_cartridge import choose_team, reach_map, wait_for_vram_pose
from test_interactions import run_code

MAPS = (
    ('Kongo Jungle', 0x16), ('Monkey Mines', 0xD9), ('Vine Valley', 0xA5),
    ('Gorilla Glacier', 0x24), ('Kremkroc Industries', 0x40), ('Chimp Caverns', 0x30),
)


def cgram(emulator):
    state = emulator.snapshot()
    offset = state.index(b'PPU:002652:') + 11 + 64
    return unpack_from('>256H', state, offset)


def enter_internal_map(emulator, state, entrance, slot):
    # Run the original transition with both Kongs present, as after rescuing
    # the partner in a level.
    run_code(emulator, state, bytes.fromhex('5C F8 E1 80'), {
        0x3E: entrance, 0x40: entrance, 0x56F: slot + 1, 0x579: 1, 0x57D: 0,
    }, returns=False)
    emulator.run(260)
    assert emulator.word(0x3E) == entrance and emulator.word(0x527) == 1


def original_palettes(emulator, rom):
    with TemporaryDirectory() as directory:
        path = Path(directory) / 'original-dkc1.sfc'
        path.write_bytes(rom)
        emulator.load(path)
        emulator.run(12)
        reach_map(emulator)
        state = emulator.snapshot()
        island = cgram(emulator)
        palettes = {}
        for _, entrance in MAPS:
            for slot in (0, 1):
                enter_internal_map(emulator, state, entrance, slot)
                palettes[entrance, slot] = cgram(emulator)
        emulator.lib.retro_unload_game()
    return island, palettes


def compare_palettes(actual, expected, imported):
    expected = list(expected)
    if imported:
        expected[144:160] = imported
    assert actual == tuple(expected), [i for i, (a, b) in enumerate(zip(actual, expected)) if a != b]


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--core', required=True, type=Path)
    parser.add_argument('--rom', required=True, type=Path)
    parser.add_argument('--assets', required=True, type=Path)
    parser.add_argument('--input', required=True, type=Path, help='Original Jornada container')
    args = parser.parse_args()
    rom = args.rom.read_bytes()
    art = json.loads(args.assets.read_text())
    cartridge = args.input.read_bytes()
    original = {game: tables(game, cartridge) for game in (1, 2, 3)}
    palettes = map_palette_data(original)
    imported = unpack_from('<16H', palettes, 64)
    assert palettes[64:96] == palettes[96:128]
    emulator = Emulator(args.core)
    island, reference = original_palettes(emulator, original[1][0])
    emulator.load(args.rom)
    emulator.run(12)
    choose_team(emulator, (3, 2))
    reach_map(emulator)
    compare_palettes(cgram(emulator), island, imported)
    state = emulator.snapshot()
    for name, entrance in MAPS:
        for team in ((3, 2), (0, 1), (0, 2), (3, 1)):
            emulator.sram[0x1FF0:0x1FF2] = pack('<H', 0x4B00 | team[0] | team[1] << 2)
            for slot in (0, 1):
                enter_internal_map(emulator, state, entrance, slot)
                assert emulator.word(0xD45) == 0x10 and emulator.word(0xD47) == 0x12
                compare_palettes(cgram(emulator), reference[entrance, slot], imported if max(team) >= 2 else None)
                for actor, kong in ((0, team[slot]), (2, team[1 - slot])):
                    wait_for_vram_pose(emulator, rom, art, kong, actor)
                    row = 1 if kong >= 2 else 6
                    assert (emulator.word(0xC69 + actor) >> 9) & 7 == row
        print(f'{name}: both Kong sprites and every non-Kong palette match the original game', flush=True)
    emulator.close()


if __name__ == '__main__':
    main()
