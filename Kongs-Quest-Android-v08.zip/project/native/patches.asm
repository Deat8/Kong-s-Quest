assert read4($BBA7AB) == $BBCC9CBF
org $BBA7AB
    jsl NativeRenderPointer
    nop #13
assert read4($BBA890) == $BBCC9CBF
org $BBA890
    jsl NativeRenderPointer
    nop #13

assert read4($BE8384) == $189882A6
org $BE8384
    jsl NativeGrip
assert read4($BE83A3) == $189882A6
org $BE83A3
    jsl NativeGrip

assert read4($BFA7EC) == $D00002E0
org $BFA7EC
    jml NativeStompWeight
    nop
assert read4($BFA7A1) == $F00002E0
org $BFA7A1
    jml NativeStompLaunch
    nop
assert read4($BFA755) == $D00004E0
org $BFA755
    jml NativeHitboxWeight
    nop

assert read4($BDF274) == $8F9D8CA5
org $BDF274
    jsl NativePaletteQueue
    nop #17
assert read4($B6B128) == $B14820DA
org $B6B128
    jsl NativePaletteDecompose
    nop

assert read4($80E4F6) == $A0BF03A9
org $80E4F6
    jsl NativeMapPaletteLoad
    nop #9

assert read4($BFAF64) == $600EF19D
org $BFAF64
    jml NativeAirGravity

assert read4($BFB511) == $D00004E0
org $BFB511
    jml NativeJumpWeight
    nop

assert read4($BEA6B0) == $BEA7D681
org $BEA6B1
    dl NativeDKGroundJump
assert read4($BEB1C3) == $BEA7C181
org $BEB1C4
    dl NativeDiddyGroundJump

assert read4($BFFB1D) == $22AAF505
org $BFFB1D
    jsl NativeSoundDispatch
    nop #3

assert read4($BBA7CE) == $F00AE5DD
org $BBA7CE
    jml NativeComparePoseFirst
    nop
assert read4($BBA99B) == $D00AE5DD
org $BBA99B
    jml NativeComparePoseSecond
    nop

assert read4($BE80C7) == $BE8572BF
org $BE80C7
    jsl NativeAnimationScript
assert read4($BE8154) == $BE8572BF
org $BE8154
    jsl NativeAnimationScript

; Bank BE's animation interpreter reads its scripts from this bank.
; Place the new scripts in the zero-filled area after the original data.
assert read4($BEF159) == $00000000
assert read4($BEF1FF) == $00000000
org $BEF159
NativeDixieBounce:
    incbin "native-dixie-bounce.bin"
NativeKiddyBounce:
    incbin "native-kiddy-bounce.bin"
assert pc() <= $BEF1FF

; Upload the original SFX bank with the two new voice commands appended.
assert read4($8AB149) == $862D95A2
org $8AB149
    ldx.w #NativeEffects
    stx.b $4C
    lda.b #NativeEffects>>16
    sta.b $4E

; The directory holds at most 41 samples, including the new global sample.
assert read2($8AB3F4) == $B245
assert read2($8AB3F9) == $008A
org $8AB3F4
    dw NativeCommonSamples
org $8AB3F9
    dw NativeCommonSamples>>16
assert read2($8AB42F) == $3300
org $8AB42F
    dw $32A4

assert read4($8AB466) == $89FF00BF
org $8AB466
    jsl NativeSamplePointer
    nop #11
assert read4($8AB485) == $06A520E2
org $8AB485
    jsl NativeSampleDestination
    nop #3
assert read4($8AB491) == $088506A5
org $8AB491
    lda.b $08
    nop #2
assert read4($8AB4BD) == $651806A5
org $8AB4BD
    jsl NativeAdvanceSample
    nop #3

; Move the original 64 ms echo buffer to the last 8 KiB of ARAM.
; Its DSP delay and mix parameters are preserved.
assert read3($8AAF38) == $F3DF8F
assert read3($8AAF44) == $02DF8F
assert read2($8AAF53) == $FF68
org $8AAF39
    db $E0
org $8AAF45
    db $E0
org $8AAF54
    db $00
