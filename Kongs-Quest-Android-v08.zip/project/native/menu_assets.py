from struct import pack
from PIL import Image, ImageDraw, ImageFont


def tile_word(character, palette=0):
    return ord(character) | (palette << 10)


def menu_assets(directory):
    font = ImageFont.load_default(size=9)
    tiles = bytearray()
    for code in range(128):
        image = Image.new('1', (8, 8))
        if 33 <= code <= 126:
            character = chr(code)
            left, top, right, bottom = font.getbbox(character)
            ImageDraw.Draw(image).text(((8 - (right - left)) // 2 - left, -top), character, 1, font=font)
        for y in range(8):
            tiles.extend((sum(image.getpixel((x, y)) << (7 - x) for x in range(8)), 0))
    (directory / 'menu-font.bin').write_bytes(tiles)

    tilemap = [tile_word(' ')] * (32 * 32)

    def row(y, value, palette, x=None):
        if x is None:
            x = (32 - len(value)) // 2
        assert 0 <= x <= 32 - len(value)
        tilemap[y * 32 + x:y * 32 + x + len(value)] = [tile_word(c, palette) for c in value]

    row(3, 'DONKEY KONG COUNTRY', 1)
    row(5, 'A GRANDE JORNADA', 0)
    row(7, 'CAPITULO 1', 2)
    row(10, 'PRIMEIRO KONG', 2, 6)
    row(15, 'SEGUNDO KONG', 2, 6)
    row(21, 'CIMA/BAIXO    ESCOLHER CAMPO', 0, 2)
    row(23, 'ESQ/DIR       TROCAR KONG', 0, 2)
    row(25, 'START         JOGAR', 1, 2)
    (directory / 'menu-map.bin').write_bytes(pack('<1024H', *tilemap))

    names = ['DONKEY KONG', 'DIDDY KONG', 'DIXIE KONG', 'KIDDY KONG']
    words = [tile_word(c, 0) for name in names for c in name.ljust(16)]
    (directory / 'menu-names.bin').write_bytes(pack('<64H', *words))
