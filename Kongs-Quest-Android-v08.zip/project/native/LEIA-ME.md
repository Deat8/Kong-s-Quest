# Jornada Kong — cartucho nativo de DKC1

O arquivo `Jornada-Kong-DKC1-Nativa-Experimental.sfc` tem 8 MiB, usa ExHiROM e executa o seletor e as alterações do jogo em código 65816. Abra o arquivo em Snes9x ou bsnes. Use cima e baixo para selecionar a posição na dupla, esquerda e direita para escolher o Kong e Start para confirmar. O jogo guarda a dupla na bateria do cartucho.

Você pode escolher qualquer dupla de DK, Diddy, Dixie e Kiddy, em qualquer ordem e sem repetir um personagem. A fase inicial segue a regra de recrutar o parceiro pelo primeiro barril DK. A Dixie plana com Y enquanto cai sem objeto na mão. DK e Kiddy usam a classe pesada nas rotinas de pisão, quique, colisão e salto alteradas.

O mapa da ilha e os seis mapas internos usam as cores originais de DKC1 para o cenário, os ícones e os veículos. A dupla usa as miniaturas originais de DK e Diddy ou as miniaturas e a paleta compartilhada de Dixie e Kiddy em DKC3. A miniatura do líder acompanha a troca de Kong, e a do parceiro aparece quando ele está presente.

Ao montar Rambi, Expresso, Winky ou Enguarde, o desenho usa os quadros do animal em DKC1 e os quadros do Kong que o está montando. Os sprites de Dixie e Kiddy vêm da posição de montaria de DKC3. A posição desses sprites foi ajustada para o encaixe de DKC1.

A troca de liderança entre Dixie e Kiddy usa os quadros dos dois em DKC3. A posição do barril vem dos deslocamentos originais quando a pose de referência fornece o encaixe. O motor de DKC1 ainda determina a duração das ações e o momento de soltar o barril. Ações sem uma animação correspondente usam uma pose do Kong selecionado.

Ao pisar num inimigo, Dixie usa a sequência de quique de DKC3 e Kiddy usa a cambalhota aérea de DKC3. O impulso e a desaceleração do quique dos dois vêm de DKC3. O salto normal usa o impulso e a gravidade do personagem nas duas posições da dupla. A altura dos saltos curtos e longos de Dixie e Kiddy ficou a até um pixel da referência.

Dixie e Kiddy usam a pose inicial de dano e a voz de DKC3, com a mesma amostra BRR nos tons de cada personagem. A derrota do Gnawty toca o efeito original de DKC1. As vozes exclusivas de DK e Diddy identificadas no motor de DKC1 seguem o Kong selecionado nas ações correspondentes. O carregamento de áudio realoca algumas amostras de DKC1 no SPC700 e mantém os dados originais e a duração do eco. Reinicie o jogo ao substituir a ROM para carregar as amostras.

Esta etapa contém DKC1. A transição para DKC2 e DKC3 no mesmo cartucho, os demais efeitos exclusivos de Dixie e Kiddy e a fidelidade de todas as ações, físicas e animações originais seguem pendentes. Os outros emuladores e o console ainda precisam de validação.

## Compilar

Use Python 3 com NumPy e Pillow e Asar 1.91. Execute a partir da raiz deste pacote.

```sh
python3 project/native/build.py \
  --asar /caminho/para/asar \
  --input recovered/Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc \
  --output Jornada-Kong-DKC1-Nativa-Experimental.sfc
```

O arquivo em `recovered` é a base com os três jogos usada para extrair o DKC1 e os dados de referência. A compilação valida os CRC32 das três revisões originais. A ROM de saída leva o DKC1 e os recursos importados para ele. O manifesto de quadros fica em `work/native-dkc1/native-art.json`.

## Reproduzir os testes

Os testes usaram os núcleos libretro Snes9x `fae2fea08f74180759ef540ee94259213f503480` e bsnes-mercury performance `79d7f9de218b6ffa65a80bbdc5828532bc239232` sem modificações.

```sh
python3 project/native/test_cartridge.py \
  --core /caminho/para/snes9x_libretro.so \
  --rom Jornada-Kong-DKC1-Nativa-Experimental.sfc \
  --assets work/native-dkc1/native-art.json \
  --output work/native-dkc1/test-snes9x --snes9x

python3 project/native/test_cartridge.py \
  --core /caminho/para/bsnes_mercury_performance_libretro.so \
  --rom Jornada-Kong-DKC1-Nativa-Experimental.sfc \
  --assets work/native-dkc1/native-art.json \
  --output work/native-dkc1/test-bsnes

python3 project/native/test_interactions.py \
  --core /caminho/para/snes9x_libretro.so \
  --rom Jornada-Kong-DKC1-Nativa-Experimental.sfc \
  --input recovered/Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc

python3 project/native/test_maps.py \
  --core /caminho/para/snes9x_libretro.so \
  --rom Jornada-Kong-DKC1-Nativa-Experimental.sfc \
  --assets work/native-dkc1/native-art.json \
  --input recovered/Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc

python3 project/native/test_mounts.py \
  --core /caminho/para/snes9x_libretro.so \
  --rom Jornada-Kong-DKC1-Nativa-Experimental.sfc \
  --assets work/native-dkc1/native-art.json \
  --output work/native-dkc1/test-mounts

python3 project/native/test_impact.py \
  --core /caminho/para/snes9x_libretro.so \
  --rom Jornada-Kong-DKC1-Nativa-Experimental.sfc \
  --assets work/native-dkc1/native-art.json \
  --input recovered/Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc
```

O teste por controle cobre o seletor, o salvamento da dupla, o mapa da ilha, o mapa interno de Kongo Jungle e o início de Jungle Hijinxs. Dixie e Kiddy recrutam o parceiro pelo primeiro barril DK e trocam a liderança nas duas ordens. No Snes9x, o teste compara os tiles dos quadros com os dados originais e carrega um cenário preservado de barril para os quatro Kongs.

O teste dos mapas compara a memória de cores com o cartucho original na ilha e nos seis mapas internos. Também verifica os tiles das duas miniaturas nos mapas internos com a liderança alternada. O teste de montaria coloca cada animal perto de Dixie e Kiddy pela rotina original de criação de objetos. Exercita montar, deslocar-se e desmontar pelo controle e verifica os tiles do animal e do Kong na VRAM. O teste de interações verifica pisões em Klump, Army e Blue Krusha, a seleção de sons de DK e Diddy e o toque da amostra de DKC3 no DSP emulado para Dixie e Kiddy. A execução completa da campanha e a comparação quadro a quadro de todas as animações continuam pendentes.

O teste de impacto joga contra Gnawty no DKC1 e Sneek no DKC3 original. Compara 30 quadros do quique, a altura, a velocidade e os tiles de Dixie e Kiddy nas duas posições. A pausa inicial de impacto no DKC1 pode ter um quadro a mais dependendo da ordem de atualização dos atores. O teste também verifica a pose e a voz na colisão que causa dano e compara os saltos curtos e longos com a referência.

A ROM testada tem CRC32 `692B91DC` e SHA-256 `7302b2ddcd3f7228ac56ef780911c3146f1e75864da6d08e0341c3d781f7e6e1`.
