"""Compare real enemy contacts in the native cart and the original DKC3."""
from argparse import ArgumentParser
from pathlib import Path
from tempfile import TemporaryDirectory
import json

from emulator import Emulator
from native_assets import tables
from test_cartridge import (B, SELECT, RIGHT, ROOT, NAMES, choose_team, exact_vram_pose,
                            reach_internal_map, reach_map, reach_stage)
from test_interactions import audio_state, run_code, word
from test_maps import enter_internal_map
from extract_native_carry import signed

BOUNCE_FRAMES = 30
TEST_TEAMS = ((3, 2), (2, 3))
APPROACH = {(3, 0): 112, (2, 0): 108, (3, 1): 112, (2, 1): 110}


def reference_kiddy(emulator, stage):
    # Rescue Kiddy through the original DK-barrel routine in the fixture.
    run_code(emulator, stage, bytes.fromhex('22 9C 80 B8'), {0x70: 0xA30, 0x7E: 0, 0x7C: 0})
    updated = emulator.snapshot()
    memory = stage.index(b'RAM:131072:') + 11
    resumed = bytearray(stage)
    start, end = memory + 0x200, memory + 0x1DC0
    resumed[start:end] = updated[start:end]
    emulator.restore(bytes(resumed))
    emulator.run(100)
    emulator.run(3, SELECT)
    emulator.run(237)
    assert emulator.word(0x4F9) == 0x8E6 and emulator.word(0x91E) == 1


def ground_jumps(emulator, y_position, y_speed, direction):
    stage = emulator.snapshot()
    initial_y = emulator.word(y_position)
    jumps = []
    for hold in (1, 38):
        speeds = []
        height = 0
        for frame in range(75):
            emulator.run(buttons=B if frame < hold else 0)
            speed = direction * signed(emulator.word(y_speed))
            if speed > 0 and len(speeds) < 12:
                speeds.append(speed)
            height = max(height, direction * (emulator.word(y_position) - initial_y))
        assert len(speeds) == 12 and height > 0
        jumps.append((speeds, height))
        emulator.restore(stage)
    return jumps


def reference_bounces(emulator, source):
    rom, _, headers = source
    assets = {offset: name for name, (offset, _) in headers.items()}
    fixture = (ROOT / 'project/tests/fixtures/stage3-8.state').read_bytes()
    bounces, jumps = {}, {}
    with TemporaryDirectory() as directory:
        path = Path(directory) / 'original-dkc3.sfc'
        path.write_bytes(rom)
        emulator.load(path)
        emulator.run(2)
        for kong, actor, animation, approach in ((2, 0x878, 0x0D, 90), (3, 0x8E6, 0x94, 101)):
            if kong == 3:
                reference_kiddy(emulator, fixture)
            else:
                emulator.restore(fixture)
            stage = emulator.snapshot()
            emulator.run(140)
            jumps[kong] = ground_jumps(emulator, actor + 0x16, actor + 0x2E, -1)
            emulator.restore(stage)
            emulator.run(approach, RIGHT)
            for tick in range(65):
                if emulator.word(actor + 0x40) == animation:
                    break
                emulator.run(buttons=RIGHT | B if tick < 40 else RIGHT)
            else:
                raise AssertionError((kong, 'the original Sneek stomp did not occur'))
            contact = emulator.word(actor + 0x16)
            trace = []
            for _ in range(BOUNCE_FRAMES):
                assert emulator.word(actor + 0x40) == animation
                pose = emulator.word(actor + 0x24)
                offset = int.from_bytes(rom[0x3C8000 + pose:0x3C8003 + pose], 'little') & 0x3FFFFF
                trace.append((assets[offset], -signed(emulator.word(actor + 0x2E)),
                              contact - emulator.word(actor + 0x16)))
                emulator.run(buttons=RIGHT)
            bounces[kong] = trace
        emulator.lib.retro_unload_game()
    return bounces, jumps


def test_stomp(emulator, rom, art, kong, slot, reference):
    actor = 2 + slot * 2
    animation = 0x17 + 0x68 * slot
    emulator.run(APPROACH[kong, slot], RIGHT)
    for tick in range(70):
        if emulator.word(0x10D1 + actor) == animation:
            break
        emulator.run(buttons=RIGHT | B if tick < 38 else RIGHT)
    else:
        raise AssertionError((kong, slot, 'Gnawty stomp did not occur'))

    assert emulator.word(0xF5) == 0x43, 'Gnawty played a different Kong voice'
    contact = emulator.word(0xBC1 + actor)
    previous = None
    for frame, (name, speed, height) in enumerate(reference):
        # DKC1 can hold the impact for one extra display frame depending on
        # actor update order. Compare the motion after that freeze.
        if frame == 3 and emulator.word(0xEF1 + actor) == reference[0][1]:
            emulator.run(buttons=RIGHT)
        assert emulator.word(0x10D1 + actor) == animation
        pose = emulator.word(0xD11 + actor)
        actual = art['characters'][kong]['mapped'][str(pose)]['target']
        assert actual == name, (kong, slot, frame, actual, name)
        actual_speed = signed(emulator.word(0xEF1 + actor))
        assert actual_speed == speed, (kong, slot, frame, actual_speed, speed)
        actual_height = emulator.word(0xBC1 + actor) - contact
        assert abs(actual_height - height) <= 1, (kong, slot, frame, actual_height, height)
        # On contact, the second slot may need two frames for its first DMA.
        if frame >= 2:
            assert exact_vram_pose(emulator, rom, art, kong, actor, previous), (kong, slot, frame)
        previous = pose
        emulator.run(buttons=RIGHT)
    emulator.run(35)
    assert emulator.word(0x10D1 + actor) != animation, 'Landing did not end the bounce'


def test_damage(emulator, rom, art, kong, slot):
    actor = 2 + slot * 2
    for _ in range(185):
        if emulator.word(0xF5) == kong + 0x42:
            break
        emulator.run(buttons=RIGHT)
    else:
        raise AssertionError((kong, slot, 'the player did not take damage'))
    pose = emulator.word(0xD11 + actor)
    assert art['characters'][kong]['mapped'][str(pose)]['target'] == f'GFX_{NAMES[kong]}_Hurt1'
    pitch = (0x047D, 0x02FF)[kong - 2]
    checked_sound = checked_pixels = False
    for _ in range(6):
        aram, dsp = audio_state(emulator.snapshot())
        source = aram[0x04E0 + 0x46]
        checked_sound |= any(dsp[voice + 4] == source and word(dsp, voice + 2) == pitch
                             and dsp[voice + 8] for voice in range(0, 128, 16))
        checked_pixels |= exact_vram_pose(emulator, rom, art, kong, actor, pose)
        emulator.run()
    assert checked_pixels and checked_sound, (kong, slot, checked_pixels, checked_sound)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--core', required=True, type=Path)
    parser.add_argument('--rom', required=True, type=Path)
    parser.add_argument('--assets', required=True, type=Path)
    parser.add_argument('--input', required=True, type=Path)
    args = parser.parse_args()
    emulator = Emulator(args.core)
    bounces, jumps = reference_bounces(emulator, tables(3, args.input.read_bytes()))
    rom = args.rom.read_bytes()
    art = json.loads(args.assets.read_text())
    for team in TEST_TEAMS:
        emulator.load(args.rom)
        emulator.run(12)
        choose_team(emulator, team)
        reach_map(emulator)
        island = emulator.snapshot()
        for slot, kong in enumerate(team):
            if slot:
                enter_internal_map(emulator, island, 0x16, slot)
            else:
                reach_internal_map(emulator)
            reach_stage(emulator)
            assert emulator.word(0x56F) == slot + 1
            stage = emulator.snapshot()
            actor = 2 + slot * 2
            actual_jumps = ground_jumps(emulator, 0xBC1 + actor, 0xEF1 + actor, 1)
            for (speeds, height), (expected_speeds, expected_height) in zip(actual_jumps, jumps[kong]):
                assert speeds == expected_speeds and abs(height - expected_height) <= 1
            test_stomp(emulator, rom, art, kong, slot, bounces[kong])
            emulator.restore(stage)
            test_damage(emulator, rom, art, kong, slot)
            print(f'{NAMES[kong]} slot {slot + 1}: DKC3 ground jump and bounce physics, '
                  'original bounce frames and damage pose and voice', flush=True)
        emulator.lib.retro_unload_game()
    emulator.lib.retro_deinit()


if __name__ == '__main__':
    main()
