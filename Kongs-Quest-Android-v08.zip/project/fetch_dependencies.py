"""Fetch the pinned Android tools needed by android/build.sh."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import os
import stat
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DOWNLOADS = ROOT / 'work/assets'
DOWNLOADS.mkdir(parents=True, exist_ok=True)
JOBS = [
    ('https://dl.google.com/android/repository/android-ndk-r27d-linux.zip', 'ndk.zip'),
    ('https://dl.google.com/android/repository/build-tools_r35_linux.zip', 'build.zip'),
    ('https://dl.google.com/android/repository/platform-35_r02.zip', 'platform.zip'),
    ('https://repo1.maven.org/maven2/org/eclipse/jdt/ecj/3.40.0/ecj-3.40.0.jar', 'ecj.jar'),
]

def fetch(job):
    url, filename = job
    path = DOWNLOADS / filename
    if not path.exists():
        subprocess.run(['curl', '-fL', '--retry', '2', url, '-o', str(path)], check=True)
    if filename.endswith('.zip'):
        destination = ROOT / 'work/android'
        destination.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(path) as archive:
            archive.extractall(destination)
            for entry in archive.infolist():
                mode = entry.external_attr >> 16
                target = destination / entry.filename
                if stat.S_ISLNK(mode):
                    target.unlink(missing_ok=True)
                    target.symlink_to(archive.read(entry).decode())
                elif mode & 0o111 and target.is_file():
                    target.chmod(mode & 0o777)
    else:
        target = ROOT / 'work/tools' / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
    print(filename, 'ready', flush=True)

with ThreadPoolExecutor(max_workers=4) as executor:
    list(executor.map(fetch, JOBS))
