from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ['45659', '45684', '45661', '45588']
# Row bounds, selected source frames, then barrel centers in the 64 pixel cell.
CARRY = [
    [(620,680,[6]*6),(690,768,[0,1,3,5,7,9]),(620,680,[0,1,2,3,4,6]),(690,768,[10,11,12,13,14,15]),(690,768,[0]*6)],
    [(598,643,[4]*6),(598,643,[4,5,7,8,10,11]),(598,643,[0,1,2,3,4,4]),(660,718,[0,1,2,3,4,5]),(598,643,[4]*6)],
    [(620,671,[12]*6),(696,744,[0,3,5,8,11,14]),(620,671,[0,2,4,6,8,11]),(776,826,[0,2,4,6,8,10]),(620,671,[12]*6)],
    [(1387,1431,[5]*6),(1387,1431,[6,7,9,11,13,15]),(1387,1431,[0,1,2,3,4,5]),(1294,1350,[6,7,9,11,13,15]),(1387,1431,[9]*6)],
]
GRIPS = [(32,4),(53,43),(49,28),(54,43)]
THROW_GRIPS = [
    [(32,4),(35,8),(44,18),(53,33),(55,42),(58,46)],
    [(53,43),(52,40),(46,43),(38,45),(45,42),(55,40)],
    [(49,28),(48,29),(49,29),(45,35),(56,42),(57,47)],
    [(54,43),(54,48),(54,51),(55,50),(60,32),(58,20)],
]

def sprites(image, top, bottom):
    rgb=np.asarray(image)[top:bottom,:1120]
    mask=np.any(rgb!=np.asarray(image)[0,0],axis=-1)
    # Discard captions and preserve every complete frame in its original pixel size.
    if top == 620 and image.width == 1240:
        mask[:13,:300] = False
    active=np.any(mask,axis=0)
    edges=np.where(np.diff(np.pad(active,(1,1)).astype(np.int8)))[0]
    result=[]
    for a,b in zip(edges[::2],edges[1::2]):
        ys=np.flatnonzero(np.any(mask[:,a:b],axis=1))
        if b-a<16 or b-a>85 or len(ys)<20:
            continue
        rgba=np.dstack((rgb[ys[0]:ys[-1]+1,a:b],mask[ys[0]:ys[-1]+1,a:b]*255)).astype('uint8')
        sprite=Image.fromarray(rgba)
        if sprite.width>64 or sprite.height>63:
            sprite.thumbnail((64,63),Image.Resampling.NEAREST)
        result.append(sprite)
    return result

atlas=bytearray()
metadata=bytearray()
preview=Image.new('RGB',(6*80,4*5*80),'#26302c')
for kong, source in enumerate(SOURCES):
    image=Image.open(ROOT/'work/assets'/f'{source}.png').convert('RGB')
    for motion,(top,bottom,order) in enumerate(CARRY[kong]):
        frames=sprites(image,top,bottom)
        print(source,motion,len(frames),order,flush=True)
        assert max(order)<len(frames)
        for frame,index in enumerate(order):
            sprite=frames[index]
            cell=Image.new('RGBA',(64,64))
            cell.paste(sprite,((64-sprite.width)//2,63-sprite.height))
            rgba=np.asarray(cell).astype(np.uint16)
            pixels=((rgba[:,:,0]>>3)<<11)|((rgba[:,:,1]>>2)<<5)|(rgba[:,:,2]>>3)
            pixels=np.where(rgba[:,:,3],np.maximum(pixels,1),0)
            atlas.extend(pixels.astype('<u2').tobytes())
            gx,gy=THROW_GRIPS[kong][frame] if motion==3 else GRIPS[kong]
            if motion==2:
                # The pickup lifts the object from the ground to the carry grip.
                gy=round(52+(gy-52)*frame/5)
            metadata.extend((gx&255,gy&255))
            preview.paste(cell,(frame*80+8,(kong*5+motion)*80+8),cell)
assert len(atlas)==0xf0000
rom=bytearray((ROOT/'recovered/Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc').read_bytes()[:0x1330000])
rom[0x7f20:0x7f24]=b'ANM3'
rom.extend(atlas)
rom.extend(metadata)
# Preserve the usual checksum/complement invariant for the extended container.
rom[0xffdc:0xffe0]=bytes((255,255,0,0))
checksum=sum(rom)&65535
rom[0xffdc:0xffe0]=(checksum^65535).to_bytes(2,'little')+checksum.to_bytes(2,'little')
(ROOT/'Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc').write_bytes(rom)
preview.save('/tmp/carry-atlas-preview.png')
