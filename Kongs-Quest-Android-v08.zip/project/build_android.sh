#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
cd "$root"
python3 - <<'PY'
from pathlib import Path
import shutil
source = Path('work/core')
target = Path('work/core-android')
shutil.copytree(source, target, dirs_exist_ok=True,
                ignore=shutil.ignore_patterns('.git', '*.o', '*.so', '__pycache__'))
PY
ndk="$root/work/android/android-ndk-r27d/toolchains/llvm/prebuilt/linux-x86_64/bin"
make -s clean -C work/core-android/libretro
make -s -j 6 -C work/core-android/libretro platform=unix \
    CC="$ndk/aarch64-linux-android23-clang" CXX="$ndk/aarch64-linux-android23-clang++" \
    AR="$ndk/llvm-ar" 'LDFLAGS=-static-libstdc++ -Wl,-z,max-page-size=16384'
bash project/android/build.sh
