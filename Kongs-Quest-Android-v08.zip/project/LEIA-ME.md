# Jornada Kong

O [cartucho nativo de DKC1](native/LEIA-ME.md) abre em Snes9x e bsnes sem modificações e inclui seleção da dupla, sprites e alterações de física no jogo. A campanha dos três jogos ainda está em integração.

## Leitor 4.5 experimental

Leia `project/ESTADO-INTEGRACAO.md` para o estado atual e as limitações. Esta versão inclui gráficos nativos nas ações de carregamento, com sincronização do arremesso e da duração de pegada; a integração completa permanece pendente. Use o mesmo arquivo SFC 4.3 no novo leitor.

Projeto reconstruído para corrigir os personagens carregando objetos na campanha combinada.

A ROM usa o leitor Android próprio incluído na entrega. O arquivo reúne os dados dos três jogos, a seleção de dois personagens distintos e os gráficos adicionais. As rotinas de campanha e renderização ficam no núcleo modificado em `work/core/journey.cpp` e `work/core/journey_gfx.h`.

## Compilar no Linux

São necessários Python 3 com Pillow e NumPy, GNU make, compiladores C/C++, Java 17 ou posterior, curl e zip.

1. Na raiz deste pacote, execute `python3 project/fetch_dependencies.py` para obter NDK r27d, Android 35, build tools 35 e o compilador Java ECJ 3.40.
2. Execute `python3 project/build_carry_atlas.py` para gerar a ROM atualizada a partir do cartucho-base preservado em `recovered` e dos sprites em `work/assets`.
3. Execute `bash project/build_android.sh` para compilar o núcleo ARM64 e gerar o APK 4.5 experimental.

A chave de assinatura desta reconstrução está em `project/android/jornada-signing.p12`. O script de compilação reutiliza essa chave nas próximas versões. O aplicativo usa o pacote `org.jornadakong.player.rebuilt`, com progresso próprio. A assinatura 4.2 foi perdida e essa compilação instala em paralelo à anterior.

## Testes

Compile o núcleo de teste com `make -s -j 6 -C work/core/libretro`.

Execute, nesta ordem, `python3 project/tests/test_campaign.py`, `python3 project/tests/test_carry_render.py`, `python3 project/tests/test_second_carry.py` e `python3 project/tests/test_third_carry.py`.

Os testes cobrem as 12 duplas distintas, a correção de seleções antigas com personagens repetidos, as condições de passagem entre capítulos e o carregamento do progresso após reabrir o cartucho. As verificações de barris usam pontos de teste preservados em `project/tests/fixtures`. O teste do terceiro capítulo utiliza uma fase carregada por uma entrada de depuração e isola os inimigos da interação com o barril.

Foram inspecionadas imagens de carregamento, caminhada, virada e arremesso dos quatro Kongs nos três capítulos. O APK teve assinatura e estrutura verificadas. A instalação e os controles no aparelho Android ainda precisam de validação.

## Base e créditos

Emulação Snes9x, versão de origem `fae2fea08f74180759ef540ee94259213f503480`, obtida de https://github.com/libretro/snes9x. A licença está em `work/core/LICENSE`.

Sprites originais de Rare e Nintendo, obtidos das folhas 45659, 45684, 45661 e 45588 de https://www.spriters-resource.com. A campanha usa o cartucho fornecido pelo usuário.
