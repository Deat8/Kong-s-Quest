"""Measure actual native object release, not just the replacement animation."""
import harness as h
from pathlib import Path
RELEASE=(22,19,29,18)
DURATION=(44,41,45,46)
PICKUP=(16,11,32,15)

def prepare(chapter,kong):
 h.load(h.ROOT/'Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc')
 h.sram[0x1800:0x1807]=list(b'DKCJ')+[chapter-1,0,0];h.sram[0x1807]=0xa0|kong|(((kong+1)%4)<<2)
 h.run(35);h.press(8);h.run(160)
 filename='held-native.state' if chapter==1 else f'stage{chapter}-'+('10.state' if chapter==2 else '8.state')
 h.restore((Path(__file__).parent/'fixtures'/filename).read_bytes())
 if chapter==3:
  for _ in range(100):
   h.run(1,130)
   if h.word(0x186b):break
 h.run(90,2)
 return (0x16f5,0xd7a,0x186b)[chapter-1],(0x10d3,0xe18,0x8b8)[chapter-1]
for chapter in (1,2,3):
 for kong in range(4):
  held,animation=prepare(chapter,kong)
  assert h.word(held),(chapter,kong,'no held object')
  start=release=end=None
  logical=0; previous=None; logical_release=logical_end=None
  timer=(0x1107,0xe1a,0x8ba)[chapter-1]
  script=(0x116f,0xe1e,0x8be)[chapter-1]
  throw_id=(0x4a,0x14,0x15)[chapter-1]
  # Original engine slot 0 is DK, Diddy, Dixie respectively.
  for tick in range(100):
   h.run(1,0)
   anim=h.word(animation)
   current=(h.word(timer),h.word(script))
   if start is None and anim==throw_id:start=tick;previous=current
   elif start is not None and current!=previous:logical+=1;previous=current
   if start is not None and release is None and not h.word(held):release=tick-start;logical_release=logical
   if start is not None and anim!=throw_id:end=tick-start;logical_end=logical;break
  print('timing',chapter,kong,'release',release,'end',end,'logic',logical_release,logical_end,'expected',RELEASE[kong],DURATION[kong],flush=True)
  assert start is not None and release is not None and end is not None,(chapter,kong,start,release,end)

  assert abs(logical_release-RELEASE[kong])<=1,(chapter,kong,'release mismatch',logical_release,RELEASE[kong])
  assert abs(logical_end-DURATION[kong])<=1,(chapter,kong,'duration mismatch',logical_end,DURATION[kong])
print('Release and full action duration match donor scripts within one logic tick for all 12 cases',flush=True)
