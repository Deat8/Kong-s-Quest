"""Measure pickup completion in native DKC3 logic for all selected Kongs."""
from pathlib import Path
import harness as h
for kong,duration in enumerate((16,11,32,15)):
 h.load(h.ROOT/'Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc')
 h.sram[0x1800:0x1807]=list(b'DKCJ')+[2,0,0];h.sram[0x1807]=0xa0|kong|(((kong+1)%4)<<2)
 h.run(35);h.press(8);h.run(160)
 h.restore((Path(__file__).parent/'fixtures/stage3-8.state').read_bytes())
 start=None;previous=None;logical=0;end=None
 for tick in range(180):
  h.run(1,130 if start is None else 2)
  animation=h.word(0x8b8);current=(h.word(0x8ba),h.word(0x8be))
  if start is None and animation==0x10:start=tick;previous=current
  elif start is not None:
   if current!=previous:logical+=1;previous=current
   if animation!=0x10:end=tick-start;break
 assert end is not None,(kong,'pickup did not complete')
 assert abs(logical-duration)<=1,(kong,logical,duration)
 assert h.word(0x186b),(kong,'object lost during pickup')
 print('pickup',kong,'logic',logical,'expected',duration,'wall',end,flush=True)
print('Four pickup actions complete at donor durations and keep the object',flush=True)
