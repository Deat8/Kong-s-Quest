"""Regression of v0.8 hold-to-skip guard on real libretro frames.

Victory marker is injected into WRAM: does not establish final-boss completion
in normal gameplay. All assertions use the modified Snes9x core.
"""
from pathlib import Path
import harness as h

ROM = Path('/mnt/data/Donkey-Kong-Country-Kongs-Quest-Campanha-Unica-Emulador-Proprio.sfc')
assert ROM.is_file()


def start_chapter_one():
    h.load(ROM)
    h.run(35)
    h.press(8)
    h.run(160)
    assert h.page() == 1


start_chapter_one()
# Manual chapter advancement must not work before chapter completion.
h.run(65, 0xC08)
assert h.page() == 1, 'manual override bypassed victory gate'
print('PASS: no manual skip before victory')

# Establish armed state: the marker must first be observed low.
h.write(0x5e1, h.word(0x5e1) & ~1)
h.run(8)
# A victory takes 8 successive frames, not a single transient sample.
h.write(0x5e1, h.word(0x5e1) | 1)
h.run(8)
assert h.sram[0x1804] == 1
print('PASS: victory requires stable signal')

# Short/accidental taps, even following a victory, cannot cut the ending short.
h.run(8, 0xC08)
assert h.page() == 1
h.run(3)
h.run(48, 0xC08)
assert h.page() == 1, 'tap counter not reset on button release'
h.run(3)
print('PASS: short or interrupted shortcut does not skip ending')

# A deliberate one-second hold remains available as a safety fallback.
h.run(62, 0xC08)
h.run(3)
assert h.page() == 2, ('held fallback did not advance', h.page())
print('PASS: deliberate one-second hold advances to DKC2')

# Retains chapter-one progress in battery across cold loads.
battery = bytes(h.sram)
h.load(ROM)
h.sram[:] = battery
h.run(35)
h.press(8)
h.run(160)
assert h.page() == 2 and h.sram[0x1804] == 1
print('PASS: progress preserved on cold reload')
