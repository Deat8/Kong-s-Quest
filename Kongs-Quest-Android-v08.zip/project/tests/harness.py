from pathlib import Path
import ctypes as c
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[2]
lib=c.CDLL(str(ROOT/'work/core/libretro/snes9x_libretro.so'))
ENV=c.CFUNCTYPE(c.c_bool,c.c_uint,c.c_void_p)
VIDEO=c.CFUNCTYPE(None,c.c_void_p,c.c_uint,c.c_uint,c.c_size_t)
AUDIO=c.CFUNCTYPE(c.c_size_t,c.c_void_p,c.c_size_t)
SAMPLE=c.CFUNCTYPE(None,c.c_int16,c.c_int16)
POLL=c.CFUNCTYPE(None)
INPUT=c.CFUNCTYPE(c.c_int16,c.c_uint,c.c_uint,c.c_uint,c.c_uint)
input_mask=0
capture=None
sample_rate=32040
@ENV
def env(cmd,data):
    if cmd in (10,18,35,36,37,44,52,60):return True
    if cmd==47:
        c.cast(data,c.POINTER(c.c_int)).contents.value=3
        return True
    if cmd in (9,31):
        c.cast(data,c.POINTER(c.c_char_p)).contents.value=str(ROOT).encode()
        return True
    return False
@VIDEO
def video(data,w,h,pitch):
    global capture
    if data and w==256:
        a=np.frombuffer(c.string_at(data,pitch*h),dtype=np.uint16).reshape(h,pitch//2)[:,:w]
        capture=Image.fromarray(np.stack(((a>>11)*255//31,((a>>5)&63)*255//63,(a&31)*255//31),axis=-1).astype('uint8'))
@AUDIO
def audio(data,frames):return frames
@SAMPLE
def sample(left,right):pass
@POLL
def poll():pass
@INPUT
def inputs(port,device,index,button):
    if port:return 0
    if button==256:return input_mask
    return int(bool(input_mask&(1<<button)))
class Game(c.Structure):
    _fields_=[('path',c.c_char_p),('data',c.c_void_p),('size',c.c_size_t),('meta',c.c_char_p)]
for name,fn in [('environment',env),('video_refresh',video),('audio_sample_batch',audio),('audio_sample',sample),('input_poll',poll),('input_state',inputs)]:
    getattr(lib,'retro_set_'+name)(fn)
lib.retro_get_memory_data.restype=c.c_void_p
lib.retro_get_memory_data.argtypes=[c.c_uint]
lib.retro_get_memory_size.restype=c.c_size_t
lib.retro_load_game.argtypes=[c.POINTER(Game)]
lib.retro_load_game.restype=c.c_bool
lib.retro_serialize_size.restype=c.c_size_t
lib.retro_serialize.argtypes=[c.c_void_p,c.c_size_t]
lib.retro_serialize.restype=c.c_bool
lib.retro_unserialize.argtypes=[c.c_void_p,c.c_size_t]
lib.retro_unserialize.restype=c.c_bool
lib.retro_init()
def load(path=None):
    global rom_buffer,game,ram,sram
    if path is None:path=ROOT/'recovered/Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc'
    raw=Path(path).read_bytes()
    rom_buffer=c.create_string_buffer(raw)
    game=Game(str(path).encode(),c.cast(rom_buffer,c.c_void_p),len(raw),None)
    assert lib.retro_load_game(c.byref(game))
    ram=(c.c_uint8*131072).from_address(lib.retro_get_memory_data(2))
    sram=(c.c_uint8*8192).from_address(lib.retro_get_memory_data(0))
def run(n,buttons=0):
    global input_mask
    input_mask=buttons
    for _ in range(n):lib.retro_run()
def press(button):run(2,button);run(6)
def word(a):return ram[a]|ram[a+1]<<8
def write(a,w):ram[a]=w&255;ram[a+1]=(w>>8)&255
def save():
    b=c.create_string_buffer(lib.retro_serialize_size())
    assert lib.retro_serialize(b,len(b))
    return b.raw
def restore(s):
    b=c.create_string_buffer(bytes(s))
    assert lib.retro_unserialize(b,len(s))
def page():
    s=save();p=s.index(b'FIL:032768:')+11
    return s[p+0x5ff0]
def boot(chapter,team):
    load()
    sram[0x1800:0x1807]=list(b'DKCJ')+[chapter-1,0,0]
    sram[0x1807]=0xa0|team[0]|team[1]<<2
    run(35);press(8);run(160)
    assert page()==chapter,(page(),chapter)
    for t in range(1200):
        run(1,8 if 30<=t%90<34 else 0)
        if (chapter==1 and word(0x1e15)&0x40) or (chapter==2 and word(0x20)==0x8608):break
    else:raise RuntimeError('stage did not open')
    run(300)
