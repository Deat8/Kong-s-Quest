import harness as h
from pathlib import Path
from PIL import Image,ImageDraw
rom=h.ROOT/'Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc'
state=(Path(__file__).parent/'fixtures/stage3-8.state').read_bytes()
sheet=Image.new('RGB',(256*4,224*3));draw=ImageDraw.Draw(sheet)
for kong in range(4):
 h.load(rom)
 h.sram[0x1800:0x1807]=list(b'DKCJ')+[2,0,0];h.sram[0x1807]=0xa0|kong|(((kong+1)%4)<<2)
 h.run(35);h.press(8);h.run(160);assert h.page()==3
 h.restore(state)
 for t in range(100):
  h.run(1,128|2)
  if h.word(0x186b):break
 else:raise AssertionError(('no barrel',kong,h.word(0x88a),h.word(0x88e)))
 print('third grab',kong,t,hex(h.word(0x186b)),hex(h.word(0x8b8)),flush=True)
 h.run(18,2)
 for row,(label,n,keys) in enumerate([('hold',8,2),('walk',14,2|128),('throw',45,0)]):
  h.run(n,keys)
  sheet.paste(h.capture,(kong*256,row*224));draw.text((kong*256+2,row*224+2),f'3 / {kong} / {label}',fill='white')
  print('third',kong,label,hex(h.word(0x186b)),hex(h.word(0x8b8)),flush=True)
 sheet.save('/tmp/carry-third.png')
 h.run(60)
 assert h.word(0x186b)==0, ('barrel did not release',kong,h.word(0x186b),h.word(0x8b8))
