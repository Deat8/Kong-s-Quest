import harness as h
import ctypes as c,subprocess
from pathlib import Path
symbols={p[2]:int(p[0],16) for line in subprocess.check_output(['nm','-an',str(h.ROOT/'work/core/libretro/snes9x_libretro.so')],text=True).splitlines() if len(p:=line.split())==3 and p[2] in ('CPU','retro_init')}
cpu=c.cast(h.lib.retro_init,c.c_void_p).value-symbols['retro_init']+symbols['CPU']

def compare(state,x,y,port):
    snapshot=bytearray(state)
    regs=snapshot.index(b'REG:000016:')+11
    memory=snapshot.index(b'RAM:131072:')+11
    # Execute the actual 65816 CPX absolute instruction through the emulator.
    code=bytes.fromhex('78 c2 30')+b'\xa2'+x.to_bytes(2,'little')+b'\xa0'+y.to_bytes(2,'little')+b'\xec'+port.to_bytes(2,'little')+bytes.fromhex('08 e2 20 68 8f 00 f0 7f 5c 14 fa 7f')
    snapshot[memory+0x1fa00:memory+0x1fa00+len(code)]=code
    snapshot[regs:regs+2]=b'\x7f\x00';snapshot[regs+14:regs+16]=b'\xfa\x00'
    h.restore(snapshot)
    for offset in (24,25,68):c.c_uint8.from_address(cpu+offset).value=0
    h.run(1)
    return bool(h.ram[0x1f000]&2)

for chapter in (1,3):
 for leader in range(4):
  partner=(leader+1)%4
  h.load(h.ROOT/'Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc')
  h.sram[0x1800:0x1807]=list(b'DKCJ')+[chapter-1,0,0]
  h.sram[0x1807]=0xa0|leader|(partner<<2)
  h.run(35);h.press(8);h.run(160)
  state=h.save()
  for slot,kong in enumerate((leader,partner)):
   heavy=kong in (0,3)
   if chapter==1:
    assert compare(state,2+slot*2,0,0x5ff2)==heavy,(chapter,slot,kong,'heavy')
    assert compare(state,2+slot*2,0,0x5ff4)!=heavy,(chapter,slot,kong,'light')
   else:
    assert compare(state,0x22c+slot*4,0x878+slot*0x6e,0x5ff6)==heavy,(chapter,slot,kong)
 print('Native weight comparisons follow the selected Kong in both slots, chapter',chapter,flush=True)
