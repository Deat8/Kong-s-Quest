"""Compare ROM-decoded carry poses to the original games' live PPU tiles."""
import sys,ctypes as c,subprocess,struct
from pathlib import Path
import numpy as np
import harness as h
sys.path.insert(0,str(h.ROOT/'project'))
from extract_native_carry import decode_native
from extract_native_map_sprites import tables,decode_tile
syms={p[2]:int(p[0],16) for line in subprocess.check_output(['nm','-an',str(h.ROOT/'work/core/libretro/snes9x_libretro.so')],text=True).splitlines() if len(p:=line.split())==3 and p[2] in ('PPU','retro_init')}
ppu=c.cast(h.lib.retro_init,c.c_void_p).value-syms['retro_init']+syms['PPU']
def crop(a):
 y,x=a.nonzero();return a[y.min():y.max()+1,x.min():x.max()+1]
for game,kong in ((1,0),(2,1),(3,2)):
 h.load(h.ROOT/'Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc')
 h.sram[0x1800:0x1807]=list(b'DKCJ')+[game-1,0,0];h.sram[0x1807]=0xa0|kong|((kong+1)<<2)
 h.run(35);h.press(8);h.run(160)
 fixture='held-native.state' if game==1 else f'stage{game}-'+('10.state' if game==2 else '8.state')
 h.restore((h.ROOT/'project/tests/fixtures'/fixture).read_bytes())
 if game!=1:
  for _ in range(100):
   h.run(1,130)
   if h.word(0xd7a if game==2 else 0x186b):break
 h.run(60,2)
 rom,assets,headers=tables(game);lookup={addr:name for name,(addr,_) in headers.items()}
 candidates=[]
 prefix=('DonkeyKong','Diddy','Dixie')[game-1]
 for candidate in headers:
  if candidate.startswith('GFX_'+prefix+'_') and any('_'+w in candidate for w in ('Hold','Pickup','Throw')):
   pixels=decode_native(rom,assets,headers,candidate,list(range(16)))
   candidates.append((candidate,crop(pixels)))
 matched=set()
 for sample in range(8):
  h.run(1,2|128)
  check_base=2 if game==1 else 0xde2 if game==2 else 0x878
  previous_pose=h.word(0xd11+check_base if game==1 else check_base+(0x1a if game==2 else 0x24))
  h.run(1,2|128)
  base=2 if game==1 else 0xde2 if game==2 else 0x878
  pose=previous_pose
  table=0x3bcc9c if game==1 else 0x3c8000
  address=int.from_bytes(rom[table+pose:table+pose+3],'little')&0x3fffff
  name=lookup[address]
  assert any(w in name for w in ('Hold','Pickup')),name
  expected=decode_native(rom,assets,headers,name,list(range(16)))
  attr=h.word(0xc69+base if game==1 else base+(0x12 if game==2 else 0x1e))
  mask=0x1c0 if game==1 else 0x1e0;palette=(attr>>9)&7;pool=attr&mask
  raw=c.string_at(ppu+582,1536);vram=c.string_at(h.lib.retro_get_memory_data(3),65536)
  namebase=c.c_uint16.from_address(ppu+2122).value;nameselect=c.c_uint16.from_address(ppu+2124).value
  actual=np.zeros((256,512),dtype=np.uint16)
  flip=False
  for i in range(128):
   x,y,hflip,vflip,tile,priority,pal,size=struct.unpack_from('<hHBBHBBB',raw,i*12)
   if pal!=palette or priority<2 or tile&mask!=pool or not -32<x<256 or y>=224:continue
   width=16 if size else 8;flip=bool(hflip)
   for py in range(width):
    for px in range(width):
     sx=width-1-px if hflip else px;sy=width-1-py if vflip else py
     tileindex=(tile&0x100)|(((tile&0xf0)+(sy//8)*16)&0xf0)|(((tile&15)+sx//8)&15)
     addr=(namebase+tileindex*32+(nameselect if tileindex&0x100 else 0)+(sy&7)*2)&65535
     bit=7-(sx&7)
     value=sum(((vram[(addr+off)&65535]>>bit)&1)<<plane for plane,off in enumerate((0,1,16,17)))
     if value and 0<=y+py<256 and 0<=x+px+64<512:actual[y+py,x+px+64]=value
  a=crop(actual)
  matches=[candidate for candidate,pixels in candidates if a.shape==pixels.shape and np.array_equal(a,pixels[:,::-1] if flip else pixels)]
  assert matches,(game,sample,name,a.shape,'no original pose matches native PPU')
  matched.update(matches)
  exact=crop(expected[:,::-1] if flip else expected)
  assert a.shape==exact.shape and np.array_equal(a,exact),(game,sample,'previous pose mismatch',name,matches)
 assert len(matched)>=3,(game,'too few distinct original poses',matched)
 print('Exact palette-index match to native PPU:',game,'8 carry poses',flush=True)
