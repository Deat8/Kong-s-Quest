import harness as h
from pathlib import Path
ROM=h.ROOT/'Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc'
for leader in range(4):
 for partner in range(4):
  if leader==partner:continue
  h.load(ROM)
  h.sram[0x1807]=0xa0|leader|(partner<<2)
  h.run(35)
  assert (h.ram[6],h.ram[7])==(leader,partner)
  for field in (0,1):
   h.press(16 if field==0 else 32)
   original=(h.ram[6],h.ram[7])
   for _ in range(3):
    h.press(128)
    assert h.ram[6]!=h.ram[7]
   assert (h.ram[6],h.ram[7])==original
  h.press(8);h.run(140)
  assert h.page()==1
print('12 distinct pairs selectable and both fields skip duplicate Kongs',flush=True)
for kong in range(4):
 h.load(ROM);h.sram[0x1807]=0xa0|kong|(kong<<2);h.run(35)
 assert (h.ram[6],h.ram[7])==(kong,(kong+1)%4)
print('Legacy duplicate pairs normalized',flush=True)
h.load(ROM);h.run(35);h.press(8);h.run(160)
for chapter,(address,mask) in enumerate(((0x5e1,1),(0x59be,2),(0x655,2)),1):
 assert h.page()==chapter
 h.run(15)
 h.write(address,h.word(address)|mask)
 h.run(1)
 assert h.sram[0x1804]==chapter,(chapter,h.sram[0x1804])
 if chapter<3:
  h.run(185)
  assert h.page()==chapter+1
  h.run(160)
 print('Campaign chapter',chapter,'registered and advanced',flush=True)
battery=bytes(h.sram)
h.load(ROM);h.sram[:]=battery;h.run(35);h.press(8);h.run(160)
assert h.page()==3 and h.sram[0x1804]==3
print('Battery progress resumes at chapter 3 after cold load',flush=True)
