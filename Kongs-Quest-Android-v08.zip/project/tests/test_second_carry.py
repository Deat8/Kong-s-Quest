import harness as h
import numpy as np
from pathlib import Path
from PIL import Image,ImageDraw
rom=h.ROOT/'Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc'
old=h.load
h.load=lambda path=None:old(rom if path is None else path)
state=(Path(__file__).parent/'fixtures/stage2-10.state').read_bytes()
sheet=Image.new('RGB',(256*4,224*3));d=ImageDraw.Draw(sheet)
for kong in range(4):
 h.boot(2,(kong,(kong+1)%4));h.restore(state);h.run(15,2)
 for row,(label,n,keys) in enumerate([('hold',8,2),('walk',14,2|128),('throw',36,0)]):
  h.run(n,keys)
  sheet.paste(h.capture,(kong*256,row*224));d.text((kong*256+2,row*224+2),f'2 / {kong} / {label}',fill='white')
  if kong==0 and label=='hold':
   pixels=np.asarray(h.capture.crop((42,82,85,112))).astype(float)
   brown=(pixels[:,:,0]>pixels[:,:,1]*1.15)&(pixels[:,:,2]<110)&(pixels[:,:,0]>45)
   assert brown.sum()>100, 'The overhead barrel was clipped by DKC2 sky raster effects'
  if label=='throw':assert h.word(0xd7a)==0, 'Held object did not release'
  print('second',kong,label,'object',hex(h.word(0xd7a)), 'animation',hex(h.word(0xde2+0x36)),flush=True)
 sheet.save('/tmp/carry-second.png')
