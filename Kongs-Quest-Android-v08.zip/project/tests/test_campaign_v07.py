"""Kong's Quest v0.7: victory debounce, auto-advance, save persistence.

Tests run the actual modified libretro Snes9x core. Victory flags are injected
into WRAM: this is NOT proof that each original final boss raises them.
"""
from pathlib import Path
import harness as h

ROM = Path('/mnt/data/Donkey-Kong-Country-Kongs-Quest-Campanha-Unica-Emulador-Proprio.sfc')
assert ROM.is_file()

# Keep original 12-team selection regression: runs through the real menu.
for first in range(4):
    for second in range(4):
        if first == second:
            continue
        h.load(ROM)
        h.sram[0x1807] = 0xa0 | first | (second << 2)
        h.run(35)
        assert (h.ram[6], h.ram[7]) == (first, second)
        h.press(8)
        h.run(160)
        assert h.page() == 1
print('PASS: 12 unique teams and native loader')

# A one-frame false completion flag must not unlock a chapter.
for first in range(1, 4):
    h.load(ROM)
    if first > 1:
        h.sram[:0x1800] = b'\x60' * 0x1800
        h.sram[0x1800:0x1808] = list(b'DKCJ') + [first - 1, 0, 0, 0xa4]
    h.run(35)
    h.press(8)
    h.run(160)
    assert h.page() == first, (first, h.page())
    h.run(12)
    addr, mask = ((0x5e1, 1), (0x59be, 2), (0x655, 2))[first - 1]
    h.write(addr, h.word(addr) & ~mask)
    h.run(3)
    h.write(addr, h.word(addr) | mask)
    h.run(4)
    assert h.sram[0x1804] == first - 1, ('false win marked', first)
    h.write(addr, h.word(addr) & ~mask)
    h.run(3)
    assert h.sram[0x1804] == first - 1, ('flicker marked', first)
    h.write(addr, h.word(addr) | mask)
    h.run(8)
    assert h.sram[0x1804] == first, ('stable win not marked', first, h.sram[0x1804])
    print(f'PASS: chapter {first} flicker suppressed, stable victory recorded')
    if first < 3:
        assert h.page() == first, ('premature advance', first)
        h.run(190)
        assert h.page() == first + 1, ('no auto advance', first, h.page())
        print(f'PASS: automatic chapter {first} -> {first + 1}')
    else:
        h.run(200)
        assert h.page() == 3
        print('PASS: final chapter does not advance beyond 3')

# Resume from the saved final chapter in a cold load.
battery = bytes(h.sram)
h.load(ROM)
h.sram[:] = battery
h.run(35)
h.press(8)
h.run(160)
assert h.page() == 3 and h.sram[0x1804] == 3
print('PASS: cold-load battery resumes at final chapter')
