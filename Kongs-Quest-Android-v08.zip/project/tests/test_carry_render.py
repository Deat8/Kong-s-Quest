import harness as h
from pathlib import Path
from PIL import Image,ImageDraw
import struct,subprocess,ctypes as c
rom=h.ROOT/'Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc'
old_load=h.load
h.load=lambda path=None:old_load(rom if path is None else path)
state=(Path(__file__).parent/'fixtures/held-native.state').read_bytes()
syms={t[2]:int(t[0],16) for line in subprocess.check_output(['nm','-an',str(h.ROOT/'work/core/libretro/snes9x_libretro.so')],text=True).splitlines() if len(t:=line.split())==3 and t[2] in ('Journey','retro_init')}
runtime=c.cast(h.lib.retro_init,c.c_void_p).value-syms['retro_init']+syms['Journey']
sheet=Image.new('RGB',(256*4,224*4));draw=ImageDraw.Draw(sheet)
for kong in range(4):
 h.boot(1,(kong,(kong+1)%4))
 h.restore(state)
 h.run(4,2)
 for row,(label,frames,keys) in enumerate([('hold',12,2),('walk',16,2|128),('turn',14,2|64),('throw',12,0)]):
  h.run(frames,keys)
  raw=c.string_at(runtime+8248,28)
  motion,frame=raw[4:6]
  print(kong,label,motion,frame,'native',hex(h.word(0x10d3)),'held',h.word(0x16f5),flush=True)
  sheet.paste(h.capture,(kong*256,row*224))
  draw.text((kong*256+3,row*224+3),f'{kong} {label} {motion}/{frame}',fill='white')
  if kong!=0 and label!='throw':assert motion in (6,7,8,10)
  if kong!=0 and label=='throw':assert motion in (9,0,1)
 sheet.save('/tmp/carry-gameplay.png')
 h.run(40)
 assert h.word(0x16f5)==0, 'Held object did not release'
print('Four Kongs rendered with original barrel graphics',flush=True)
