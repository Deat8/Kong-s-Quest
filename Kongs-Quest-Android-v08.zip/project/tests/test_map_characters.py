"""Smoke test: native map art must change locally with each selected leader."""
import harness as h
import numpy as np
from PIL import Image

regions = {1:(45,150,125,217), 2:(0,75,55,140), 3:(65,90,130,155)}
preview = Image.new('RGB', (256*4,224*3))
for chapter in (1,2,3):
    captures=[]
    for leader in range(4):
        h.load(h.ROOT/'Donkey-Kong-Country-A-Grande-Jornada-Dupla-Livre.sfc')
        h.sram[0x1800:0x1807]=list(b'DKCJ')+[chapter-1,0,0]
        h.sram[0x1807]=0xa0|leader|(((leader+1)%4)<<2)
        h.run(35);h.press(8);h.run(160)
        captures.append(h.capture.copy())
        preview.paste(h.capture,(leader*256,(chapter-1)*224))
    region=regions[chapter]
    assert len({im.crop(region).tobytes() for im in captures})==4,chapter
    # Selection must leave all pixels outside the player icons unchanged.
    arrays=[np.asarray(im) for im in captures]
    left,top,right,bottom=region
    for other in arrays[1:]:
        diff=np.any(arrays[0]!=other,axis=2)
        diff[top:bottom,left:right]=False
        assert not diff.any(),(chapter,'unexpected changes outside map icon')
    print('Four distinct native map miniatures, chapter',chapter,flush=True)
preview.save('/tmp/map-four-characters.png')
