#!/usr/bin/env bash
set -euo pipefail
project=$(cd "$(dirname "$0")/.." && pwd)
root=$(cd "$project/.." && pwd)
tools="$root/work/android/android-15"
sdk="$root/work/android/android-35/android.jar"
ndk="$root/work/android/android-ndk-r27d/toolchains/llvm/prebuilt/linux-x86_64/bin"
app="$project/android"
out="$app/out"
mkdir -p "$out/classes" "$out/staging/lib/arm64-v8a" "$out/staging/assets"
cp "$root/work/core-android/libretro/snes9x_libretro.so" "$out/staging/lib/arm64-v8a/libsnes9x_jornada.so"
"$ndk/aarch64-linux-android23-clang++" -std=c++17 -O2 -shared -fPIC -static-libstdc++ \
    -Wl,-z,max-page-size=16384 -Wl,-soname,libjornada_player.so \
    -I"$root/work/core/libretro" -L"$out/staging/lib/arm64-v8a" \
    "$app/bridge.cpp" -l:libsnes9x_jornada.so -ljnigraphics -o "$out/staging/lib/arm64-v8a/libjornada_player.so"
"$ndk/llvm-strip" --strip-unneeded "$out/staging/lib/arm64-v8a/"*.so
java -jar "$root/work/tools/ecj.jar" -8 -encoding UTF-8 -nowarn -proc:none \
    -bootclasspath "$sdk:$tools/core-lambda-stubs.jar" -d "$out/classes" "$app/MainActivity.java"
"$tools/d8" --min-api 23 --lib "$sdk" --output "$out/staging" "$out/classes/org/jornadakong/player/rebuilt/"*.class
cp "$root/work/core/LICENSE" "$out/staging/assets/Snes9x-LICENSE.txt"
"$tools/aapt2" link -I "$sdk" --manifest "$app/AndroidManifest.xml" -o "$out/unsigned.apk"
(cd "$out/staging" && zip -q "$out/unsigned.apk" classes.dex lib/arm64-v8a/*.so assets/Snes9x-LICENSE.txt)
"$tools/zipalign" -f -P 16 4 "$out/unsigned.apk" "$out/aligned.apk"
if [ ! -f "$app/jornada-signing.p12" ]; then
    keytool -genkeypair -alias jornada -keyalg RSA -keysize 2048 -validity 10000 \
        -storetype PKCS12 -keystore "$app/jornada-signing.p12" -storepass jornada-local-rebuild \
        -dname "CN=Jornada Kong Rebuilt, O=Jornada Kong" >/dev/null 2>&1
fi
result="$root/Donkey-Kong-Country-Kongs-Quest-Android-v08-Experimental.apk"
"$tools/apksigner" sign --ks "$app/jornada-signing.p12" --ks-pass pass:jornada-local-rebuild \
    --out "$result" "$out/aligned.apk"
"$tools/apksigner" verify --verbose "$result"
"$tools/aapt2" dump badging "$result" | head -12
