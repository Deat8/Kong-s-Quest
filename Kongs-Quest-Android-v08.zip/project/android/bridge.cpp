#include <jni.h>
#include <android/bitmap.h>
#include <algorithm>
#include <cstring>
#include <vector>
#include "libretro.h"

namespace {
std::vector<uint8_t> cartridge;
std::vector<int16_t> sound;
uint16_t frame[512 * 478];
unsigned width = 0, height = 0, buttons = 0;
bool initialized = false, loaded = false;

bool environment(unsigned command, void* data)
{
    switch (command) {
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
            return *static_cast<retro_pixel_format*>(data) == RETRO_PIXEL_FORMAT_RGB565;
        case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
        case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
        case RETRO_ENVIRONMENT_SET_VARIABLES:
        case RETRO_ENVIRONMENT_SET_GEOMETRY:
        case RETRO_ENVIRONMENT_SET_SUPPORT_ACHIEVEMENTS:
        case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
            return true;
        case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE:
            *static_cast<int*>(data) = 3;
            return true;
        case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS:
            return true;
        case RETRO_ENVIRONMENT_GET_CAN_DUPE:
            *static_cast<bool*>(data) = true;
            return true;
        case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
        case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
            *static_cast<const char**>(data) = ".";
            return true;
        default:
            return false;
    }
}

void video(const void* data, unsigned newWidth, unsigned newHeight, size_t pitch)
{
    if (!data || newWidth > 512 || newHeight > 478)
        return;
    width = newWidth;
    height = newHeight;
    for (unsigned y = 0; y < height; ++y)
        std::memcpy(frame + y * 512, static_cast<const uint8_t*>(data) + y * pitch, width * 2);
}

size_t audio(const int16_t* data, size_t count)
{
    const size_t available = (8192 - sound.size()) / 2;
    const size_t accepted = std::min(count, available);
    sound.insert(sound.end(), data, data + accepted * 2);
    return count;
}
void sample(int16_t left, int16_t right)
{
    const int16_t values[] = {left, right};
    audio(values, 1);
}
void poll() { }
int16_t input(unsigned port, unsigned device, unsigned index, unsigned id)
{
    if (port || device != RETRO_DEVICE_JOYPAD)
        return 0;
    return id == RETRO_DEVICE_ID_JOYPAD_MASK ? buttons : (buttons >> id) & 1;
}
void close()
{
    if (loaded) retro_unload_game();
    if (initialized) retro_deinit();
    loaded = initialized = false;
    cartridge.clear();
    sound.clear();
    width = height = 0;
}
}

extern "C" JNIEXPORT jint JNICALL
Java_org_jornadakong_player_rebuilt_MainActivity_nativeOpen(JNIEnv* env, jclass, jbyteArray rom, jbyteArray save)
{
    close();
    const jsize size = env->GetArrayLength(rom);
    if (size < 0x1330000 || size > 0x1420100)
        return 0;
    cartridge.resize(size);
    env->GetByteArrayRegion(rom, 0, size, reinterpret_cast<jbyte*>(cartridge.data()));
    if (std::memcmp(cartridge.data() + 0x7f00, "DKCJOURNEY-MMC5", 14))
        return 0;
    retro_set_environment(environment);
    retro_set_video_refresh(video);
    retro_set_audio_sample_batch(audio);
    retro_set_audio_sample(sample);
    retro_set_input_poll(poll);
    retro_set_input_state(input);
    retro_init();
    initialized = true;
    retro_game_info game = {"Jornada.sfc", cartridge.data(), cartridge.size(), nullptr};
    loaded = retro_load_game(&game);
    if (!loaded) { close(); return 0; }
    if (save && env->GetArrayLength(save) == 8192)
        env->GetByteArrayRegion(save, 0, 8192, static_cast<jbyte*>(retro_get_memory_data(RETRO_MEMORY_SAVE_RAM)));
    retro_system_av_info info;
    retro_get_system_av_info(&info);
    return static_cast<int>(info.timing.sample_rate);
}

extern "C" JNIEXPORT jint JNICALL
Java_org_jornadakong_player_rebuilt_MainActivity_nativeStep(JNIEnv* env, jclass, jobject bitmap,
                                                         jint mask, jshortArray samples, jintArray info)
{
    if (!loaded) return 0;
    buttons = mask;
    sound.clear();
    retro_run();
    AndroidBitmapInfo image;
    void* pixels = nullptr;
    if (width && AndroidBitmap_getInfo(env, bitmap, &image) == ANDROID_BITMAP_RESULT_SUCCESS &&
        AndroidBitmap_lockPixels(env, bitmap, &pixels) == ANDROID_BITMAP_RESULT_SUCCESS) {
        for (unsigned y = 0; y < std::min(height, image.height); ++y)
            std::memcpy(static_cast<uint8_t*>(pixels) + y * image.stride, frame + y * 512,
                        std::min(width, image.width) * 2);
        AndroidBitmap_unlockPixels(env, bitmap);
    }
    const unsigned count = std::min<size_t>(sound.size(), env->GetArrayLength(samples));
    if (count) env->SetShortArrayRegion(samples, 0, count, sound.data());
    const auto* battery = static_cast<uint8_t*>(retro_get_memory_data(RETRO_MEMORY_SAVE_RAM));
    const bool advance = !std::memcmp(battery + 0x1800, "DKCJ", 4) &&
        battery[0x1805] >= 1 && battery[0x1805] < 3 && battery[0x1804] == battery[0x1805];
    const jint values[] = {static_cast<jint>(count), advance};
    env->SetIntArrayRegion(info, 0, 2, values);
    return width ? (width << 16) | height : 0;
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_org_jornadakong_player_rebuilt_MainActivity_nativeSave(JNIEnv* env, jclass)
{
    if (!loaded) return nullptr;
    jbyteArray result = env->NewByteArray(8192);
    env->SetByteArrayRegion(result, 0, 8192, static_cast<const jbyte*>(retro_get_memory_data(RETRO_MEMORY_SAVE_RAM)));
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_org_jornadakong_player_rebuilt_MainActivity_nativeClose(JNIEnv*, jclass) { close(); }
