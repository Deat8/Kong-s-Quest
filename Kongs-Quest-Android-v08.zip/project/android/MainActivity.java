package org.jornadakong.player.rebuilt;

import android.app.Activity;
import android.content.Intent;
import android.graphics.*;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.net.Uri;
import android.os.Bundle;
import android.util.AtomicFile;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.concurrent.locks.LockSupport;

public final class MainActivity extends Activity {
    static { System.loadLibrary("jornada_player"); }
    private static final int FILE_PICK = 7;
    private static final int UP = 16, DOWN = 32, LEFT = 64, RIGHT = 128;
    private static final int B = 1, Y = 2, SELECT = 4, START = 8;
    private static final int A = 256, X = 512, L = 1024, R = 2048, MENU = L | R | START;
    private static native int nativeOpen(byte[] rom, byte[] save);
    private static native int nativeStep(Bitmap bitmap, int keys, short[] audio, int[] count);
    private static native byte[] nativeSave();
    private static native void nativeClose();
    private final Object frameLock = new Object();
    private final Bitmap bitmap = Bitmap.createBitmap(512, 478, Bitmap.Config.RGB_565);
    private AtomicFile saveFile;
    private volatile boolean running, foreground, canAdvance;
    private volatile int touch, keys, video;
    private Thread player;
    private volatile Screen screen;
    private TextView status;
    private Uri pending;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        saveFile = new AtomicFile(new File(getFilesDir(), "jornada.srm"));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        home("");
    }

    private void home(String message) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 24, 32, 24);
        layout.setBackgroundColor(0xff142118);
        TextView title = new TextView(this);
        title.setText("DONKEY KONG COUNTRY\nKong's Quest · 0.8 experimental");
        title.setTextSize(25);
        title.setTextColor(0xffffd26d);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);
        status = new TextView(this);
        status.setText(message.isEmpty() ? "Abra Kong's Quest — campanha única (.sfc)." : message);
        status.setTextColor(0xfff1eed8);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 24, 0, 24);
        layout.addView(status);
        Button open = new Button(this);
        open.setText("Abrir ROM .sfc");
        open.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            startActivityForResult(intent, FILE_PICK);
        });
        layout.addView(open);
        String previous = getPreferences(0).getString("romUri", null);
        if (previous != null) {
            Button again = new Button(this);
            again.setText("Reabrir última ROM");
            again.setOnClickListener(view -> launch(Uri.parse(previous)));
            layout.addView(again);
        }
        setContentView(layout);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == FILE_PICK && result == RESULT_OK && data != null && data.getData() != null) {
            pending = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(pending, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException ignored) { }
        }
    }

    @Override protected void onResume() {
        super.onResume();
        foreground = true;
        if (pending != null) {
            Uri selected = pending;
            pending = null;
            launch(selected);
        }
    }

    @Override protected void onPause() {
        foreground = false;
        touch = keys = 0;
        super.onPause();
    }

    @Override protected void onDestroy() {
        running = false;
        super.onDestroy();
    }

    private byte[] readRom(Uri uri) throws IOException {
        try (InputStream stream = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            if (stream == null) throw new IOException("Arquivo indisponível");
            byte[] buffer = new byte[32768];
            for (int count; (count = stream.read(buffer)) != -1;) {
                output.write(buffer, 0, count);
                if (output.size() > 0x1420100) throw new IOException("Cartucho inválido");
            }
            return output.toByteArray();
        }
    }

    private void launch(Uri uri) {
        if (player != null) return;
        status.setText("Carregando cartucho…");
        running = true;
        player = new Thread(() -> play(uri), "SNES Jornada");
        player.start();
    }

    private void writeSave() throws IOException {
        byte[] bytes = nativeSave();
        if (bytes == null) return;
        FileOutputStream output = saveFile.startWrite();
        try {
            output.write(bytes);
            saveFile.finishWrite(output);
        } catch (IOException error) {
            saveFile.failWrite(output);
            throw error;
        }
    }

    private void play(Uri uri) {
        AudioTrack track = null;
        String error = null;
        try {
            byte[] save = null;
            try { save = saveFile.readFully(); } catch (FileNotFoundException ignored) { }
            int sampleRate = nativeOpen(readRom(uri), save);
            if (sampleRate <= 0) throw new IOException("Use a ROM Dupla Livre desta versão.");
            getPreferences(0).edit().putString("romUri", uri.toString()).apply();
            int minimum = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(minimum, 16384), AudioTrack.MODE_STREAM);
            track.play();
            runOnUiThread(() -> {
                if (running) {
                    screen = new Screen();
                    setContentView(screen);
                    getWindow().getDecorView().setSystemUiVisibility(5894);
                }
            });
            short[] audio = new short[8192];
            int[] count = new int[2];
            long nextFrame = System.nanoTime();
            int frames = 0;
            boolean savedWhilePaused = false;
            while (running) {
                if (!foreground) {
                    if (!savedWhilePaused) {
                        writeSave();
                        savedWhilePaused = true;
                    }
                    nextFrame = System.nanoTime();
                    LockSupport.parkNanos(20000000);
                    continue;
                }
                savedWhilePaused = false;
                synchronized (frameLock) {
                    int size = nativeStep(bitmap, touch | keys, audio, count);
                    if (size != 0) video = size;
                    canAdvance = count[1] != 0;
                }
                if (count[0] > 0) track.write(audio, 0, Math.min(count[0], audio.length));
                Screen current = screen;
                if (current != null) current.postInvalidate();
                if (++frames % 120 == 0) writeSave();
                nextFrame += 16639000L;
                long delay = nextFrame - System.nanoTime();
                if (delay > 0) LockSupport.parkNanos(delay);
                else if (delay < -100000000L) nextFrame = System.nanoTime();
            }
            writeSave();
        } catch (Exception failure) {
            error = "Não foi possível abrir ou salvar o jogo. " + failure.getMessage();
        } finally {
            running = false;
            if (track != null) { track.stop(); track.release(); }
            nativeClose();
            final String message = error;
            runOnUiThread(() -> {
                player = null;
                screen = null;
                if (message != null) home(message);
            });
        }
    }

    private int buttonFor(int key) {
        switch (key) {
            case KeyEvent.KEYCODE_DPAD_UP: return UP;
            case KeyEvent.KEYCODE_DPAD_DOWN: return DOWN;
            case KeyEvent.KEYCODE_DPAD_LEFT: return LEFT;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return RIGHT;
            case KeyEvent.KEYCODE_BUTTON_A: case KeyEvent.KEYCODE_X: return B;
            case KeyEvent.KEYCODE_BUTTON_B: case KeyEvent.KEYCODE_Z: return A;
            case KeyEvent.KEYCODE_BUTTON_X: case KeyEvent.KEYCODE_A: return X;
            case KeyEvent.KEYCODE_BUTTON_Y: case KeyEvent.KEYCODE_S: return Y;
            case KeyEvent.KEYCODE_BUTTON_L1: case KeyEvent.KEYCODE_Q: return L;
            case KeyEvent.KEYCODE_BUTTON_R1: case KeyEvent.KEYCODE_E: return R;
            case KeyEvent.KEYCODE_BUTTON_START: case KeyEvent.KEYCODE_ENTER: return START;
            case KeyEvent.KEYCODE_BUTTON_SELECT: case KeyEvent.KEYCODE_V: return SELECT;
            default: return 0;
        }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        int button = buttonFor(event.getKeyCode());
        if (screen != null && button != 0) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) keys |= button;
            if (event.getAction() == KeyEvent.ACTION_UP) keys &= ~button;
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private final class Screen extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect source = new Rect();
        private final RectF output = new RectF(), dpad = new RectF();
        private final RectF[] buttons = new RectF[9];
        private final String[] labels = {"Y","X","B","A","L","R","SELECT","START","SEGURE"};
        private final int[] values = {MainActivity.Y,MainActivity.X,B,A,L,R,SELECT,START,MENU};
        Screen() {
            super(MainActivity.this);
            for (int i = 0; i < buttons.length; ++i) buttons[i] = new RectF();
            setFocusable(true);
            setKeepScreenOn(true);
        }
        private void bounds(int index, float x, float y, float radius) {
            buttons[index].set(x-radius, y-radius, x+radius, y+radius);
        }
        @Override protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
            boolean landscape = width > height;
            float unit = Math.min(width / 7.1f, height / (landscape ? 4.5f : 11f));
            float radius = unit * .44f;
            float base = height - unit * 1.35f;
            dpad.set(unit*.25f,base-unit,unit*2.55f,base+unit);
            bounds(0,width-unit*2.45f,base,radius);
            bounds(1,width-unit*1.45f,base-unit*.8f,radius);
            bounds(2,width-unit*1.45f,base+unit*.8f,radius);
            bounds(3,width-unit*.45f,base,radius);
            bounds(4,unit*.7f,height-unit*3.0f,radius*.7f);
            bounds(5,width-unit*.7f,height-unit*3.0f,radius*.7f);
            bounds(6,width*.41f,height-unit*.55f,radius*.7f);
            bounds(7,width*.59f,height-unit*.55f,radius*.7f);
            bounds(8,width*.5f,height-unit*1.7f,radius*.85f);
            float availableHeight = landscape ? height-unit*1.05f : height-unit*4.2f;
            float scale = Math.min(width/256f,availableHeight/224f);
            float gameWidth = 256*scale, gameHeight = 224*scale;
            output.set((width-gameWidth)/2,0,(width+gameWidth)/2,gameHeight);
        }
        @Override protected void onDraw(Canvas canvas) {
            canvas.drawColor(0xff10271e);
            synchronized (frameLock) {
                if (video != 0) {
                    source.set(0,0,video>>>16,video&65535);
                    paint.setFilterBitmap(false);
                    canvas.drawBitmap(bitmap,source,output,paint);
                }
            }
            paint.setColor(0xbb315549);
            float arm = dpad.width()*.16f;
            canvas.drawRoundRect(dpad.centerX()-arm,dpad.top,dpad.centerX()+arm,dpad.bottom,8,8,paint);
            canvas.drawRoundRect(dpad.left,dpad.centerY()-arm,dpad.right,dpad.centerY()+arm,8,8,paint);
            paint.setColor(0xffeef4df);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(arm);
            canvas.drawText("▲",dpad.centerX(),dpad.top+arm,paint);
            canvas.drawText("▼",dpad.centerX(),dpad.bottom,paint);
            canvas.drawText("◀",dpad.left+arm,dpad.centerY()+arm*.4f,paint);
            canvas.drawText("▶",dpad.right-arm,dpad.centerY()+arm*.4f,paint);
            for (int i=0;i<buttons.length;++i) {
                if (i==8 && !canAdvance) continue;
                RectF button=buttons[i];
                paint.setColor((touch&values[i])==values[i]?0xff8dc4a6:0xbb456a54);
                canvas.drawRoundRect(button,button.height()*.45f,button.height()*.45f,paint);
                paint.setColor(0xfff3eed8);
                paint.setTextSize(button.height()*(i<6?.55f:.30f));
                canvas.drawText(labels[i],button.centerX(),button.centerY()-(paint.ascent()+paint.descent())/2,paint);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent event) {
            int mask=0;
            int action=event.getActionMasked();
            if (action!=MotionEvent.ACTION_UP && action!=MotionEvent.ACTION_CANCEL) {
                for (int pointer=0;pointer<event.getPointerCount();++pointer) {
                    if (action==MotionEvent.ACTION_POINTER_UP && pointer==event.getActionIndex()) continue;
                    float x=event.getX(pointer), y=event.getY(pointer);
                    if (dpad.contains(x,y)) {
                        float dx=(x-dpad.centerX())/(dpad.width()/2), dy=(y-dpad.centerY())/(dpad.height()/2);
                        if (dx<-.25f) mask|=LEFT;
                        if (dx>.25f) mask|=RIGHT;
                        if (dy<-.25f) mask|=UP;
                        if (dy>.25f) mask|=DOWN;
                    }
                    for (int i=0;i<buttons.length;++i)
                        if ((i!=8||canAdvance)&&buttons[i].contains(x,y)) mask|=values[i];
                }
            }
            touch=mask;
            return true;
        }
    }
}
