# Donkey Kong Country: Kong's Quest — integraçao v0.8

## O que de fato foi alterado

- Núcleo Snes9x personalizado: transição de emergência (L+R+Start) agora exige 60 quadros consecutivos segurando os botões **após vencer o capítulo**. Soltar qualquer botão zera o contador. Isso impede avanço acidental durante a cena de encerramento.
- Passagem normal automática permanece igual à v0.7: sinal de vitória estabilizado por 8 quadros, temporização de encerramento e estado de mapa/título estabilizado.
- Persistência da bateria da campanha, seleção das 12 duplas e carregamento de capítulos conservados.
- Código de interface Android atualizado para exibir **Kong's Quest** e botão **SEGURE**. O código do APK foi preparado, mas o APK v0.8 **não foi compilado** neste ambiente, pois faltam Android NDK, Android SDK e ferramentas Android.

## Testes executados

No Linux com o núcleo v0.8: `project/tests/test_campaign_v07.py`, `project/tests/test_campaign_v08.py`, `project/tests/test_character_roles.py` e `project/tests/test_map_characters.py` finalizaram sem erro. Os sinais de vitória foram **injetados na memória** durante os testes, portanto NÃO demonstram que derrotar o último chefe de cada jogo acionará a passagem corretamente numa partida completa.

## Arquivos

- `Kongs-Quest-Nucleo-Snes9x-Linux-v08.so` (fornecido separadamente), não serve para instalar no Android.
- `Donkey-Kong-Country-Kongs-Quest-Campanha-Unica-Emulador-Proprio.sfc` (mantido da v0.6). O container contém os três jogos, mas exige nosso núcleo modificado.
- Este pacote ZIP inclui os fontes do núcleo, testes e fontes Android. Não inclui ROMs originais nem chave de assinatura.

## Compilar para Android em uma máquina com internet

1. Instalar Python 3, Java 17 e ferramentas de compilação para Linux.
2. Executar `python3 project/fetch_dependencies.py` a partir da raiz da extração para baixar Android SDK 35, NDK r27d e ECJ.
3. Executar `bash project/build_android.sh` para recompilar o núcleo Snes9x ARM64 e gerar `Donkey-Kong-Country-Kongs-Quest-Android-v08-Experimental.apk`.
4. Validar com `apksigner verify`, instalar e testar num aparelho Android. Sem a antiga chave de assinatura, a nova APK não atualizará diretamente uma instalação 4.5; faça backup da bateria e reinstale, se necessário.

O fluxo não foi executado neste ambiente, por ausência do Android SDK/NDK e sem acesso à internet. Um APK v0.8 não foi gerado. Não substitua pela versão 4.5 e não declare que ela inclui a lógica nova.

## Checksum

Linux core: SHA-256 e219a690617bb1384ff6c73d5c92c8cf126745ee33f8a98d3ae4a759677e00e5
Campaign v0.6: SHA-256 67c419caedd3c18404dd3fa945799203bb0368c8c9e27a44cd24074be189dd0b
