# Donkey Kong Country: Kong's Quest — Android v0.8

**Situacao:** a v0.8 do nucleo foi compilada/testada em Linux, mas nao foi compilada em Android neste ambiente. Este pacote e **fonte de compilacao**, nao APK pronto.

## Compilar automaticamente (GitHub Actions)

1. Crie um repositorio GitHub **privado** (ou use um proprio, sem ROMs comerciais).
2. Coloque na raiz desse repositorio o conteudo **extraido** deste ZIP, incluindo as pastas ocultas `.github`, `project` e `work`.
3. Ao enviar os arquivos para a branch `main` ou `master`, o GitHub Actions inicia a compilação automaticamente. Também pode executar manualmente pela aba **Actions** usando **Run workflow**.
4. Se a compilacao terminar com sucesso, abra a execucao, baixe o artifact `Kongs-Quest-Android-v08-Experimental` e extraia o APK.
5. Instale o APK e abra o arquivo `Donkey-Kong-Country-Kongs-Quest-Campanha-Unica-Emulador-Proprio.sfc` fornecido separadamente em nossa conversa.

A compilacao depende de o runner ter acesso aos downloads oficiais do Android SDK 35, NDK r27d, Build Tools e ECJ, e pode exigir correcoes adicionais. Nao foi executada aqui.

## Assinatura / atualizacao

O script atual **gera uma nova chave de assinatura** na primeira compilacao e a guarda localmente. No GitHub Actions, o runner e temporario: **uma compilacao futura gerara outra chave**, e nao atualizara o APK ja instalado. Nao desinstale a versao antiga sem realizar backup dos dados de salvamento. Para atualizacoes estaveis, e preciso fornecer uma chave persistente por segredo do repositorio e adaptar a etapa de assinatura. Nao publique a chave privada de assinatura no repositorio.

## Validacao indispensavel

- Instalar no aparelho ARM64 e verificar abertura, controles, audio, retorno ao aplicativo e autosave.
- Confirmar que o arquivo de campanha abre sem erro.
- Confirmar as transicoes DKC1 → DKC2 → DKC3 **jogando os ultimos chefes**, pois os testes anteriores injetavam sinal de vitoria na memoria.
- Verificar animacoes, fisica e graficos dos personagens ao longo das fases.

## Estrutura

`project/build_android.sh` compila o nucleo C/C++ Snes9x para ARM64 e chama `project/android/build.sh`, que compila o aplicativo Java, cria o APK e valida a assinatura. `.github/workflows/build-android.yml` executa esses scripts automaticamente.

Nao inclua as ROMs comerciais no repositorio. O arquivo especial de campanha continua separado do aplicativo.
