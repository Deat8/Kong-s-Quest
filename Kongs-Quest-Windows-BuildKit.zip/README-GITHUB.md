# Kong's Quest — versão experimental Windows x64

Este ZIP é um **kit de compilação**, não o jogo completo. Contém um executável
Windows que precisa da DLL `snes9x_libretro.dll` personalizada.

## Compilação na sua conta GitHub

O repositório `Deat8/Kong-s-Quest` já contém `Kongs-Quest-Android-v08.zip` com
fontes do núcleo Snes9x adaptado (a versão não é Android-only; o núcleo pode ser
compilado para Windows).

1. Faça upload de **`Kongs-Quest-Windows-BuildKit.zip`** na raiz desse repositório.
2. Crie o arquivo **`.github/workflows/build-windows.yml`** no repositório,
   copiando o conteúdo de `build-windows.yml` incluído no BuildKit.
3. O GitHub Actions iniciará a compilação. Também é possível clicar em Actions
   > **Kong's Quest - Windows 64 bits** > **Run workflow**.
4. Após a execução com sucesso, baixe o artefato **Kongs-Quest-Windows-x64-Experimental**.
   Ele contém `KongQuest-Windows.exe` + `snes9x_libretro.dll` + licenças.
5. Copie para a mesma pasta seu arquivo de campanha `.sfc` fornecido nesta
   conversa. **Não envie ROMs ao repositório público.**

O workflow realiza uma verificação da DLL no Windows, mas **não é equivalente a
um teste de jogabilidade**. Bugs de renderização, física e transição devem ser
reportados após uma partida real.
