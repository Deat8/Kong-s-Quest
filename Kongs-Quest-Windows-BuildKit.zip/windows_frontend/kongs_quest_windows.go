//go:build windows
// Kong's Quest — host nativo do núcleo libretro modificado (Windows x64).
// Não contém nem distribui jogos comerciais. A ROM é selecionada pelo usuário.
package main

import (
 "fmt"
 "os"
 "path/filepath"
 "runtime"
 "strings"
 "syscall"
 "time"
 "unsafe"
)

const (
 csVredraw = 0x0001; csHredraw = 0x0002
 wsOverlappedWindow = 0x00CF0000; wsVisible = 0x10000000
 cwUseDefault = 0x80000000
 wmDestroy = 0x0002; wmPaint = 0x000F; wmClose = 0x0010; wmCommand = 0x0111
 wmKeyDown=0x0100; wmDropFiles=0x0233
 pmRemove = 1; swShow = 5
 biRGB=0; dibRGBColors=0; colorOnColor=3
 mfString=0x0000; mbOK=0; mbIconError=0x10; mbIconInformation=0x40
 fileMustExist=0x00001000; pathMustExist=0x00000800; ofnExplorer=0x00080000
 memCommit=0x1000; memReserve=0x2000; memRelease=0x8000; pageReadWrite=0x04
 retroSaveRam=0; retroDeviceJoypad=1; retroJoypadMask=256
 waveMapper=0xFFFFFFFF; waveFormatPCM=1; waveHdrDone=0x00000001
 waveBlockBytes=8192; waveBuffers=14
 commandOpen=1001; commandSave=1002; commandPause=1003; commandReset=1004; commandControls=1005; commandQuit=1006
 vkUp=0x26; vkDown=0x28; vkLeft=0x25; vkRight=0x27; vkReturn=0x0D; vkShift=0x10
 vkEscape=0x1B; vkF2=0x71; vkF5=0x74; vkF11=0x7A; vkSpace=0x20
)

type point struct{ X,Y int32 }
type msg struct { Hwnd uintptr; Message uint32; _ uint32; Wparam,Lparam uintptr; Time uint32; Pt point; Private uint32 }
type rect struct{ Left,Top,Right,Bottom int32 }
type wndClass struct { Size,Style uint32; WndProc uintptr; ClsExtra,WndExtra int32; Instance,Icon,Cursor,Background,MenuName,ClassName,SmallIcon uintptr }
type bitmapInfoHeader struct{ Size uint32; Width,Height int32; Planes,BitCount uint16; Compression,SizeImage uint32; XPelsPerMeter,YPelsPerMeter int32; ClrUsed,ClrImportant uint32 }
type bitmapInfo struct{ Header bitmapInfoHeader; Colors [1]uint32 }
type openFileName struct{
 Size uint32; Owner,Instance uintptr; Filter,CustomFilter uintptr; MaxCustomFilter,FilterIndex uint32
 File uintptr; MaxFile uint32; FileTitle uintptr; MaxFileTitle uint32; InitialDir,Title uintptr
 Flags uint32; FileOffset,FileExtension uint16; DefExt,CustomData,Hook,TemplateName,Reserved uintptr
 ReservedInt,FlagsEx uint32
}
type retroGame struct{ Path,Data,Size,Meta uintptr }
type retroGeometry struct{ BaseW,BaseH,MaxW,MaxH uint32; Aspect float32 }
type retroAV struct { Geometry retroGeometry; Timing struct{ FPS, SampleRate float64 } }
type waveFormat struct { Tag,Channels uint16; Rate,AvgBytes uint32; BlockAlign,Bits uint16; Size uint16 }
type waveHdr struct{ Data uintptr; BufferLength,BytesRecorded uint32; User uintptr; Flags,Loops uint32; Next,Reserved uintptr }
type xinputState struct { Packet uint32; Buttons uint16; LeftTrigger,RightTrigger uint8; LX,LY,RX,RY int16 }

var (
 user32=syscall.NewLazyDLL("user32.dll"); kernel32=syscall.NewLazyDLL("kernel32.dll")
 gdi32=syscall.NewLazyDLL("gdi32.dll"); winmm=syscall.NewLazyDLL("winmm.dll")
 comdlg32=syscall.NewLazyDLL("comdlg32.dll"); shell32=syscall.NewLazyDLL("shell32.dll")
 pRegisterClass=user32.NewProc("RegisterClassExW"); pCreateWindow=user32.NewProc("CreateWindowExW")
 pDefWindowProc=user32.NewProc("DefWindowProcW"); pPeekMessage=user32.NewProc("PeekMessageW")
 pTranslateMessage=user32.NewProc("TranslateMessage"); pDispatchMessage=user32.NewProc("DispatchMessageW")
 pShowWindow=user32.NewProc("ShowWindow"); pUpdateWindow=user32.NewProc("UpdateWindow")
 pDestroyWindow=user32.NewProc("DestroyWindow"); pGetClientRect=user32.NewProc("GetClientRect")
 pGetDC=user32.NewProc("GetDC"); pReleaseDC=user32.NewProc("ReleaseDC")
 pInvalidateRect=user32.NewProc("InvalidateRect"); pValidateRect=user32.NewProc("ValidateRect")
 pGetAsyncKeyState=user32.NewProc("GetAsyncKeyState"); pGetForegroundWindow=user32.NewProc("GetForegroundWindow")
 pLoadCursor=user32.NewProc("LoadCursorW"); pMessageBox=user32.NewProc("MessageBoxW")
 pCreateMenu=user32.NewProc("CreateMenu"); pAppendMenu=user32.NewProc("AppendMenuW")
 pSetMenu=user32.NewProc("SetMenu"); pSetWindowText=user32.NewProc("SetWindowTextW")
 pStretchDIBits=gdi32.NewProc("StretchDIBits"); pSetStretchBltMode=gdi32.NewProc("SetStretchBltMode")
 pGetOpenFileName=comdlg32.NewProc("GetOpenFileNameW")
 pDragAcceptFiles=shell32.NewProc("DragAcceptFiles"); pDragQueryFile=shell32.NewProc("DragQueryFileW")
 pDragFinish=shell32.NewProc("DragFinish")
 pWaveOpen=winmm.NewProc("waveOutOpen"); pWavePrepare=winmm.NewProc("waveOutPrepareHeader")
 pWaveWrite=winmm.NewProc("waveOutWrite"); pWaveReset=winmm.NewProc("waveOutReset")
 pWaveUnprepare=winmm.NewProc("waveOutUnprepareHeader"); pWaveClose=winmm.NewProc("waveOutClose")
 pVirtualAlloc=kernel32.NewProc("VirtualAlloc"); pVirtualFree=kernel32.NewProc("VirtualFree")
 pGetModuleHandle=kernel32.NewProc("GetModuleHandleW")
 hwnd uintptr; isRunning=true; loaded=false; isPaused=false
 core *syscall.DLL; romMem uintptr; romSize uintptr; gamePath string; savePath string
 frame []uint32; frameW,frameH int; pixelFormat uint32 = 0; bi bitmapInfo
 coreFns=map[string]*syscall.Proc{}; fps=60.098
 systemPathCString []byte; videoFrames uint64
 waveHandle uintptr; waveHeaderPtrs [waveBuffers]uintptr; waveUsed [waveBuffers]bool; wavePos int
 audioRate uint32=32040
 padMasks [2]uint16; xinput *syscall.Proc
)

// Verificações de compatibilidade ABI Win32 x64 em tempo de compilação.
var _ [152-int(unsafe.Sizeof(openFileName{}))]byte
var _ [int(unsafe.Sizeof(openFileName{}))-152]byte
var _ [80-int(unsafe.Sizeof(wndClass{}))]byte
var _ [int(unsafe.Sizeof(wndClass{}))-80]byte
var _ [48-int(unsafe.Sizeof(waveHdr{}))]byte
var _ [int(unsafe.Sizeof(waveHdr{}))-48]byte

func wide(s string)*uint16{ p,_:=syscall.UTF16PtrFromString(s); return p }
func call(p interface{ Call(...uintptr)(uintptr,uintptr,error) },args ...uintptr)uintptr{ r,_,_:=p.Call(args...); return r }
func u16p(s string)uintptr{ return uintptr(unsafe.Pointer(wide(s))) }
func notify(text string, bad bool){ flags:=uintptr(mbOK|mbIconInformation);if bad{flags=mbOK|mbIconError};call(pMessageBox,hwnd,u16p(text),u16p("Kong's Quest — Windows"),flags) }
func coreCall(name string, args ...uintptr)uintptr { p:=coreFns[name]; if p==nil{return 0};return call(p,args...) }
func loadCore() error {
 exe,err:=os.Executable();if err!=nil{return err}
 dllPath:=filepath.Join(filepath.Dir(exe),"snes9x_libretro.dll")
 core,err=syscall.LoadDLL(dllPath);if err!=nil{return fmt.Errorf("Não encontrei o núcleo modificado snes9x_libretro.dll na mesma pasta do programa.\n\n%w",err)}
 funcs:=[]string{"retro_set_environment","retro_set_video_refresh","retro_set_audio_sample","retro_set_audio_sample_batch","retro_set_input_poll","retro_set_input_state","retro_init","retro_deinit","retro_load_game","retro_unload_game","retro_run","retro_reset","retro_get_system_av_info","retro_get_memory_data","retro_get_memory_size","retro_set_controller_port_device"}
 for _,name:=range funcs{p,e:=core.FindProc(name);if e!=nil{return fmt.Errorf("O núcleo não tem a função %s: %w",name,e)};coreFns[name]=p}
 systemPathCString=append([]byte(filepath.Dir(exe)),0)
 coreCall("retro_set_environment",syscall.NewCallback(envCB))
 coreCall("retro_set_video_refresh",syscall.NewCallback(videoCB))
 coreCall("retro_set_audio_sample",syscall.NewCallback(audioSampleCB))
 coreCall("retro_set_audio_sample_batch",syscall.NewCallback(audioBatchCB))
 coreCall("retro_set_input_poll",syscall.NewCallback(inputPollCB))
 coreCall("retro_set_input_state",syscall.NewCallback(inputStateCB))
 coreCall("retro_init")
 coreCall("retro_set_controller_port_device",0,retroDeviceJoypad)
 return nil
}

func envCB(cmd,data uintptr) uintptr {
 switch cmd {
 case 3: // GET_CAN_DUPE
  if data!=0{ *(*byte)(unsafe.Pointer(data))=1 };return 1
 case 9,31: // directories
  if data!=0 && len(systemPathCString)>0 { *(*uintptr)(unsafe.Pointer(data))=uintptr(unsafe.Pointer(&systemPathCString[0]));return 1 }
 case 10: // SET_PIXEL_FORMAT
  if data!=0{format:=*(*uint32)(unsafe.Pointer(data));if format<=2{pixelFormat=format;return 1}}
 case 52: // GET_CORE_OPTIONS_VERSION, fallback to legacy variables
  if data!=0{*(*uint32)(unsafe.Pointer(data))=0};return 1
 case (51|0x10000): // GET_INPUT_BITMASKS
  return 1
 }
 return 0
}
func videoCB(data,w,h,pitch uintptr) uintptr {
 if data==0 || data==^uintptr(0) || w==0 || h==0 || w>1024 || h>1024{return 0}
 count:=int(w*h);if cap(frame)<count{frame=make([]uint32,count)};frame=frame[:count]
 switch pixelFormat {
 case 1: // XRGB8888
  for y:=uintptr(0);y<h;y++ {src:=unsafe.Slice((*uint32)(unsafe.Pointer(data+y*pitch)),int(w));copy(frame[int(y*w):int((y+1)*w)],src)}
 case 2: // RGB565
  for y:=uintptr(0);y<h;y++ {src:=unsafe.Slice((*uint16)(unsafe.Pointer(data+y*pitch)),int(w));for x,v:=range src {r:=uint32(v>>11)&31;g:=uint32(v>>5)&63;b:=uint32(v)&31;frame[int(y*w)+x]=(r*255/31)<<16|(g*255/63)<<8|(b*255/31)}}
 default: // 0RGB1555
  for y:=uintptr(0);y<h;y++ {src:=unsafe.Slice((*uint16)(unsafe.Pointer(data+y*pitch)),int(w));for x,v:=range src {r:=uint32(v>>10)&31;g:=uint32(v>>5)&31;b:=uint32(v)&31;frame[int(y*w)+x]=(r*255/31)<<16|(g*255/31)<<8|(b*255/31)}}
 }
 frameW,frameH=int(w),int(h);videoFrames++
 return 0
}
func audioSampleCB(l,r uintptr) uintptr {
 two:=[2]int16{int16(l),int16(r)}
 audioBatchCB(uintptr(unsafe.Pointer(&two[0])),1);runtime.KeepAlive(two)
 return 0
}
func audioBatchCB(data,frames uintptr) uintptr {
 if waveHandle==0 || frames==0 || data==0{return frames}
 src:=unsafe.Slice((*byte)(unsafe.Pointer(data)),int(frames)*4)
 for len(src)>0{
  count:=len(src);if count>waveBlockBytes{count=waveBlockBytes}
  i:=wavePos;hptr:=waveHeaderPtrs[i]
  if hptr==0{src=src[count:];wavePos=(wavePos+1)%waveBuffers;continue}
  h:=(*waveHdr)(unsafe.Pointer(hptr))
  if !waveUsed[i] || h.Flags&waveHdrDone!=0 {
   copy(unsafe.Slice((*byte)(unsafe.Pointer(h.Data)),waveBlockBytes),src[:count])
   h.BufferLength=uint32(count)
   if call(pWaveWrite,waveHandle,waveHeaderPtrs[i],unsafe.Sizeof(*h))==0 {waveUsed[i]=true}
   wavePos=(wavePos+1)%waveBuffers
  } // no spare buffer: drop audio rather than blocking emulation
  src=src[count:]
 }
 return frames
}
func key(vk uintptr)bool{return int16(call(pGetAsyncKeyState,vk))<0}
func tryXInput() {
 for _,name:=range []string{"xinput1_4.dll","xinput9_1_0.dll","xinput1_3.dll"}{dll,e:=syscall.LoadDLL(name);if e!=nil{continue};p,e:=dll.FindProc("XInputGetState");if e==nil{xinput=p;return}}
}
func inputPollCB()uintptr {
 if call(pGetForegroundWindow)!=hwnd{padMasks=[2]uint16{};return 0}
 var pads [2]uint16
 if key(vkUp){pads[0]|=1<<4};if key(vkDown){pads[0]|=1<<5}
 if key(vkLeft){pads[0]|=1<<6};if key(vkRight){pads[0]|=1<<7}
 if key('Z'){pads[0]|=1<<0};if key('X'){pads[0]|=1<<8}
 if key('A'){pads[0]|=1<<1};if key('S'){pads[0]|=1<<9}
 if key('Q'){pads[0]|=1<<10};if key('W'){pads[0]|=1<<11}
 if key(vkReturn){pads[0]|=1<<3};if key(vkShift){pads[0]|=1<<2}
 if xinput!=nil{for i:=0;i<2;i++{
  var s xinputState
  if call(xinput,uintptr(i),uintptr(unsafe.Pointer(&s)))!=0{continue}
  b:=s.Buttons
  if b&0x0001!=0 || s.LY>16000{pads[i]|=1<<4}
  if b&0x0002!=0 || s.LY< -16000{pads[i]|=1<<5}
  if b&0x0004!=0 || s.LX< -16000{pads[i]|=1<<6}
  if b&0x0008!=0 || s.LX>16000{pads[i]|=1<<7}
  if b&0x1000!=0{pads[i]|=1<<0} // Xbox A -> SNES B (pular)
  if b&0x2000!=0{pads[i]|=1<<8} // Xbox B -> SNES A
  if b&0x4000!=0{pads[i]|=1<<1} // Xbox X -> SNES Y (rolar)
  if b&0x8000!=0{pads[i]|=1<<9} // Xbox Y -> SNES X
  if b&0x0100!=0{pads[i]|=1<<10};if b&0x0200!=0{pads[i]|=1<<11}
  if b&0x0010!=0{pads[i]|=1<<3};if b&0x0020!=0{pads[i]|=1<<2}
 }}
 padMasks=pads
 return 0
}
func inputStateCB(port,device,index,id uintptr)uintptr {
 if device&0xff!=retroDeviceJoypad || port>1{return 0}
 mask:=padMasks[port]
 if id==retroJoypadMask{return uintptr(mask)}
 if id>=16{return 0}
 if mask&(1<<id)!=0{return 1}
 return 0
}
func startAudio(rate float64){
 stopAudio()
 if rate<8000 || rate>192000{rate=32040}
 audioRate=uint32(rate+0.5)
 format:=waveFormat{Tag:waveFormatPCM,Channels:2,Rate:audioRate,AvgBytes:audioRate*4,BlockAlign:4,Bits:16}
 if call(pWaveOpen,uintptr(unsafe.Pointer(&waveHandle)),waveMapper,uintptr(unsafe.Pointer(&format)),0,0,0)!=0{waveHandle=0;return}
 for i:=range waveHeaderPtrs{
  a:=call(pVirtualAlloc,0,waveBlockBytes,memCommit|memReserve,pageReadWrite)
  hptr:=call(pVirtualAlloc,0,unsafe.Sizeof(waveHdr{}),memCommit|memReserve,pageReadWrite)
  if a==0 || hptr==0{continue}
  h:=(*waveHdr)(unsafe.Pointer(hptr));h.Data=a;h.BufferLength=waveBlockBytes
  if call(pWavePrepare,waveHandle,hptr,unsafe.Sizeof(*h))==0{waveHeaderPtrs[i]=hptr}else{call(pVirtualFree,hptr,0,memRelease);call(pVirtualFree,a,0,memRelease)}
 }
 wavePos=0
}
func stopAudio(){
 if waveHandle==0{return}
 call(pWaveReset,waveHandle)
 for i,hptr:=range waveHeaderPtrs{if hptr!=0{
  h:=(*waveHdr)(unsafe.Pointer(hptr))
  call(pWaveUnprepare,waveHandle,hptr,unsafe.Sizeof(*h))
  if h.Data!=0{call(pVirtualFree,h.Data,0,memRelease)}
  call(pVirtualFree,hptr,0,memRelease)
  waveHeaderPtrs[i]=0;waveUsed[i]=false
 }}
 call(pWaveClose,waveHandle);waveHandle=0
}
func saveRAM(){
 if !loaded || savePath==""{return}
 mem:=coreCall("retro_get_memory_data",retroSaveRam)
 size:=coreCall("retro_get_memory_size",retroSaveRam)
 if mem==0 || size==0 || size>131072{return}
 src:=unsafe.Slice((*byte)(unsafe.Pointer(mem)),int(size))
 b:=append([]byte(nil),src...)
 _=os.WriteFile(savePath,b,0644)
}
func loadRAM(){
 b,err:=os.ReadFile(savePath);if err!=nil{return}
 mem:=coreCall("retro_get_memory_data",retroSaveRam)
 size:=coreCall("retro_get_memory_size",retroSaveRam)
 if mem!=0 && size>0 && len(b)==int(size){copy(unsafe.Slice((*byte)(unsafe.Pointer(mem)),int(size)),b)}
}
func unload(){
 if !loaded{return}
 saveRAM();stopAudio();coreCall("retro_unload_game");loaded=false
 if romMem!=0{call(pVirtualFree,romMem,0,memRelease);romMem=0;romSize=0}
}
func loadGame(path string)error{
 fileData,err:=os.ReadFile(path);if err!=nil{return err}
 if len(fileData)<65536 || len(fileData)>40*1024*1024{return fmt.Errorf("Arquivo não parece uma campanha SNES válida: %d bytes",len(fileData))}
 // No core de Kong's Quest, o container tem tamanho específico e assinatura no offset 0x7f00.
 if len(fileData)<0x7f0f || string(fileData[0x7f00:0x7f0f])!="DKCJOURNEY-MMC5" {return fmt.Errorf("Este arquivo não é o container especial de Kong's Quest (.sfc).")}
 unload()
 mem:=call(pVirtualAlloc,0,uintptr(len(fileData)),memCommit|memReserve,pageReadWrite)
 if mem==0{return fmt.Errorf("Não foi possível reservar memória para a campanha.")}
 copy(unsafe.Slice((*byte)(unsafe.Pointer(mem)),len(fileData)),fileData)
 romMem=mem;romSize=uintptr(len(fileData))
 pathC:=append([]byte(path),0)
 game:=retroGame{Path:uintptr(unsafe.Pointer(&pathC[0])),Data:romMem,Size:romSize}
 ok:=coreCall("retro_load_game",uintptr(unsafe.Pointer(&game)))
 runtime.KeepAlive(pathC)
 if ok==0{call(pVirtualFree,romMem,0,memRelease);romMem=0;romSize=0;return fmt.Errorf("O núcleo Snes9x recusou o arquivo de campanha.")}
 gamePath=path;savePath=strings.TrimSuffix(path,filepath.Ext(path))+".srm"
 loaded=true;isPaused=false;loadRAM()
 var av retroAV;coreCall("retro_get_system_av_info",uintptr(unsafe.Pointer(&av)))
 if av.Timing.FPS>40 && av.Timing.FPS<75{fps=av.Timing.FPS}
 startAudio(av.Timing.SampleRate)
 call(pSetWindowText,hwnd,u16p("Kong's Quest — "+filepath.Base(path)))
 return nil
}
func chooseGame() {
 buffer:=make([]uint16,32768)
 // Filtro: *.sfc;*.smc;*.bin, e todos os arquivos.
 filter:=syscall.StringToUTF16("Campanha Kong's Quest (*.sfc)\x00*.sfc\x00Todos os arquivos (*.*)\x00*.*\x00")
 ofn:=openFileName{Size:uint32(unsafe.Sizeof(openFileName{})),Owner:hwnd,Filter:uintptr(unsafe.Pointer(&filter[0])),File:uintptr(unsafe.Pointer(&buffer[0])),MaxFile:uint32(len(buffer)),Title:u16p("Selecione a campanha Kong's Quest (.sfc)"),Flags:fileMustExist|pathMustExist|ofnExplorer}
 if call(pGetOpenFileName,uintptr(unsafe.Pointer(&ofn)))==0{return}
 n:=0;for n<len(buffer) && buffer[n]!=0{n++}
 path:=syscall.UTF16ToString(buffer[:n])
 if err:=loadGame(path);err!=nil{notify(err.Error(),true)}
 runtime.KeepAlive(filter);runtime.KeepAlive(buffer)
}
func draw(){
 dc:=call(pGetDC,hwnd);if dc==0{return};defer call(pReleaseDC,hwnd,dc)
 var r rect;call(pGetClientRect,hwnd,uintptr(unsafe.Pointer(&r)))
 cw,ch:=int(r.Right-r.Left),int(r.Bottom-r.Top)
 if cw<=0 || ch<=0{return}
 // Fundo preto, sem alterar pixels originais do jogo.
 brush,_,_:=syscall.NewLazyDLL("gdi32.dll").NewProc("CreateSolidBrush").Call(0)
 if brush!=0{
  fill:=user32.NewProc("FillRect");call(fill,dc,uintptr(unsafe.Pointer(&r)),brush)
  call(gdi32.NewProc("DeleteObject"),brush)
 }
 if frameW<1 || frameH<1 || len(frame)<frameW*frameH {
  msg:="KONG'S QUEST — WINDOWS\r\n\r\nArquivo > Abrir campanha (.sfc)\r\nou pressione F2.\r\n\r\nO núcleo Snes9x adaptado deve estar na mesma pasta."
  call(gdi32.NewProc("SetTextColor"),dc,0x00FFFFFF)
  call(gdi32.NewProc("SetBkMode"),dc,1)
  call(user32.NewProc("DrawTextW"),dc,u16p(msg),^uintptr(0),uintptr(unsafe.Pointer(&r)),0x10|0x1)
  return
 }
 info:=bitmapInfo{Header:bitmapInfoHeader{Size:40,Width:int32(frameW),Height:-int32(frameH),Planes:1,BitCount:32,Compression:biRGB}}
 // 4:3 no monitor, com preservação de proporção e pixels do jogo.
 targetW,targetH:=cw,ch
 if targetW*3>targetH*4{targetW=targetH*4/3}else{targetH=targetW*3/4}
 if targetW<=0 || targetH<=0{return}
 offX,offY:=(cw-targetW)/2,(ch-targetH)/2
 call(pSetStretchBltMode,dc,colorOnColor)
 call(pStretchDIBits,dc,uintptr(offX),uintptr(offY),uintptr(targetW),uintptr(targetH),0,0,uintptr(frameW),uintptr(frameH),uintptr(unsafe.Pointer(&frame[0])),uintptr(unsafe.Pointer(&info)),dibRGBColors,0x00CC0020)
 runtime.KeepAlive(frame)
}
func windowProc(wh uintptr,message uint32,wparam,lparam uintptr)uintptr{
 switch message {
 case wmPaint:
  if wh==hwnd{draw();call(pValidateRect,hwnd,0)};return 0
 case wmCommand:
  switch wparam&0xffff {
  case commandOpen:chooseGame()
  case commandSave:saveRAM();notify("Progresso salvo no arquivo .srm ao lado da campanha.",false)
  case commandPause:isPaused=!isPaused
  case commandReset:if loaded{saveRAM();coreCall("retro_reset")}
  case commandControls:notify("TECLADO\nSetas: movimentação\nZ: pular (B) | A: rolar (Y)\nX: botão A | S: botão X\nQ: L | W: R | Enter: Start | Shift: Select\nF2: abrir campanha | F5: salvar | P: pausa\n\nCONTROLE XBOX\nA: pular | X: rolar | LB/RB: L/R\nMenu: Start | View: Select\n\nPara avançar após concluir o capítulo: segure L+R+Start por 1 segundo.",false)
  case commandQuit:call(pDestroyWindow,hwnd)
  };return 0
 case wmKeyDown:
  switch wparam{
  case vkF2:chooseGame();return 0
  case vkF5:saveRAM();return 0
  case 'P':isPaused=!isPaused;return 0
  case vkEscape: // não fecha o jogo sem querer
   return 0
  }
 case wmDropFiles:
  len:=call(pDragQueryFile,wparam,0,0,0)
  if len>0 && len<32767{
   b:=make([]uint16,int(len)+1)
   call(pDragQueryFile,wparam,0,uintptr(unsafe.Pointer(&b[0])),len+1)
   path:=syscall.UTF16ToString(b)
   if err:=loadGame(path);err!=nil{notify(err.Error(),true)}
  }
  call(pDragFinish,wparam);return 0
 case wmClose:call(pDestroyWindow,wh);return 0
 case wmDestroy:isRunning=false;return 0
 }
 return call(pDefWindowProc,wh,uintptr(message),wparam,lparam)
}
func buildWindow()error{
 hInst:=call(pGetModuleHandle,0)
 class:=wide("KongsQuestWindowClass")
 wc:=wndClass{Size:uint32(unsafe.Sizeof(wndClass{})),Style:csVredraw|csHredraw,WndProc:syscall.NewCallback(windowProc),Instance:hInst,Cursor:call(pLoadCursor,0,32512),ClassName:uintptr(unsafe.Pointer(class))}
 if call(pRegisterClass,uintptr(unsafe.Pointer(&wc)))==0{return fmt.Errorf("RegisterClassExW falhou")}
 hwnd=call(pCreateWindow,0,uintptr(unsafe.Pointer(class)),u16p("Kong's Quest — Windows"),wsOverlappedWindow|wsVisible,100,70,1040,860,0,0,hInst,0)
 if hwnd==0{return fmt.Errorf("CreateWindowExW falhou")}
 menu:=call(pCreateMenu)
 for _,item:=range []struct{id uintptr;name string}{{commandOpen,"Abrir campanha... (F2)"},{commandSave,"Salvar progresso (F5)"},{commandPause,"Pausar / continuar (P)"},{commandReset,"Reiniciar capítulo"},{commandControls,"Controles e ajuda"},{commandQuit,"Sair"}}{
  call(pAppendMenu,menu,mfString,item.id,u16p(item.name))
 }
 call(pSetMenu,hwnd,menu);call(pDragAcceptFiles,hwnd,1)
 call(pShowWindow,hwnd,swShow);call(pUpdateWindow,hwnd)
 return nil
}
func run(){
 var m msg
 period:=time.Second/60;next:=time.Now()
 saveTicker:=time.Now()
 for isRunning {
  for call(pPeekMessage,uintptr(unsafe.Pointer(&m)),0,0,0,pmRemove)!=0{
   if m.Message==0x12{isRunning=false;break}
   call(pTranslateMessage,uintptr(unsafe.Pointer(&m)));call(pDispatchMessage,uintptr(unsafe.Pointer(&m)))
  }
  if !isRunning{break}
  if loaded && !isPaused {
   effectiveFPS:=fps;if effectiveFPS<40 || effectiveFPS>75{effectiveFPS=60.098}
   period=time.Duration(float64(time.Second)/effectiveFPS)
   now:=time.Now()
   if !now.Before(next){
    coreCall("retro_run");call(pInvalidateRect,hwnd,0,0)
    next=next.Add(period)
    if now.Sub(next)>4*period{next=now.Add(period)}
   }
   if time.Since(saveTicker)>30*time.Second{saveRAM();saveTicker=time.Now()}
  }else{next=time.Now()}
  time.Sleep(time.Millisecond)
 }
}
func main(){
 runtime.LockOSThread()
 if e:=buildWindow();e!=nil{notify(e.Error(),true);return}
 if e:=loadCore();e!=nil{notify(e.Error(),true);call(pDestroyWindow,hwnd);return}
 tryXInput()
 // Se um .sfc estiver junto do executável, carregá-lo automaticamente.
 candidates:=[]string{}
 if len(os.Args)>1{candidates=append(candidates,os.Args[1])}
 exe,_:=os.Executable()
 local,_:=filepath.Glob(filepath.Join(filepath.Dir(exe),"*.sfc"));candidates=append(candidates,local...)
 for _,c:=range candidates{if err:=loadGame(c);err==nil{break}}
 run();unload();coreCall("retro_deinit")
}
